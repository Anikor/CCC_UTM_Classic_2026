#!/usr/bin/env python3
"""Per-case best-of merge: python3 merge6.py <in> <out> <cand1.out> <cand2.out> ..."""
import sys
_argv=sys.argv; sys.argv=['x']
exec(open('nano6.py').read().replace('\nmain()\n','\n'))
sys.argv=_argv
inp,outp=sys.argv[1:3]; cands=sys.argv[3:]
cases=parse(inp)
best=[None]*len(cases); src=[None]*len(cases)
for cf in cands:
    try: blocks=[b for b in open(cf).read().replace('\r\n','\n').split('\n\n') if b.strip()]
    except FileNotFoundError: continue
    if len(blocks)!=len(cases): print(f'skip {cf}: {len(blocks)} blocks vs {len(cases)} cases', file=sys.stderr); continue
    for i,((R,rows,cols,need,pat),b) in enumerate(zip(cases,blocks)):
        if 'FAIL' in b: continue
        prog=[l.split() for l in b.strip().split('\n')]
        if any(len(l)!=6 for l in prog): continue
        if best[i] is not None and len(prog)>=len(best[i]): continue
        if simulate(Geo(R),pat,prog)!=need: continue
        best[i]=prog; src[i]=cf
assert all(b is not None for b in best), [i for i,b in enumerate(best) if b is None]
open(outp,'w').write('\n\n'.join('\n'.join(' '.join(l) for l in p) for p in best)+'\n')
from collections import Counter
print(f'{outp}: score {sum(len(p) for p in best)} sources {dict(Counter(src))}', file=sys.stderr)
