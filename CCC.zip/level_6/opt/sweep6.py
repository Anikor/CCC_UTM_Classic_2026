#!/usr/bin/env python3
"""Structured sweep planner for level 6.  python3 sweep6.py <in> <out> [fallback.out]"""
import sys
from collections import defaultdict
sys.argv_backup = sys.argv; sys.argv = ['x']
exec(open('nano6.py').read().replace('\nmain()\n', '\n'))
sys.argv = sys.argv_backup

def line_pos(geo, e, c):
    """rail position of emitter e whose beam passes through cell c (or None)."""
    for (ee, p) in geo.cell_opts[c]:
        if ee == e: return p
    return None

def plan_shots(geo, cells, P, S, rev_lines, state_pos):
    """cells: remaining pattern cells. P: primary family (0,1,2), S: sweeper family.
    Returns list of shots (cell, pe, pa, se, pb)."""
    P0, P1, S0, S1 = P, P+3, S, S+3
    lines = defaultdict(list)
    for c in cells:
        lines[line_pos(geo, P0, c)].append(c)
    keys = sorted(lines)
    if rev_lines: keys.reverse()
    shots = []; use_p = 0; use_s = 0; flip = False
    prev_end = None
    for k in keys:
        cs = lines[k]
        cs.sort(key=lambda c: line_pos(geo, S0, c))
        # serpentine: start at the end nearest to the previous run's end (by sweeper rail pos)
        if prev_end is not None:
            d_first = min(dist(geo, prev_end, line_pos(geo, S0, cs[0]))[0], dist(geo, prev_end, line_pos(geo, S1, cs[0]))[0])
            d_last = min(dist(geo, prev_end, line_pos(geo, S0, cs[-1]))[0], dist(geo, prev_end, line_pos(geo, S1, cs[-1]))[0])
            if d_last < d_first: cs.reverse()
        pe = P0 if use_p == 0 else P1; use_p ^= 1
        pa = line_pos(geo, pe, cs[0])
        prev = None
        for c in cs:
            sp0 = line_pos(geo, S0, c)
            if prev is not None and dist(geo, prev, sp0)[0] != 1:
                use_s ^= 1          # gap -> switch to the twin sweeper
            se = S0 if use_s == 0 else S1
            shots.append((c, pe, pa, se, line_pos(geo, se, c)))
            prev = sp0
        prev_end = prev
        use_s ^= 1                  # new line -> switch sweeper so the other can pre-position
    return shots

def run_shots(geo, pat, shots, pos, act, board, prog, pm, nb, max_ticks=100000):
    """Tick scheduler. Mutates pos/act/board/prog. Returns number of submissions made."""
    rows, cols = geo.rows, geo.cols
    k = 0; subs = 0; ticks = 0
    def next_target(e, k):
        for s in shots[k:]:
            if s[1] == e: return s[2]
            if s[3] == e: return s[4]
        return None
    while k < len(shots):
        ticks += 1
        if ticks > max_ticks: return -1
        c, pe, pa, se, pb = shots[k]
        line = ['-'] * 6
        pair = {pe: pa, se: pb}
        for e in range(6):
            if e in pair:
                tgt = pair[e]
                if pos[e] != tgt:
                    line[e] = dist(geo, pos[e], tgt)[1]
            elif act[e]:
                line[e] = 'T'
            else:
                t = next_target(e, k + 1)
                if t is not None and pos[e] != t:
                    line[e] = dist(geo, pos[e], t)[1]
        # will both be at target after moves?
        newpos = {e: ((pos[e] + (1 if line[e]=='F' else -1 if line[e]=='B' else 0)) % geo.M) for e in pair}
        ready = all(newpos[e] == pair[e] for e in pair)
        for e in pair:
            if not act[e] and line[e] == '-':
                other = se if e == pe else pe
                # toggle on if partner inactive, or partner will be at target this tick (then we fire)
                if (not act[other]) or ready:
                    line[e] = 'T'
        # if both active but not ready, and someone moves -> stray; toggle off the mover if it moved... avoid:
        if act[pe] and act[se] and not ready:
            # keep the non-moving one on, toggle off the one that is moving? cannot (move+T). toggle off the other.
            movers = [e for e in pair if line[e] in 'FB']
            if movers:
                stay = [e for e in pair if e not in movers]
                if stay: line[stay[0]] = 'T'
                else:   # both moving: toggle off one instead of moving it this tick
                    line[movers[0]] = 'T'
        # execute
        for e in range(6):
            if line[e]=='F': pos[e]=(pos[e]+1)%geo.M
            elif line[e]=='B': pos[e]=(pos[e]-1)%geo.M
            elif line[e]=='T': act[e]=not act[e]
        cnt = defaultdict(int)
        for e in range(6):
            if act[e]:
                for cc in geo.beam[(e,pos[e])]: cnt[cc]+=1
        for cc,n in cnt.items():
            if n==2: board[cc[0]][cc[1]]='M'
            elif n>=3: board[cc[0]][cc[1]]='O'
        if all(board[i][j]=='M' for i,j in pm) and not any(board[i][j]=='M' for i,j in nb):
            subs+=1
            for i,j in pm: board[i][j]='O'
        prog.append(line)
        if act[pe] and act[se] and pos[pe]==pa and pos[se]==pb:
            k += 1
    return subs

def solve_case_sweep(R, rows, cols, need, pat, P, S):
    geo = Geo(R)
    pm = [(i,j) for i in range(rows) for j in range(cols) if pat[i][j]=='M']
    pmset=set(pm); nb=set()
    for (i,j) in pm:
        for dr,dc in NB:
            c=(i+dr,j+dc)
            if c not in pmset and 0<=c[0]<rows and 0<=c[1]<cols and geo.g[c[0]][c[1]]=='O': nb.add(c)
    pos=list(geo.start); act=[False]*6; board=[r[:] for r in geo.g]; prog=[]
    total=0
    for copy in range(need):
        shots = plan_shots(geo, pm, P, S, copy % 2 == 1, pos)
        s = run_shots(geo, pat, shots, pos, act, board, prog, pm, nb)
        if s < 0: return None
        total += s
        if total != copy + 1: return None
    # strict re-check with the reference simulator
    if simulate(geo, pat, prog) != need: return None
    return prog

def main():
    inp, outp = sys.argv[1:3]
    fallback = sys.argv[3] if len(sys.argv) > 3 else None
    cases = parse(inp)
    fb = None
    if fallback:
        fb=[b for b in open(fallback).read().replace('\r\n','\n').split('\n\n') if b.strip()]
    out=[]; total=0; nfb=0
    for idx,(R,rows,cols,need,pat) in enumerate(cases):
        best=None
        for P in range(3):
            for S in range(3):
                if S==P: continue
                prog=solve_case_sweep(R,rows,cols,need,pat,P,S)
                if prog is not None and (best is None or len(prog)<len(best)): best=prog
        if best is None:
            nfb+=1; blk=fb[idx]; total+=blk.count('\n')+1; out.append(blk.strip()); continue
        total+=len(best); out.append('\n'.join(' '.join(l) for l in best))
    open(outp,'w').write('\n\n'.join(out)+'\n')
    print(f'{inp}: score {total} (fallbacks {nfb})', file=sys.stderr)
main()
