// Beam search for level 6.  ./bs6 <in> <out> [W=64] [threads=8]
#include <bits/stdc++.h>
using namespace std;
typedef bitset<512> BS;
struct Geo {
    int R, rows, cols, M; vector<string> g; vector<pair<int,int>> ring; int start[6];
    vector<vector<int>> id; int ncell;
    vector<vector<BS>> beam; // [e][p]
    int D[6][2] = {{0,2},{1,1},{1,-1},{0,-2},{-1,-1},{-1,1}};
    Geo(int R_):R(R_){
        rows=2*R+1; cols=4*R+1; g.assign(rows,string(cols,'-')); id.assign(rows,vector<int>(cols,-1)); ncell=0;
        for(int i=0;i<rows;i++){int off=abs(i-R); for(int j=off;j<=cols-1-off;j+=2){bool b=(i==0||i==rows-1||j==off||j==cols-1-off); g[i][j]=b?'*':'O'; if(!b) id[i][j]=ncell++;}}
        for(int t=0;t<R;t++) ring.push_back({0,R+2*t}); for(int t=0;t<R;t++) ring.push_back({t,3*R+t});
        for(int t=0;t<R;t++) ring.push_back({R+t,4*R-t}); for(int t=0;t<R;t++) ring.push_back({2*R,3*R-2*t});
        for(int t=0;t<R;t++) ring.push_back({2*R-t,R-t}); for(int t=0;t<R;t++) ring.push_back({R-t,t});
        M=ring.size(); int s[6]={5*R,0,R,2*R,3*R,4*R}; for(int e=0;e<6;e++)start[e]=s[e];
        beam.assign(6,vector<BS>(M));
        for(int e=0;e<6;e++)for(int p=0;p<M;p++){int y=ring[p].first+D[e][0],x=ring[p].second+D[e][1]; while(y>=0&&y<rows&&x>=0&&x<cols){ if(id[y][x]>=0) beam[e][p].set(id[y][x]); y+=D[e][0];x+=D[e][1];}}
    }
    int rd(int p,int q)const{int f=((q-p)%M+M)%M; return min(f,M-f);}
};
bool beamneeded(const struct Geo&G,int e,int p,const BS&needed);
struct State { unsigned char pos[6]; unsigned char act; BS board; int copies; int score; int parent; unsigned short mv; };
static inline int popc(const BS&b){return (int)b.count();}

struct Case { int R,rows,cols,need; vector<string> pat; };

string solve(const Case& c, int W, long long& outlines){
    Geo G(c.R); BS pat; vector<pair<int,int>> pm;
    for(int i=0;i<c.rows;i++)for(int j=0;j<c.cols;j++) if(c.pat[i][j]=='M'){pat.set(G.id[i][j]); pm.push_back({i,j});}
    int npat=popc(pat);
    // per-tick layers kept for reconstruction
    vector<vector<State>> layers;
    State s0; memset(&s0,0,sizeof s0); for(int e=0;e<6;e++)s0.pos[e]=G.start[e]; s0.act=0; s0.copies=0; s0.parent=-1; s0.mv=0;
    layers.push_back({s0});
    const char INS[4]={'-','F','B','T'};
    int done=-1; int depth=0;
    vector<int> near(6*G.M); // nearest useful position distance per emitter per position (per parent, recomputed when needed changes)
    while(done<0 && depth<20000){
        vector<State>& cur=layers.back(); vector<State> nxt; nxt.reserve(cur.size()*64);
        unordered_set<unsigned long long> seen;
        for(int pi=0;pi<(int)cur.size();pi++){
            const State& s=cur[pi]; BS needed = pat & ~s.board;
            // distance table: for each emitter e and position p, 1 if line has needed cells
            int useful[6][80]; for(int e=0;e<6;e++)for(int p=0;p<G.M;p++) useful[e][p]=(beamneeded(G,e,p,needed)?1:0);
            for(int e=0;e<6;e++){ // near[e][p] = ring distance to nearest useful position
                for(int p=0;p<G.M;p++){int best=G.M; for(int q=0;q<G.M;q++) if(useful[e][q]) best=min(best,G.rd(p,q)); near[e*G.M+p]=best;}
            }
            for(int mv=0;mv<4096;mv++){
                State t=s; t.parent=pi; t.mv=mv; int m=mv; bool bad=false;
                for(int e=0;e<6;e++){int o=m&3; m>>=2; if(o==1)t.pos[e]=(t.pos[e]+1)%G.M; else if(o==2)t.pos[e]=(t.pos[e]+G.M-1)%G.M; else if(o==3)t.act^=(1<<e);}
                BS c1,c2,c3; for(int e=0;e<6;e++) if(t.act>>e&1){const BS&b=G.beam[e][t.pos[e]]; c3|=c2&b; c2|=c1&b; c1|=b;}
                BS created=c2&~c3; BS destroyed=c3;
                if((created&~pat).any()) continue;           // stray
                if((destroyed&t.board).any()) continue;      // destroying our matter
                BS nb=(t.board|created)&~destroyed;
                t.copies=s.copies;
                if((nb&pat)==pat){ t.copies++; nb&=~pat; }
                t.board=nb;
                // dedupe
                unsigned long long h=t.act; for(int e=0;e<6;e++) h=h*131+t.pos[e]; h=h*1000003+t.copies; 
                for(int w=0;w<8;w++){ unsigned long long wv=0; for(int b=0;b<64;b++) if(t.board[w*64+b]) wv|=1ULL<<b; h=h*1000000007ULL+wv; }
                if(!seen.insert(h).second) continue;
                // eval
                int donec=popc(t.board&pat); BS need2=pat&~t.board;
                int pot=0, dsum=0;
                for(int e=0;e<6;e++){ int onl=popc(G.beam[e][t.pos[e]]&need2); pot += (t.act>>e&1)? 3*onl : onl; dsum+=near[e*G.M+t.pos[e]]; }
                t.score = t.copies*100000 + donec*300 + pot*4 - dsum*3;
                nxt.push_back(t);
                if(t.copies==c.need){ done=(int)nxt.size()-1; }
            }
            if(done>=0) break;
        }
        if(nxt.empty()) return "";
        if(done<0 && (int)nxt.size()>W){ nth_element(nxt.begin(), nxt.begin()+W, nxt.end(), [](const State&a,const State&b){return a.score>b.score;}); nxt.resize(W); }
        layers.push_back(move(nxt)); depth++;
    }
    if(done<0) return "";
    // reconstruct
    vector<int> mvs; int li=layers.size()-1, si=done;
    while(li>0){ mvs.push_back(layers[li][si].mv); si=layers[li][si].parent; li--; }
    reverse(mvs.begin(),mvs.end()); string out;
    for(int mv:mvs){ int m=mv; for(int e=0;e<6;e++){ out+=INS[m&3]; m>>=2; out+= (e==5?'\n':' ');} }
    outlines=mvs.size(); return out;
}
bool beamneeded(const Geo&G,int e,int p,const BS&needed){ return (G.beam[e][p]&needed).any(); }

int main(int argc,char**argv){
    if(argc<3){fprintf(stderr,"usage\n");return 1;}
    int W0=argc>3?atoi(argv[3]):64; int TH=argc>4?atoi(argv[4]):8; double budget=argc>5?atof(argv[5]):20.0; int Wmax=argc>6?atoi(argv[6]):4096;
    ifstream in(argv[1]); int n; in>>n; vector<Case> cs(n);
    for(auto&c:cs){ in>>c.R>>c.rows>>c.cols>>c.need; c.pat.resize(c.rows); for(auto&r:c.pat) in>>r; }
    vector<string> res(n); vector<long long> lines(n,0); atomic<int> idx(0);
    vector<thread> th; for(int t=0;t<TH;t++) th.emplace_back([&]{ for(;;){ int i=idx++; if(i>=n)break;
        auto t0=chrono::steady_clock::now(); double spent=0, last=0; long long bestl=LLONG_MAX; string bests;
        for(int W=W0; W<=Wmax; W*=2){
            auto t1=chrono::steady_clock::now(); long long l=0; string r=solve(cs[i],W,l);
            last=chrono::duration<double>(chrono::steady_clock::now()-t1).count(); spent=chrono::duration<double>(chrono::steady_clock::now()-t0).count();
            if(!r.empty() && l<bestl){bestl=l; bests=r;}
            if(spent + last*2.2 > budget) break;
        }
        res[i]=bests; lines[i]=(bestl==LLONG_MAX?0:bestl); } });
    for(auto&t:th)t.join();
    long long tot=0; int fail=0; ofstream out(argv[2]);
    for(int i=0;i<n;i++){ if(res[i].empty()){fail++; out<<"FAIL\n";} else {out<<res[i];} if(i+1<n) out<<"\n"; tot+=lines[i]; }
    fprintf(stderr,"%s: score %lld fails %d (anytime W0=%d budget=%.0fs)\n",argv[1],tot,fail,W0,budget);
}
