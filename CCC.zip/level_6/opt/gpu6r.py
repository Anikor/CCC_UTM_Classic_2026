#!/usr/bin/env python3
"""gpu6 with the 'never destroy built pattern cells' prune removed (the real rules allow it).
  python gpu6r.py test <W>                    # A/B vs original on converged medium + long e/l cases
  python gpu6r.py run  <f> <W> <stopHHMM>     # whole file f in e/l/m, longest first -> x_<f>R<W>.out"""
import sys, time
import numpy as np
import cupy as cp
import gpu6snap as g

ORIG_SRC = g.SRC
PRUNE = 'if (c3[k] & bd) bad = true;'
assert g.SRC.count(PRUNE) == 1
RELAX_SRC = g.SRC.replace(PRUNE, '')
MODE = {'relax': True}
_mods = {}
def getmod2(NWP, NWA):
    key = (NWP, NWA, MODE['relax'])
    if key not in _mods:
        m = cp.RawModule(code=RELAX_SRC if MODE['relax'] else ORIG_SRC,
                         options=('-DNWP=%d' % NWP, '-DNWA=%d' % NWA, '-std=c++14'))
        _mods[key] = (m.get_function('expand'), m.get_function('compact'), m.get_function('materialize'), m.get_function('nearK'))
    return _mods[key]
g.getmod = getmod2

def solve(case, W, relax):
    MODE['relax'] = relax
    return g.solve(case, W, 4.0)

FID = {'e': '4-enormous', 'l': '3-large', 'm': '2-medium'}
if __name__ == '__main__':
    if sys.argv[1] == 'test':
        W = int(sys.argv[2]); tests = []
        cs = g.parse('../input/in_level-6_2-medium.txt'); best = g.refl('w_2-medium.out')
        tests += [('m', cs[i], best[i], i) for i in sorted([i for i, c in enumerate(cs) if c[3] >= 8 and c[0] >= 4], key=lambda i: -best[i])[:12]]
        for f in 'el':
            cs = g.parse('../input/in_level-6_%s.txt' % FID[f]); best = g.refl('w_%s.out' % FID[f])
            tests += [(f, cs[i], best[i], i) for i in sorted(range(len(cs)), key=lambda i: -best[i])[:6]]
        tot = {}
        for f, c, b, i in tests:
            a = solve(c, W, False); r = solve(c, W, True)
            la = len(a) if a else 999; lr = len(r) if r else 999
            t = tot.setdefault(f, [0, 0, 0]); t[0] += la; t[1] += lr; t[2] += b
            print('%s case %d need %d: orig %d  relaxed %d  (best %d)' % (f, i, c[3], la, lr, b), flush=True)
        print('TOTAL', tot, flush=True)
    else:
        f, W, stop = sys.argv[2], int(sys.argv[3]), sys.argv[4]
        cs = g.parse('../input/in_level-6_%s.txt' % FID[f]); best = g.refl('w_%s.out' % FID[f])
        res = [None] * len(cs); lastw = 0
        for i in sorted(range(len(cs)), key=lambda i: -best[i]):
            if time.strftime('%H%M', time.gmtime()) >= stop: break
            r = solve(cs[i], W, True); res[i] = r
            print('%s case %d: %s (best %d)' % (f, i, len(r) if r else 'FAIL', best[i]), file=sys.stderr, flush=True)
            if time.time() - lastw > 20: g.writeout('x_%sR%d.out' % (f, W), res); lastw = time.time()
        g.writeout('x_%sR%d.out' % (f, W), res)
