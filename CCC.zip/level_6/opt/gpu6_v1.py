#!/usr/bin/env python3
"""GPU beam search for CCC42 level 6 (mirrors bs6s.cpp, with board&=pat dedupe).
usage: python gpu6.py <in> <out> W [first_case] [ncases] [K_factor]
Writes <out> incrementally (FAIL for unsolved/unfinished cases)."""
import sys, os, time
import numpy as np
import cupy as cp

def parse(path):
    L = [l.rstrip('\n').rstrip('\r') for l in open(path)]
    i = 0; n = int(L[i]); i += 1
    cases = []
    for _ in range(n):
        while L[i].strip() == '': i += 1
        R, rows, cols, cnt = map(int, L[i].split()); i += 1
        pat = L[i:i+rows]; i += rows
        cases.append((R, rows, cols, cnt, pat))
    return cases

D = [(0,2),(1,1),(1,-1),(0,-2),(-1,-1),(-1,1)]
NBd = [(0,2),(0,-2),(1,1),(1,-1),(-1,1),(-1,-1)]

def geo(R):
    rows = 2*R+1; cols = 4*R+1
    idg = [[-1]*cols for _ in range(rows)]
    ncell = 0
    for i in range(rows):
        off = abs(i-R)
        for j in range(off, cols-off, 2):
            b = (i == 0 or i == rows-1 or j == off or j == cols-1-off)
            if not b: idg[i][j] = ncell; ncell += 1
    ring = []
    for t in range(R): ring.append((0, R+2*t))
    for t in range(R): ring.append((t, 3*R+t))
    for t in range(R): ring.append((R+t, 4*R-t))
    for t in range(R): ring.append((2*R, 3*R-2*t))
    for t in range(R): ring.append((2*R-t, R-t))
    for t in range(R): ring.append((R-t, t))
    M = len(ring)
    start = [5*R, 0, R, 2*R, 3*R, 4*R]
    beam = [[None]*M for _ in range(6)]
    for e in range(6):
        for p in range(M):
            y = ring[p][0]+D[e][0]; x = ring[p][1]+D[e][1]; cells = []
            while 0 <= y < rows and 0 <= x < cols:
                if idg[y][x] >= 0: cells.append((y, x))
                y += D[e][0]; x += D[e][1]
            beam[e][p] = cells
    return rows, cols, idg, ring, M, start, beam

OFFSET = 8192
NBK = 1 << 21

SRC = r'''
typedef unsigned long long u64;
#define NEG_INF (-2147483647-1)
#define OFFSET @OFFSET@
#define NBK @NBK@

__device__ __forceinline__ u64 fmix(u64 x){ x^=x>>33; x*=0xff51afd7ed558ccdULL; x^=x>>33; x*=0xc4ceb9fe1a85ec53ULL; x^=x>>33; return x; }

__device__ __forceinline__ bool child(int w, int mv, int M, const unsigned char* __restrict__ Ppos, const int* __restrict__ Pact,
    const u64* __restrict__ Pbrd, const u64* __restrict__ BP, const u64* __restrict__ BA, const u64* __restrict__ PM,
    int* pos, int& act, u64* nb, bool& full)
{
    act = Pact[w]; int m = mv;
    #pragma unroll
    for (int e=0;e<6;e++){ int p = Ppos[w*6+e]; int o = m&3; m >>= 2;
        if (o==1){ p++; if (p==M) p=0; } else if (o==2){ p--; if (p<0) p=M-1; } else if (o==3) act ^= (1<<e);
        pos[e] = p; }
    u64 c1[NWP], c2[NWP], c3[NWP], a1[NWA], a2[NWA], a3[NWA];
    #pragma unroll
    for (int k=0;k<NWP;k++){ c1[k]=0; c2[k]=0; c3[k]=0; }
    #pragma unroll
    for (int k=0;k<NWA;k++){ a1[k]=0; a2[k]=0; a3[k]=0; }
    #pragma unroll
    for (int e=0;e<6;e++) if ((act>>e)&1) {
        const u64* bp = BP + (size_t)(e*M+pos[e])*NWP; const u64* ba = BA + (size_t)(e*M+pos[e])*NWA;
        #pragma unroll
        for (int k=0;k<NWP;k++){ u64 b = __ldg(bp+k); c3[k] |= c2[k]&b; c2[k] |= c1[k]&b; c1[k] |= b; }
        #pragma unroll
        for (int k=0;k<NWA;k++){ u64 b = __ldg(ba+k); a3[k] |= a2[k]&b; a2[k] |= a1[k]&b; a1[k] |= b; }
    }
    bool bad = false;
    #pragma unroll
    for (int k=0;k<NWA;k++) if (a2[k] & ~a3[k]) bad = true;
    full = true;
    #pragma unroll
    for (int k=0;k<NWP;k++){ u64 bd = Pbrd[(size_t)w*NWP+k]; if (c3[k] & bd) bad = true;
        nb[k] = (bd | (c2[k] & ~c3[k])) & ~c3[k]; if (nb[k] != PM[k]) full = false; }
    return !bad;
}

__device__ __forceinline__ int evalc(int w, int M, const int* pos, int act, const u64* nb, int cop,
    const u64* __restrict__ BP, const unsigned char* __restrict__ nearT)
{
    int donec = 0;
    #pragma unroll
    for (int k=0;k<NWP;k++) donec += __popcll(nb[k]);
    int pot = 0, dsum = 0;
    #pragma unroll
    for (int e=0;e<6;e++){ const u64* bp = BP + (size_t)(e*M+pos[e])*NWP; int onl = 0;
        #pragma unroll
        for (int k=0;k<NWP;k++) onl += __popcll(__ldg(bp+k) & ~nb[k]);
        pot += ((act>>e)&1) ? 3*onl : onl; dsum += nearT[((size_t)w*6+e)*M + pos[e]]; }
    return cop*100000 + donec*300 + pot*4 - dsum*3;
}

extern "C" __global__ void expand(const int Wc, const int M, const int need,
    const unsigned char* __restrict__ Ppos, const int* __restrict__ Pact, const int* __restrict__ Pcop,
    const u64* __restrict__ Pbrd, const unsigned char* __restrict__ nearT,
    const u64* __restrict__ BP, const u64* __restrict__ BA, const u64* __restrict__ PM,
    int* __restrict__ scores, int* __restrict__ hist, int* __restrict__ doneidx)
{
    long long idx = (long long)blockIdx.x * blockDim.x + threadIdx.x;
    int w = (int)(idx >> 12); int mv = (int)(idx & 4095);
    int score = NEG_INF; int bucket = -1;
    if (w < Wc) {
        int pos[6]; int act; u64 nb[NWP]; bool full;
        if (child(w, mv, M, Ppos, Pact, Pbrd, BP, BA, PM, pos, act, nb, full)) {
            int cop = Pcop[w];
            if (full) { cop++;
                #pragma unroll
                for (int k=0;k<NWP;k++) nb[k]=0; }
            score = evalc(w, M, pos, act, nb, cop, BP, nearT);
            if (cop == need) atomicMin(doneidx, (int)idx);
            bucket = score + OFFSET; if (bucket < 0) bucket = 0; if (bucket > NBK-1) bucket = NBK-1;
        }
        scores[idx] = score;
    }
    unsigned msk = __match_any_sync(0xffffffffu, bucket);
    int lane = threadIdx.x & 31;
    if (bucket >= 0 && lane == __ffs(msk)-1) atomicAdd(&hist[bucket], __popc(msk));
}

extern "C" __global__ void compact(const int* __restrict__ scores, const long long total, const int T, const int cntAbove,
    const int needT, int* __restrict__ ctr, int* __restrict__ sel)
{
    long long idx = (long long)blockIdx.x * blockDim.x + threadIdx.x;
    int s = (idx < total) ? scores[idx] : NEG_INF;
    int b = -1;
    if (s != NEG_INF) { b = s + OFFSET; if (b < 0) b = 0; if (b > NBK-1) b = NBK-1; }
    bool above = (b > T); bool eq = (b == T);
    unsigned ma = __ballot_sync(0xffffffffu, above);
    unsigned me = __ballot_sync(0xffffffffu, eq);
    int lane = threadIdx.x & 31;
    int bA = 0, bE = 0;
    if (lane == 0) { if (ma) bA = atomicAdd(&ctr[0], __popc(ma)); if (me) bE = atomicAdd(&ctr[1], __popc(me)); }
    bA = __shfl_sync(0xffffffffu, bA, 0); bE = __shfl_sync(0xffffffffu, bE, 0);
    unsigned lt = (1u << lane) - 1u;
    if (above) sel[bA + __popc(ma & lt)] = (int)idx;
    if (eq) { int r = bE + __popc(me & lt); if (r < needT) sel[cntAbove + r] = (int)idx; }
}

extern "C" __global__ void materialize(const int K, const int* __restrict__ sel, const int M,
    const unsigned char* __restrict__ Ppos, const int* __restrict__ Pact, const int* __restrict__ Pcop,
    const u64* __restrict__ Pbrd, const unsigned char* __restrict__ nearT,
    const u64* __restrict__ BP, const u64* __restrict__ BA, const u64* __restrict__ PM,
    unsigned char* __restrict__ Cpos, int* __restrict__ Cact, int* __restrict__ Ccop, u64* __restrict__ Cbrd,
    int* __restrict__ Cscore, u64* __restrict__ Chash, int* __restrict__ Cpar, int* __restrict__ Cmv)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x; if (i >= K) return;
    int idx = sel[i]; int w = idx >> 12; int mv = idx & 4095;
    int pos[6]; int act; u64 nb[NWP]; bool full;
    child(w, mv, M, Ppos, Pact, Pbrd, BP, BA, PM, pos, act, nb, full);
    int cop = Pcop[w];
    if (full) { cop++;
        #pragma unroll
        for (int k=0;k<NWP;k++) nb[k]=0; }
    int score = evalc(w, M, pos, act, nb, cop, BP, nearT);
    u64 key = (u64)act;
    #pragma unroll
    for (int e=0;e<6;e++){ Cpos[i*6+e] = (unsigned char)pos[e]; key |= ((u64)pos[e]) << (8+8*e); }
    u64 h = fmix(key ^ 0x9E3779B97F4A7C15ULL); h = fmix(h ^ ((u64)cop * 0x9E3779B97F4A7C15ULL));
    #pragma unroll
    for (int k=0;k<NWP;k++){ Cbrd[(size_t)i*NWP+k] = nb[k]; h = fmix(h ^ (nb[k] + 0x632BE59BD9B4E019ULL*(k+1))); }
    Cact[i] = act; Ccop[i] = cop; Cscore[i] = score; Chash[i] = h; Cpar[i] = w; Cmv[i] = mv;
}

extern "C" __global__ void nearK(const int Wc, const int M, const u64* __restrict__ Pbrd, const u64* __restrict__ BP,
    const u64* __restrict__ PM, unsigned char* __restrict__ nearT)
{
    int t = blockIdx.x * blockDim.x + threadIdx.x; if (t >= Wc*6) return;
    int w = t / 6, e = t % 6;
    u64 needed[NWP];
    #pragma unroll
    for (int k=0;k<NWP;k++) needed[k] = PM[k] & ~Pbrd[(size_t)w*NWP+k];
    u64 u0 = 0, u1 = 0;
    for (int q=0;q<M;q++){ bool use = false;
        #pragma unroll
        for (int k=0;k<NWP;k++) if (__ldg(BP + (size_t)(e*M+q)*NWP + k) & needed[k]) use = true;
        if (use) { if (q < 64) u0 |= 1ULL<<q; else u1 |= 1ULL<<(q-64); } }
    unsigned char* out = nearT + (size_t)t*M;
    if (!u0 && !u1) { for (int p=0;p<M;p++) out[p] = (unsigned char)M; return; }
    for (int p=0;p<M;p++){ int d;
        for (d=0; d<=M/2; d++){ int a = p+d; if (a>=M) a-=M; int b = p-d; if (b<0) b+=M;
            bool sa = (a<64) ? ((u0>>a)&1) : ((u1>>(a-64))&1);
            bool sb = (b<64) ? ((u0>>b)&1) : ((u1>>(b-64))&1);
            if (sa || sb) break; }
        out[p] = (unsigned char)d; }
}
'''.replace("@OFFSET@", str(OFFSET)).replace("@NBK@", str(NBK))

_mods = {}
def getmod(NWP, NWA):
    key = (NWP, NWA)
    if key not in _mods:
        m = cp.RawModule(code=SRC, options=('-DNWP=%d' % NWP, '-DNWA=%d' % NWA, '-std=c++14'))
        _mods[key] = (m.get_function('expand'), m.get_function('compact'), m.get_function('materialize'), m.get_function('nearK'))
    return _mods[key]

def tomask(bits, NW):
    a = np.zeros(NW, np.uint64)
    for b in bits: a[b >> 6] |= np.uint64(1) << np.uint64(b & 63)
    return a

INS = '-FBT'
MAXKF = 64
hist = None

def solve(case, W, KF=2.0, maxlayers=None):
    global hist
    R, rows, cols, need, pat = case
    rows_, cols_, idg, ring, M, start, beam = geo(R)
    plist = [(i, j) for i in range(rows) for j in range(cols) if pat[i][j] == 'M']
    pidx = {c: k for k, c in enumerate(plist)}
    pset = set(plist)
    alist = []; aset = set()
    for (i, j) in plist:
        for dy, dx in NBd:
            y, x = i+dy, j+dx
            if 0 <= y < rows and 0 <= x < cols and idg[y][x] >= 0 and (y, x) not in pset and (y, x) not in aset:
                aset.add((y, x)); alist.append((y, x))
    aidx = {c: k for k, c in enumerate(alist)}
    npat = len(plist); nadj = len(alist)
    NWP = max(1, (npat+63)//64); NWA = max(1, (nadj+63)//64)
    fexp, fcomp, fmat, fnear = getmod(NWP, NWA)
    bp = np.zeros((6, M, NWP), np.uint64); ba = np.zeros((6, M, NWA), np.uint64)
    for e in range(6):
        for p in range(M):
            bp[e, p] = tomask([pidx[c] for c in beam[e][p] if c in pidx], NWP)
            ba[e, p] = tomask([aidx[c] for c in beam[e][p] if c in aidx], NWA)
    BP = cp.asarray(bp.reshape(-1)); BA = cp.asarray(ba.reshape(-1))
    PM = cp.asarray(tomask(range(npat), NWP))
    if hist is None: hist = cp.zeros(NBK, cp.int32)
    Ppos = cp.asarray(np.array(start, np.uint8))
    Pact = cp.zeros(1, cp.int32); Pcop = cp.zeros(1, cp.int32); Pbrd = cp.zeros(NWP, cp.uint64)
    done = cp.zeros(1, cp.int32); ctr = cp.zeros(2, cp.int32)
    layers = []
    limit = 100 + 4*npat*need
    if maxlayers: limit = min(limit, maxlayers)
    depth = 0
    K = int(W*KF)
    while depth < limit:
        Wc = int(Pact.shape[0])
        nearT = cp.empty(Wc*6*M, cp.uint8)
        nt = Wc*6
        fnear(((nt+127)//128,), (128,), (np.int32(Wc), np.int32(M), Pbrd, BP, PM, nearT))
        total = Wc*4096
        scores = cp.empty(total, cp.int32)
        hist.fill(0); done.fill(2147483647)
        fexp((total//256,), (256,), (np.int32(Wc), np.int32(M), np.int32(need), Ppos, Pact, Pcop, Pbrd, nearT, BP, BA, PM,
                                     scores, hist, done))
        d = int(done.get()[0])
        if d != 2147483647:
            mvs = [d & 4095]; w = d >> 12
            for li in range(len(layers)-1, -1, -1):
                par, mva = layers[li]
                mvs.append(int(mva[w])); w = int(par[w])
            mvs.reverse()
            out = []
            for mv in mvs:
                m = mv; t = []
                for e in range(6): t.append(INS[m & 3]); m >>= 2
                out.append(' '.join(t))
            return out
        rc = cp.cumsum(hist[::-1])
        nvalid = int(rc[-1])
        if nvalid == 0: return None
        Kcur = K
        while True:
            Kp = min(Kcur, nvalid)
            j = int(cp.searchsorted(rc, Kp))
            T = NBK-1-j
            cntAbove = int(rc[j-1]) if j > 0 else 0
            needT = Kp - cntAbove
            ctr.fill(0)
            sel = cp.empty(Kp, cp.int32)
            fcomp(((total+255)//256,), (256,), (scores, np.int64(total), np.int32(T), np.int32(cntAbove), np.int32(needT), ctr, sel))
            Cpos = cp.empty(Kp*6, cp.uint8); Cact = cp.empty(Kp, cp.int32); Ccop = cp.empty(Kp, cp.int32)
            Cbrd = cp.empty(Kp*NWP, cp.uint64); Cscore = cp.empty(Kp, cp.int32); Chash = cp.empty(Kp, cp.uint64)
            Cpar = cp.empty(Kp, cp.int32); Cmv = cp.empty(Kp, cp.int32)
            fmat(((Kp+127)//128,), (128,), (np.int32(Kp), sel, np.int32(M), Ppos, Pact, Pcop, Pbrd, nearT, BP, BA, PM,
                                            Cpos, Cact, Ccop, Cbrd, Cscore, Chash, Cpar, Cmv))
            order = cp.argsort(Chash)
            hs = Chash[order]
            keep = cp.ones(Kp, dtype=cp.bool_)
            if Kp > 1: keep[1:] = hs[1:] != hs[:-1]
            uniq = order[keep]
            nu = int(uniq.shape[0])
            if nu >= W or Kp >= nvalid or Kcur >= MAXKF*W or Kcur*4 > (1 << 24): break
            Kcur *= 4
        del scores
        if nu > W:
            sc = Cscore[uniq]
            top = cp.argsort(-sc)[:W]
            uniq = uniq[top]
        Ppos = Cpos.reshape(Kp, 6)[uniq].reshape(-1)
        Pact = Cact[uniq]; Pcop = Ccop[uniq]
        Pbrd = Cbrd.reshape(Kp, NWP)[uniq].reshape(-1)
        layers.append((cp.asnumpy(Cpar[uniq]), cp.asnumpy(Cmv[uniq])))
        depth += 1
    return None

def writeout(path, res):
    s = []
    for r in res:
        s.append('FAIL' if r is None else '\n'.join(r))
    tmp = path + '.tmp'
    with open(tmp, 'w', newline='\n') as f: f.write('\n\n'.join(s) + '\n')
    os.replace(tmp, path)

def refl(fn):
    rb = [x for x in open(fn).read().replace(chr(13)+chr(10), chr(10)).split(chr(10)+chr(10)) if x.strip()]
    return [10**9 if 'FAIL' in x else len(x.strip().split(chr(10))) for x in rb]

def main():
    inp, outp, W = sys.argv[1], sys.argv[2], int(sys.argv[3])
    first = int(sys.argv[4]) if len(sys.argv) > 4 else 0
    cnt = int(sys.argv[5]) if len(sys.argv) > 5 else None
    KF = float(sys.argv[6]) if len(sys.argv) > 6 else 4.0
    cases = parse(inp)
    idxs = list(range(len(cases)))[first:(first+cnt if cnt else None)]
    ref = os.environ.get('ORDER_REF')
    if ref:
        rl = refl(ref)
        if len(rl) == len(cases): idxs.sort(key=lambda i: -rl[i])
    res = [None]*len(cases)
    t0 = time.time(); tot = 0; fails = 0; lastw = 0
    for n, i in enumerate(idxs):
        tc = time.time()
        r = solve(cases[i], W, KF)
        res[i] = r
        if r is None: fails += 1
        else: tot += len(r)
        print(f'case {i}: {len(r) if r else "FAIL"} lines  {time.time()-tc:.2f}s  (tot {tot}, fails {fails}, elapsed {time.time()-t0:.0f}s)', file=sys.stderr, flush=True)
        if time.time() - lastw > 20 or n == len(idxs)-1:
            writeout(outp, res); lastw = time.time()
    writeout(outp, res)
    print(f'{inp}: W={W} total {tot} fails {fails} time {time.time()-t0:.0f}s', file=sys.stderr, flush=True)

if __name__ == '__main__':
    main()
