// Level 6 (Nanofabricator optimization): tick-level beam search.
//   c++ -O2 -std=c++17 -o beam6 beam6.cpp
//   ./beam6 <in> <out> [beam_width=32] [time_limit_sec=600] [max_acting=3]
#include <bits/stdc++.h>
using namespace std;
typedef uint64_t u64;
const int NW = 7;  // 448 cells max (R=12 -> 397 interior)

struct BS { u64 w[NW]; };
static inline void bclr(BS &a) { memset(a.w, 0, sizeof a.w); }
static inline int bpop(const BS &a) { int c = 0; for (int i = 0; i < NW; i++) c += __builtin_popcountll(a.w[i]); return c; }
static inline bool bget(const BS &a, int i) { return (a.w[i >> 6] >> (i & 63)) & 1; }
static inline void bset(BS &a, int i) { a.w[i >> 6] |= 1ULL << (i & 63); }

struct Case { int R, rows, cols, need; vector<string> pat; };

struct Geo {
    int R, rows, cols, M, C;
    vector<vector<int>> id;             // cell id or -1
    vector<pair<int,int>> cells;        // id -> (i,j)
    vector<pair<int,int>> ring;
    int start[6];
    vector<array<BS, 80>> beam;         // [e][p]
    vector<vector<pair<int,int>>> opts; // cell -> (e,p)
    Geo(int R_) : R(R_) {
        rows = 2*R+1; cols = 4*R+1; M = 6*R;
        id.assign(rows, vector<int>(cols, -1));
        for (int i = 0; i < rows; i++) {
            int off = abs(i-R);
            for (int j = off; j < cols-off; j += 2) {
                bool border = i==0 || i==rows-1 || j==off || j==cols-1-off;
                if (!border) { id[i][j] = cells.size(); cells.push_back({i,j}); }
            }
        }
        C = cells.size();
        for (int t = 0; t < R; t++) ring.push_back({0, R+2*t});
        for (int t = 0; t < R; t++) ring.push_back({t, 3*R+t});
        for (int t = 0; t < R; t++) ring.push_back({R+t, 4*R-t});
        for (int t = 0; t < R; t++) ring.push_back({2*R, 3*R-2*t});
        for (int t = 0; t < R; t++) ring.push_back({2*R-t, R-t});
        for (int t = 0; t < R; t++) ring.push_back({R-t, t});
        int st[6] = {5*R, 0, R, 2*R, 3*R, 4*R};
        memcpy(start, st, sizeof st);
        static const int DR[6] = {0,1,1,0,-1,-1}, DC[6] = {2,1,-1,-2,-1,1};
        beam.assign(6, {});
        opts.assign(C, {});
        for (int e = 0; e < 6; e++) for (int p = 0; p < M; p++) {
            BS b; bclr(b);
            int y = ring[p].first + DR[e], x = ring[p].second + DC[e];
            while (y >= 0 && y < rows && x >= 0 && x < cols) {
                if (id[y][x] >= 0) { bset(b, id[y][x]); opts[id[y][x]].push_back({e,p}); }
                y += DR[e]; x += DC[e];
            }
            beam[e][p] = b;
        }
    }
    inline int dist(int p, int q) const { int f = (q-p+M)%M, b = (p-q+M)%M; return min(f,b); }
};

struct St {
    uint8_t pos[6]; uint8_t act; uint8_t copies;
    int32_t parent; uint16_t combo;
    int32_t score;
    BS board;
};

static vector<array<uint8_t,6>> combos; // 0 '-',1 F,2 B,3 T
static const char INS[4] = {'-','F','B','T'};

static void gen_combos(int maxActing) {
    combos.clear();
    for (int code = 0; code < 4096; code++) {
        array<uint8_t,6> c; int acting = 0;
        for (int e = 0; e < 6; e++) { c[e] = (code >> (2*e)) & 3; if (c[e]) acting++; }
        if (acting <= maxActing) combos.push_back(c);
    }
}

struct Params { int W = 32; double tlimit = 600; int maxActing = 3; double wmin = 30, wsum = 4; int frontier = 16; int wadj = 1500; };

// ---- simulate one tick, return new board & copies ----
static inline void step(const Geo &g, const uint8_t *pos, uint8_t act, const BS &board, const BS &pat, const BS &nbm,
                        BS &nb, bool &submitted) {
    BS a0, a1, sat; bclr(a0); bclr(a1); bclr(sat);
    for (int e = 0; e < 6; e++) if ((act >> e) & 1) {
        const BS &b = g.beam[e][pos[e]];
        for (int i = 0; i < NW; i++) { u64 c0 = a0.w[i] & b.w[i]; a0.w[i] ^= b.w[i]; u64 c1 = a1.w[i] & c0; a1.w[i] ^= c0; sat.w[i] |= c1; }
    }
    bool full = true, clean = true;
    for (int i = 0; i < NW; i++) {
        u64 ex2 = a1.w[i] & ~a0.w[i] & ~sat.w[i];
        u64 ge3 = sat.w[i] | (a1.w[i] & a0.w[i]);
        nb.w[i] = (board.w[i] | ex2) & ~ge3;
        if ((nb.w[i] & pat.w[i]) != pat.w[i]) full = false;
        if (nb.w[i] & nbm.w[i]) clean = false;
    }
    submitted = full && clean;
    if (submitted) for (int i = 0; i < NW; i++) nb.w[i] &= ~pat.w[i];
}

static vector<array<uint8_t,6>> greedy(const Geo &g, const Case &cs, const vector<int> &pm) {
    vector<array<uint8_t,6>> prog;
    int pos[6]; memcpy(pos, g.start, sizeof pos);
    auto fam = [](int e){ return e % 3; };
    for (int copy = 0; copy < cs.need; copy++) {
        for (int c : pm) {
            auto &o = g.opts[c];
            int best = INT_MAX, be1=0,bp1=0,be2=0,bp2=0;
            for (size_t a = 0; a < o.size(); a++) for (size_t b = a+1; b < o.size(); b++) {
                int e1=o[a].first,p1=o[a].second,e2=o[b].first,p2=o[b].second;
                if (e1==e2 || fam(e1)==fam(e2)) continue;
                int cost = max(g.dist(pos[e1],p1), g.dist(pos[e2],p2));
                if (cost < best) { best=cost; be1=e1; bp1=p1; be2=e2; bp2=p2; }
            }
            for (int k = 0; k < best; k++) {
                array<uint8_t,6> line{};
                for (auto [e,p] : {make_pair(be1,bp1), make_pair(be2,bp2)}) {
                    int f = (p-pos[e]+g.M)%g.M, b = (pos[e]-p+g.M)%g.M;
                    if (f==0) continue;
                    if (f <= b) { line[e]=1; pos[e]=(pos[e]+1)%g.M; } else { line[e]=2; pos[e]=(pos[e]+g.M-1)%g.M; }
                }
                prog.push_back(line);
            }
            array<uint8_t,6> t{}; t[be1]=3; t[be2]=3; prog.push_back(t); prog.push_back(t);
        }
    }
    return prog;
}

static int simulate(const Geo &g, const Case &cs, const vector<array<uint8_t,6>> &prog, const BS &pat, const BS &nbm) {
    uint8_t pos[6]; for (int e=0;e<6;e++) pos[e]=g.start[e];
    uint8_t act=0; BS board; bclr(board); int copies=0;
    for (auto &line : prog) {
        for (int e=0;e<6;e++) { if (line[e]==1) pos[e]=(pos[e]+1)%g.M; else if (line[e]==2) pos[e]=(pos[e]+g.M-1)%g.M; else if (line[e]==3) act^=1<<e; }
        BS nb; bool sub; step(g,pos,act,board,pat,nbm,nb,sub); board=nb; if (sub) copies++;
    }
    return copies;
}

static vector<array<uint8_t,6>> solve_case(const Case &cs, const Params &P, double deadline) {
    Geo g(cs.R);
    vector<int> pm; BS pat, nbm; bclr(pat); bclr(nbm);
    for (int i = 0; i < cs.rows; i++) for (int j = 0; j < cs.cols; j++) if (cs.pat[i][j]=='M') { int c = g.id[i][j]; if (c>=0) { pm.push_back(c); bset(pat,c);} }
    static const int NBR[6]={0,0,1,1,-1,-1}, NBC[6]={2,-2,1,-1,1,-1};
    for (int c : pm) { auto [i,j]=g.cells[c]; for (int d=0;d<6;d++){ int y=i+NBR[d],x=j+NBC[d]; if (y<0||y>=cs.rows||x<0||x>=cs.cols) continue; int k=g.id[y][x]; if (k>=0 && !bget(pat,k)) bset(nbm,k);} }
    int P_ = pm.size();
    auto base = greedy(g, cs, pm);
    if (P_ == 0) return base;

    // ---- beam search ----
    vector<vector<St>> levels;
    St s0{}; for (int e=0;e<6;e++) s0.pos[e]=g.start[e]; s0.act=0; s0.copies=0; s0.parent=-1; s0.combo=0; s0.score=0; bclr(s0.board);
    levels.push_back({s0});
    int maxDepth = (int)base.size() * 2 + 10;
    vector<St> cand; cand.reserve(levels[0].size()*combos.size()+1);
    int costE[6][80];
    int bestDepth = -1, bestIdx = -1;
    for (int d = 1; d <= maxDepth; d++) {
        if (chrono::duration<double>(chrono::steady_clock::now().time_since_epoch()).count() > deadline) break;
        cand.clear();
        const vector<St> &prev = levels.back();
        for (size_t si = 0; si < prev.size(); si++) {
            const St &s = prev[si];
            for (size_t ci = 0; ci < combos.size(); ci++) {
                const auto &cb = combos[ci];
                St n; memcpy(n.pos, s.pos, 6); n.act = s.act;
                bool skip = false;
                for (int e=0;e<6;e++) { if (cb[e]==1) n.pos[e]=(n.pos[e]+1)%g.M; else if (cb[e]==2) n.pos[e]=(n.pos[e]+g.M-1)%g.M; else if (cb[e]==3) n.act^=1<<e; }
                if (skip) continue;
                bool sub; step(g, n.pos, n.act, s.board, pat, nbm, n.board, sub);
                n.copies = s.copies + (sub?1:0);
                n.parent = si; n.combo = ci;
                // heuristic
                int done = 0, adj = 0, stray = 0;
                for (int i=0;i<NW;i++) { done += __builtin_popcountll(n.board.w[i] & pat.w[i]); adj += __builtin_popcountll(n.board.w[i] & nbm.w[i]); stray += __builtin_popcountll(n.board.w[i] & ~pat.w[i] & ~nbm.w[i]); }
                long progress = (long)n.copies * P_ + (n.copies < cs.need ? done : 0);
                long sc = progress * 1000 - adj * (long)P.wadj - stray * 20L;
                if (n.copies < cs.need) {
                    for (int e=0;e<6;e++) { int ina = ((n.act>>e)&1)?0:1; for (int p=0;p<g.M;p++) costE[e][p] = g.dist(n.pos[e],p) + ina; }
                    int cnt = 0; long sum = 0; int mn = INT_MAX;
                    for (int c : pm) {
                        if (bget(n.board, c)) continue;
                        int bf[3] = {INT_MAX,INT_MAX,INT_MAX};
                        for (auto [e,p] : g.opts[c]) { int v = costE[e][p]; if (v < bf[e%3]) bf[e%3] = v; }
                        int a=bf[0],b=bf[1],cc=bf[2];
                        if (a>b) swap(a,b); if (b>cc) swap(b,cc); if (a>b) swap(a,b);
                        int cellcost = b; // second smallest
                        sum += cellcost; if (cellcost < mn) mn = cellcost;
                        if (++cnt >= P.frontier) break;
                    }
                    // adjacent strays: need 3 beams (one per family) through the cell
                    if (adj) {
                        for (int i=0;i<NW;i++) { u64 m = n.board.w[i] & nbm.w[i]; while (m) { int c = i*64 + __builtin_ctzll(m); m &= m-1;
                            int bf[3] = {INT_MAX,INT_MAX,INT_MAX};
                            for (auto [e,p] : g.opts[c]) { int v = costE[e][p]; if (v < bf[e%3]) bf[e%3] = v; }
                            int cc = max(bf[0], max(bf[1], bf[2])); if (cc==INT_MAX) cc = 50;
                            sum += cc; if (cc < mn) mn = cc; } }
                    }
                    if (mn==INT_MAX) mn=0;
                    sc -= (long)(mn * P.wmin + sum * P.wsum);
                }
                n.score = (int32_t)max<long>(sc, INT_MIN/2);
                cand.push_back(n);
            }
        }
        if (cand.empty()) break;
        // select top W unique
        sort(cand.begin(), cand.end(), [](const St&a, const St&b){ return a.score > b.score; });
        vector<St> next; next.reserve(P.W);
        unordered_set<u64> seen; seen.reserve(P.W*4);
        for (auto &c : cand) {
            u64 h = 1469598103934665603ULL;
            for (int e=0;e<6;e++) h = (h ^ c.pos[e]) * 1099511628211ULL;
            h = (h ^ c.act) * 1099511628211ULL; h = (h ^ c.copies) * 1099511628211ULL;
            for (int i=0;i<NW;i++) h = (h ^ c.board.w[i]) * 1099511628211ULL;
            if (!seen.insert(h).second) continue;
            next.push_back(c);
            if ((int)next.size() >= P.W) break;
        }
        if (getenv("DBG")) { const St &b=next[0]; int done=0,adj=0,stray=0; for(int i=0;i<NW;i++){done+=__builtin_popcountll(b.board.w[i]&pat.w[i]);adj+=__builtin_popcountll(b.board.w[i]&nbm.w[i]);stray+=__builtin_popcountll(b.board.w[i]&~pat.w[i]&~nbm.w[i]);} fprintf(stderr,"d=%d best score=%d done=%d adj=%d stray=%d act=%02x pos=%d,%d,%d,%d,%d,%d cands=%zu\n",d,b.score,done,adj,stray,b.act,b.pos[0],b.pos[1],b.pos[2],b.pos[3],b.pos[4],b.pos[5],cand.size()); }
        levels.push_back(std::move(next));
        for (size_t i = 0; i < levels.back().size(); i++) if (levels.back()[i].copies >= cs.need) { bestDepth = d; bestIdx = i; break; }
        if (bestDepth >= 0) break;
        if (d >= (int)base.size()) break; // not better than greedy
    }
    if (bestDepth < 0) { fprintf(stderr, "FALLBACK R=%d need=%d cells=%d depth=%zu base=%zu bestcopies=%d\n", cs.R, cs.need, P_, levels.size()-1, base.size(), levels.back().empty()?-1:(int)levels.back()[0].copies); return base; }
    vector<array<uint8_t,6>> prog(bestDepth);
    int idx = bestIdx;
    for (int d = bestDepth; d >= 1; d--) { const St &s = levels[d][idx]; prog[d-1] = combos[s.combo]; idx = s.parent; }
    int got = simulate(g, cs, prog, pat, nbm);
    if (got != cs.need) { fprintf(stderr, "WARN: beam program invalid (%d != %d), using greedy\n", got, cs.need); return base; }
    return prog.size() < base.size() ? prog : base;
}

int main(int argc, char **argv) {
    if (argc < 3) { fprintf(stderr, "usage: %s <in> <out> [W] [tlimit] [maxActing] [wmin] [wsum] [frontier]\n", argv[0]); return 1; }
    Params P;
    if (argc > 3) P.W = atoi(argv[3]);
    if (argc > 4) P.tlimit = atof(argv[4]);
    if (argc > 5) P.maxActing = atoi(argv[5]);
    if (argc > 6) P.wmin = atof(argv[6]);
    if (argc > 7) P.wsum = atof(argv[7]);
    if (argc > 8) P.frontier = atoi(argv[8]);
    if (argc > 9) P.wadj = atoi(argv[9]);
    gen_combos(P.maxActing);
    ifstream in(argv[1]); string line; vector<string> L;
    while (getline(in, line)) { while (!line.empty() && (line.back()=='\r')) line.pop_back(); L.push_back(line); }
    size_t i = 0; int N = atoi(L[i++].c_str());
    vector<Case> cases(N);
    for (int k = 0; k < N; k++) {
        while (L[i].find_first_not_of(" \t") == string::npos) i++;
        Case &c = cases[k];
        sscanf(L[i++].c_str(), "%d %d %d %d", &c.R, &c.rows, &c.cols, &c.need);
        for (int r = 0; r < c.rows; r++) c.pat.push_back(L[i++]);
    }
    vector<vector<array<uint8_t,6>>> res(N);
    double t0 = chrono::duration<double>(chrono::steady_clock::now().time_since_epoch()).count();
    int threads = min(8, N);
    atomic<int> nextCase{0};
    atomic<long> total{0};
    vector<thread> pool;
    for (int t = 0; t < threads; t++) pool.emplace_back([&]{
        while (true) {
            int k = nextCase++; if (k >= N) break;
            double now = chrono::duration<double>(chrono::steady_clock::now().time_since_epoch()).count();
            double remaining = P.tlimit - (now - t0);
            int left = N - k; double share = remaining / max(1.0, ceil((double)left / threads));
            res[k] = solve_case(cases[k], P, now + max(0.5, share));
            total += res[k].size();
        }
    });
    for (auto &t : pool) t.join();
    ofstream out(argv[2]);
    for (int k = 0; k < N; k++) {
        if (k) out << "\n";
        for (auto &l : res[k]) { for (int e=0;e<6;e++) { if (e) out << ' '; out << INS[l[e]]; } out << "\n"; }
    }
    double t1 = chrono::duration<double>(chrono::steady_clock::now().time_since_epoch()).count();
    fprintf(stderr, "%s: %d cases, score %ld, %.1fs\n", argv[1], N, total.load(), t1 - t0);
    return 0;
}
