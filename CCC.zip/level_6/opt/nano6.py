#!/usr/bin/env python3
"""Level 6 (optimization) toolkit: geometry, simulator/validator, greedy baseline.
    python3 nano6.py solve <in> <out>      # greedy baseline
    python3 nano6.py score <in> <out>      # validate + score (lines)
"""
import sys
from collections import defaultdict

def parse(path):
    L = [l.rstrip('\n').rstrip('\r') for l in open(path)]
    i = 0
    n = int(L[i]); i += 1
    cases = []
    for _ in range(n):
        while L[i].strip() == '': i += 1
        R, rows, cols, cnt = map(int, L[i].split()); i += 1
        pat = L[i:i+rows]; i += rows
        cases.append((R, rows, cols, cnt, pat))
    return cases

class Geo:
    def __init__(s, R):
        s.R = R; rows = 2*R+1; cols = 4*R+1; s.rows=rows; s.cols=cols
        g = [['-']*cols for _ in range(rows)]
        for i in range(rows):
            off = abs(i-R)
            for j in range(off, cols-off, 2):
                border = i==0 or i==rows-1 or j==off or j==cols-1-off
                g[i][j] = '*' if border else 'O'
        s.g = g
        ring = []
        for t in range(R): ring.append((0, R+2*t))
        for t in range(R): ring.append((t, 3*R+t))
        for t in range(R): ring.append((R+t, 4*R-t))
        for t in range(R): ring.append((2*R, 3*R-2*t))
        for t in range(R): ring.append((2*R-t, R-t))
        for t in range(R): ring.append((R-t, t))
        s.ring = ring; s.M = len(ring)
        s.start = [5*R, 0, R, 2*R, 3*R, 4*R]
        s.D = [(0,2),(1,1),(1,-1),(0,-2),(-1,-1),(-1,1)]
        # beam cells for (emitter, ringpos)
        s.beam = {}
        for e in range(6):
            dr, dc = s.D[e]
            for p in range(s.M):
                y, x = ring[p]; cells = []
                y += dr; x += dc
                while 0 <= y < rows and 0 <= x < cols:
                    if g[y][x] in 'O': cells.append((y, x))
                    y += dr; x += dc
                s.beam[(e, p)] = cells
        s.cell_opts = defaultdict(list)   # cell -> [(e,p)]
        for (e, p), cells in s.beam.items():
            for c in cells: s.cell_opts[c].append((e, p))

NB = [(0,2),(0,-2),(1,1),(1,-1),(-1,1),(-1,-1)]

def simulate(geo, pat, prog, need=None, stop_at_need=False):
    """Returns (count, ok). ok=False if stray matter breaks anything (we only count)."""
    rows, cols = geo.rows, geo.cols
    board = [row[:] for row in geo.g]
    pm = [(i,j) for i in range(rows) for j in range(cols) if pat[i][j]=='M']
    pmset = set(pm)
    nb = set()
    for (i,j) in pm:
        for dr,dc in NB:
            c=(i+dr,j+dc)
            if c not in pmset and 0<=c[0]<rows and 0<=c[1]<cols and board[c[0]][c[1]] in 'OM': nb.add(c)
    pos = list(geo.start); act=[False]*6; count=0
    for line in prog:
        for e, ins in enumerate(line):
            if ins=='F': pos[e]=(pos[e]+1)%geo.M
            elif ins=='B': pos[e]=(pos[e]-1)%geo.M
            elif ins=='T': act[e]=not act[e]
        cnt = defaultdict(int)
        for e in range(6):
            if act[e]:
                for c in geo.beam[(e,pos[e])]: cnt[c]+=1
        for c,k in cnt.items():
            if k==2: board[c[0]][c[1]]='M'
            elif k>=3: board[c[0]][c[1]]='O'
        if all(board[i][j]=='M' for i,j in pm) and not any(board[i][j]=='M' for i,j in nb):
            count+=1
            for i,j in pm: board[i][j]='O'
    return count

def dist(geo, p, q):
    f=(q-p)%geo.M; b=(p-q)%geo.M
    return (f, 'F') if f<=b else (b, 'B')

def solve_case(R, rows, cols, need, pat):
    geo = Geo(R)
    pm = [(i,j) for i in range(rows) for j in range(cols) if pat[i][j]=='M']
    pos = list(geo.start); prog=[]
    fam = lambda e: e%3
    for _copy in range(need):
        for c in pm:
            opts = geo.cell_opts[c]
            best=None
            for a in range(len(opts)):
                for b in range(a+1,len(opts)):
                    (e1,p1),(e2,p2)=opts[a],opts[b]
                    if e1==e2 or fam(e1)==fam(e2): continue
                    d1,_=dist(geo,pos[e1],p1); d2,_=dist(geo,pos[e2],p2)
                    cost=max(d1,d2)
                    if best is None or cost<best[0]: best=(cost,e1,p1,e2,p2)
            cost,e1,p1,e2,p2=best
            for _ in range(cost):
                line=['-']*6
                for e,p in ((e1,p1),(e2,p2)):
                    d,dirc=dist(geo,pos[e],p)
                    if d>0:
                        line[e]=dirc; pos[e]=(pos[e]+(1 if dirc=='F' else -1))%geo.M
                prog.append(line)
            line=['-']*6; line[e1]='T'; line[e2]='T'; prog.append(line)
            line=['-']*6; line[e1]='T'; line[e2]='T'; prog.append(line)
    return prog, geo

def main():
    cmd, inp, outp = sys.argv[1:4]
    cases = parse(inp)
    if cmd=='solve':
        out=[]; total=0
        for (R,rows,cols,need,pat) in cases:
            prog, geo = solve_case(R,rows,cols,need,pat)
            got = simulate(geo, pat, prog)
            assert got==need, (got, need)
            total+=len(prog)
            out.append('\n'.join(' '.join(l) for l in prog))
        open(outp,'w').write('\n\n'.join(out)+'\n')
        print(f'{inp}: {len(cases)} cases, score {total}', file=sys.stderr)
    elif cmd=='score':
        blocks=[b for b in open(outp).read().replace('\r\n','\n').split('\n\n') if b.strip()]
        assert len(blocks)==len(cases), (len(blocks), len(cases))
        total=0; bad=0
        for (R,rows,cols,need,pat), b in zip(cases, blocks):
            prog=[l.split() for l in b.strip().split('\n')]
            got=simulate(Geo(R), pat, prog)
            if got!=need: bad+=1
            total+=len(prog)
        print(f'{outp}: score {total}, bad cases {bad}')
main()
