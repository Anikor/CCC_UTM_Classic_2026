#!/bin/bash
cd "/c/Users/Student 06/CCC_auto/games/ccc42/level_6/opt/"
PY="/c/Users/Student 06/AppData/Local/Programs/Python/Python312/python.exe"
W=$1; fl=$2
for it in 1 2 3 4 5 6 7 8; do
  RESUME=1 "$PY" -W ignore gpu6all.py $W $fl >> glog_all${fl}G$W.txt 2>&1 && break
done
