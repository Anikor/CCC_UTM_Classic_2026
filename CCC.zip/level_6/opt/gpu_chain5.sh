#!/bin/bash
cd "/c/Users/Student 06/CCC_auto/games/ccc42/level_6/opt/"
PY="/c/Users/Student 06/AppData/Local/Programs/Python/Python312/python.exe"
until grep -q "ALL DONE" glog_allG131072.txt 2>/dev/null; do sleep 2; done
"$PY" -W ignore gpu6all.py 262144 el > glog_allG262144.txt 2>&1
