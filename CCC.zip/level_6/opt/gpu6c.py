#!/usr/bin/env python3
"""gpu6 with a continuous copy weight: a copy is worth CW = 300*npat + CB instead of 100000, so states
one tick from completing compete with states that just completed (less greedy -> better repeat cycles).
  python gpu6c.py test  <W>                  # A/B vs original eval on 12 high-copy medium cases
  python gpu6c.py run   <f> <W> <stopHHMM>   # whole file f in e/l/m, longest first -> x_<f>K<W>.out"""
import sys, time
import numpy as np
import cupy as cp
import gpu6snap as g

ORIG_SRC = g.SRC
PATCHED = g.SRC.replace('return cop*100000 + donec*300', 'return cop*CWv + donec*300')
PATCHED = PATCHED.replace('__device__ __forceinline__ int evalc', 'extern "C" { __device__ int CWv; }\n__device__ __forceinline__ int evalc', 1)
assert PATCHED != ORIG_SRC and 'cop*CWv' in PATCHED
CUR = {'cw': 100000, 'cont': True}
_mods = {}
def getmod2(NWP, NWA):
    key = (NWP, NWA, CUR['cont'])
    if key not in _mods:
        _mods[key] = cp.RawModule(code=PATCHED if CUR['cont'] else ORIG_SRC,
                                  options=('-DNWP=%d' % NWP, '-DNWA=%d' % NWA, '-std=c++14'))
    m = _mods[key]
    if CUR['cont']:
        v = np.array([CUR['cw']], np.int32)
        m.get_global('CWv').copy_from_host(v.ctypes.data, 4)
    return (m.get_function('expand'), m.get_function('compact'), m.get_function('materialize'), m.get_function('nearK'))
g.getmod = getmod2

def solve(case, W, cont, CB=1000):
    npat = sum(r.count('M') for r in case[4])
    CUR['cont'] = cont; CUR['cw'] = 300 * npat + CB
    return g.solve(case, W, 4.0)

if __name__ == '__main__':
    mode = sys.argv[1]
    if mode == 'test':
        W = int(sys.argv[2])
        cs = g.parse('../input/in_level-6_2-medium.txt')
        best = g.refl('w_2-medium.out')
        pick = sorted([i for i, c in enumerate(cs) if c[3] >= 8 and c[0] >= 4], key=lambda i: -best[i])[:12]
        ta = tb = tw = 0
        for i in pick:
            a = solve(cs[i], W, False); b = solve(cs[i], W, True)
            la = len(a) if a else 999; lb = len(b) if b else 999
            ta += la; tb += lb; tw += best[i]
            print('case %d need %d: orig %d  cont %d  (best so far %d)' % (i, cs[i][3], la, lb, best[i]), flush=True)
        print('TOTAL orig %d cont %d best %d' % (ta, tb, tw), flush=True)
    else:
        f, W, stop = sys.argv[2], int(sys.argv[3]), sys.argv[4]
        fid = {'e': '4-enormous', 'l': '3-large', 'm': '2-medium'}[f]
        cs = g.parse('../input/in_level-6_%s.txt' % fid); best = g.refl('w_%s.out' % fid)
        res = [None] * len(cs); lastw = 0
        for i in sorted(range(len(cs)), key=lambda i: -best[i]):
            if time.strftime('%H%M', time.gmtime()) >= stop: break
            r = solve(cs[i], W, True); res[i] = r
            print('%s case %d: %s (best %d)' % (f, i, len(r) if r else 'FAIL', best[i]), file=sys.stderr, flush=True)
            if time.time() - lastw > 20: g.writeout('x_%sK%d.out' % (f, W), res); lastw = time.time()
        g.writeout('x_%sK%d.out' % (f, W), res)
