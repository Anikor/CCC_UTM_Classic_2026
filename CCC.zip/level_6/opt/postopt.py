#!/usr/bin/env python3
"""Local-search post-optimizer: python3 postopt.py <in> <candidate.out> <out>
Shortens each case's program (merge adjacent / skip-one lines, delete lines, drop needless moves),
accepting a change only if the reference simulator still yields exactly `need` submissions."""
import sys, time
_argv = sys.argv; sys.argv = ['x']
exec(open('nano6.py').read().replace('\nmain()\n', '\n'))
sys.argv = _argv

def ok(geo, pat, prog, need):
    return simulate(geo, pat, prog) == need

def can_merge(a, b):
    return all(x == '-' or y == '-' for x, y in zip(a, b))

def merged(a, b):
    return [x if x != '-' else y for x, y in zip(a, b)]

def optimize(geo, pat, prog, need, deadline):
    prog = [list(l) for l in prog]
    improved = True
    while improved and time.time() < deadline:
        improved = False
        # (1) merge adjacent lines
        i = 0
        while i < len(prog) - 1:
            if can_merge(prog[i], prog[i+1]):
                cand = prog[:i] + [merged(prog[i], prog[i+1])] + prog[i+2:]
                if ok(geo, pat, cand, need):
                    prog = cand; improved = True; continue
            i += 1
        # (3) merge lines i and i+2 (drop the middle one's separation: combine i and i+2, keep i+1 after)
        i = 0
        while i < len(prog) - 2:
            if can_merge(prog[i], prog[i+2]):
                cand = prog[:i] + [merged(prog[i], prog[i+2]), prog[i+1]] + prog[i+3:]
                if ok(geo, pat, cand, need):
                    prog = cand; improved = True; continue
                cand = prog[:i] + [prog[i+1], merged(prog[i], prog[i+2])] + prog[i+3:]
                if ok(geo, pat, cand, need):
                    prog = cand; improved = True; continue
            i += 1
        # (2) delete a line
        i = 0
        while i < len(prog):
            cand = prog[:i] + prog[i+1:]
            if ok(geo, pat, cand, need):
                prog = cand; improved = True; continue
            i += 1
        # (4) drop unnecessary moves/toggles (does not shorten by itself but enables merges)
        changed = False
        for i in range(len(prog)):
            for e in range(6):
                if prog[i][e] != '-':
                    old = prog[i][e]; prog[i][e] = '-'
                    if ok(geo, pat, prog, need):
                        changed = True
                    else:
                        prog[i][e] = old
        if changed:
            improved = True
    return prog

def main():
    inp, cand, outp = sys.argv[1:4]
    per_case = float(sys.argv[4]) if len(sys.argv) > 4 else 20.0
    cases = parse(inp)
    blocks = [b for b in open(cand).read().replace('\r\n', '\n').split('\n\n') if b.strip()]
    assert len(blocks) == len(cases), (len(blocks), len(cases))
    out = []; before = after = 0
    for idx, ((R, rows, cols, need, pat), b) in enumerate(zip(cases, blocks)):
        prog = [l.split() for l in b.strip().split('\n')]
        geo = Geo(R)
        before += len(prog)
        if not ok(geo, pat, prog, need):
            out.append(b.strip()); after += len(prog); continue
        new = optimize(geo, pat, prog, need, time.time() + per_case)
        if len(new) < len(prog) and ok(geo, pat, new, need):
            prog = new
        after += len(prog)
        out.append('\n'.join(' '.join(l) for l in prog))
        if idx % 20 == 0:
            print(f'  case {idx}/{len(cases)} running total {after}', file=sys.stderr, flush=True)
    open(outp, 'w').write('\n\n'.join(out) + '\n')
    print(f'{cand}: {before} -> {after}', file=sys.stderr)

main()
