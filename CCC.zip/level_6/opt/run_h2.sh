#!/bin/sh
cd "$(dirname "$0")"; I=../input/in_level-6_2-medium.txt
run() { name=$1; shift; ./h2solver $I h2_${name}_2-medium.out 128 2 0.1 128 "$@" 2>> h2_run.log; python3 nano6.py score $I h2_${name}_2-medium.out >> h2_run.log 2>&1; }
run a20w128 300 20 4 3 0 0
run a8i2d1  300 8 2 1 0 0
echo H2DONE2 >> h2_run.log
