#!/usr/bin/env python3
"""Targeted re-solve helpers.
  sub6.py pick    <in> <best.out> <k> <idx.txt>          # k cases with the longest programs
  sub6.py extract <in> <idx.txt> <sub_in.txt>             # subset input file
  sub6.py splice  <in> <idx.txt> <sub.out> <full.out>     # full-size candidate (FAIL elsewhere)
"""
import sys

def blocks_of(path):
    return [b for b in open(path).read().replace('\r\n', '\n').split('\n\n') if b.strip()]

def raw_cases(path):
    L = [l.rstrip('\r\n') for l in open(path)]
    n = int(L[0]); i = 1; out = []
    for _ in range(n):
        while L[i].strip() == '': i += 1
        rows = int(L[i].split()[1])
        out.append(L[i:i + rows + 1]); i += rows + 1
    return out

cmd = sys.argv[1]
if cmd == 'pick':
    inp, best, k, idxf = sys.argv[2:6]
    lens = [len(b.strip().split('\n')) for b in blocks_of(best)]
    idx = sorted(range(len(lens)), key=lambda i: -lens[i])[:int(k)]
    open(idxf, 'w').write('\n'.join(map(str, sorted(idx))) + '\n')
    print(f'picked {len(idx)} cases covering {sum(lens[i] for i in idx)} of {sum(lens)} lines')
elif cmd == 'extract':
    inp, idxf, outp = sys.argv[2:5]
    cs = raw_cases(inp); idx = [int(x) for x in open(idxf).read().split()]
    open(outp, 'w').write(f'{len(idx)}\n' + '\n\n'.join('\n'.join(cs[i]) for i in idx) + '\n')
elif cmd == 'splice':
    inp, idxf, subo, fullo = sys.argv[2:6]
    n = len(raw_cases(inp)); idx = [int(x) for x in open(idxf).read().split()]
    sb = blocks_of(subo); assert len(sb) == len(idx), (len(sb), len(idx))
    full = ['FAIL'] * n
    for i, b in zip(idx, sb): full[i] = b.strip()
    open(fullo, 'w').write('\n\n'.join(full) + '\n')
