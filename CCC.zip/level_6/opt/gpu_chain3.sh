#!/bin/bash
cd "/c/Users/Student 06/CCC_auto/games/ccc42/level_6/opt/"
PY="/c/Users/Student 06/AppData/Local/Programs/Python/Python312/python.exe"
until grep -q "total" glog_lG65536.txt 2>/dev/null; do sleep 2; done
ORDER_REF=x_eG65536.out "$PY" -W ignore gpu6.py ../input/in_level-6_4-enormous.txt x_eG262144.out 262144 > glog_eG262144.txt 2>&1
