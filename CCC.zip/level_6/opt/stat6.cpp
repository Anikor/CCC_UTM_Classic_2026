// Static-configuration constructor: find a set of active (emitter,pos) whose exactly-2 cells cover the
// pattern with nothing on adjacent cells; then hold still and emit one copy per tick.
//   ./stat6 <in> <out>   (cases without a static config get "FAIL")
#include <bits/stdc++.h>
using namespace std;
typedef bitset<512> BS;
struct Geo {
    int R, rows, cols, M; vector<pair<int,int>> ring; int start[6];
    vector<vector<int>> id; vector<vector<BS>> beam;
    int D[6][2] = {{0,2},{1,1},{1,-1},{0,-2},{-1,-1},{-1,1}};
    Geo(int R_):R(R_){
        rows=2*R+1; cols=4*R+1; id.assign(rows,vector<int>(cols,-1)); int n=0;
        for(int i=0;i<rows;i++){int off=abs(i-R); for(int j=off;j<=cols-1-off;j+=2){bool b=(i==0||i==rows-1||j==off||j==cols-1-off); if(!b) id[i][j]=n++;}}
        for(int t=0;t<R;t++) ring.push_back({0,R+2*t}); for(int t=0;t<R;t++) ring.push_back({t,3*R+t});
        for(int t=0;t<R;t++) ring.push_back({R+t,4*R-t}); for(int t=0;t<R;t++) ring.push_back({2*R,3*R-2*t});
        for(int t=0;t<R;t++) ring.push_back({2*R-t,R-t}); for(int t=0;t<R;t++) ring.push_back({R-t,t});
        M=ring.size(); int s[6]={5*R,0,R,2*R,3*R,4*R}; for(int e=0;e<6;e++)start[e]=s[e];
        beam.assign(6,vector<BS>(M));
        for(int e=0;e<6;e++)for(int p=0;p<M;p++){int y=ring[p].first+D[e][0],x=ring[p].second+D[e][1]; while(y>=0&&y<rows&&x>=0&&x<cols){ if(id[y][x]>=0) beam[e][p].set(id[y][x]); y+=D[e][0];x+=D[e][1];}}
    }
    int rd(int p,int q)const{int f=((q-p)%M+M)%M; return min(f,M-f);}
};
struct Case { int R,rows,cols,need; vector<string> pat; };

int main(int argc,char**argv){
    ifstream in(argv[1]); int n; in>>n; vector<Case> cs(n);
    for(auto&c:cs){ in>>c.R>>c.rows>>c.cols>>c.need; c.pat.resize(c.rows); for(auto&r:c.pat) in>>r; }
    ofstream out(argv[2]); long long tot=0; int found=0;
    for(int ci=0;ci<n;ci++){
        auto&c=cs[ci]; Geo G(c.R); BS pat, adj;
        for(int i=0;i<c.rows;i++)for(int j=0;j<c.cols;j++) if(c.pat[i][j]=='M') pat.set(G.id[i][j]);
        int NBd[6][2]={{0,2},{0,-2},{1,1},{1,-1},{-1,1},{-1,-1}};
        for(int i=0;i<c.rows;i++)for(int j=0;j<c.cols;j++) if(c.pat[i][j]=='M') for(auto&d:NBd){int y=i+d[0],x=j+d[1];
            if(y>=0&&y<c.rows&&x>=0&&x<c.cols&&G.id[y][x]>=0&&!pat[G.id[y][x]]) adj.set(G.id[y][x]);}
        vector<vector<int>> opt(6); // candidate positions per emitter (-1 = inactive)
        for(int e=0;e<6;e++){ opt[e].push_back(-1); for(int p=0;p<G.M;p++) if((G.beam[e][p]&pat).any()) opt[e].push_back(p); }
        int best=INT_MAX; int bp[6]; int cur[6];
        function<void(int,BS,BS,BS,int)> rec=[&](int e,BS c1,BS c2,BS c3,int md){
            if(md>=best) return;
            if(e==6){ BS x=c2&~c3; if((x&pat)==pat && !(x&adj).any()){best=md; memcpy(bp,cur,sizeof cur);} return; }
            for(int p:opt[e]){ cur[e]=p;
                if(p<0){ rec(e+1,c1,c2,c3,md); continue; }
                const BS&b=G.beam[e][p]; BS n3=c3|(c2&b), n2=c2|(c1&b), n1=c1|b;
                if((n3&pat).any()) continue;           // a pattern cell on >=3 beams can never be created
                rec(e+1,n1,n2,n3,max(md,G.rd(G.start[e],p)));
            }
        };
        rec(0,BS(),BS(),BS(),0);
        if(ci) out<<"\n";
        if(best==INT_MAX){ out<<"FAIL\n"; continue; }
        found++; vector<string> prog; int pos[6]; for(int e=0;e<6;e++)pos[e]=G.start[e];
        for(int t=0;t<best;t++){ string l; for(int e=0;e<6;e++){ char ch='-';
            if(bp[e]>=0 && pos[e]!=bp[e]){ int f=((bp[e]-pos[e])%G.M+G.M)%G.M; if(f<=G.M-f){ch='F';pos[e]=(pos[e]+1)%G.M;} else {ch='B';pos[e]=(pos[e]+G.M-1)%G.M;} }
            l+=ch; l+=(e==5?"":" "); } prog.push_back(l); }
        { string l; for(int e=0;e<6;e++){ l+=(bp[e]>=0?'T':'-'); l+=(e==5?"":" "); } prog.push_back(l); }
        for(int k=1;k<c.need;k++) prog.push_back("- - - - - -");
        for(auto&l:prog) out<<l<<"\n"; tot+=prog.size();
    }
    fprintf(stderr,"%s: static found %d/%d, lines in found cases %lld\n",argv[1],found,n,tot);
}
