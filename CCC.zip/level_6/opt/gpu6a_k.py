#!/usr/bin/env python3
"""gpu6 with BOTH solver-only prunes removed (real rule: a copy is collected when the pattern is full
AND no adjacent cell has matter; adjacent matter may exist in between and be destroyed by 3 beams).
State gets NWA extra words (adjacent-cell matter). Eval: -ADJPEN per adjacent matter cell.
  python gpu6a.py test <W> [cases like m167,e12,...]   # A/B list, every program validated by nano6.simulate
  python gpu6a.py run <f> <W> <stopHHMM> [out]         # whole file f in e/l/m, longest first -> x_<f>A.out
"""
import sys, os, time
import numpy as np
import cupy as cp
import gpu6snap as g

ADJPEN = int(os.environ.get('ADJPEN', '300'))
NEARADJ = int(os.environ.get('NEARADJ', '1'))

def rep(s, old, new, cnt=1):
    assert s.count(old) == cnt, (old, s.count(old))
    return s.replace(old, new)

S = g.SRC
# child(): carry adjacent-matter words, no prunes
S = rep(S, '    int* pos, int& act, u64* nb, bool& full)\n{',
           '    const u64* __restrict__ Padj, int* pos, int& act, u64* nb, u64* na, bool& full)\n{')
S = rep(S, '    for (int k=0;k<NWA;k++) if (a2[k] & ~a3[k]) bad = true;',
           '    for (int k=0;k<NWA;k++) na[k] = (Padj[(size_t)w*NWA+k] | (a2[k] & ~a3[k])) & ~a3[k];')
S = rep(S, 'if (c3[k] & bd) bad = true;', '')
S = rep(S, '    return !bad;\n}', '    #pragma unroll\n    for (int k=0;k<NWA;k++) if (na[k]) full = false;\n    return !bad;\n}')
# eval penalty
S = rep(S, 'const u64* nb, int cop,', 'const u64* nb, const u64* na, int cop,')
S = rep(S, '    return cop*100000 + donec*300 + pot*4 - dsum*3;',
           '    int adjc = 0;\n    #pragma unroll\n    for (int k=0;k<NWA;k++) adjc += __popcll(na[k]);\n'
           '    return cop*100000 + donec*300 + pot*4 - dsum*3 - adjc*ADJPEN;')
# kernels: parent adj array, child adj array, hash
S = rep(S, 'const u64* __restrict__ Pbrd, const unsigned char* __restrict__ nearT,',
           'const u64* __restrict__ Pbrd, const u64* __restrict__ Padj, const unsigned char* __restrict__ nearT,', 2)
S = rep(S, 'int pos[6]; int act; u64 nb[NWP]; bool full;', 'int pos[6]; int act; u64 nb[NWP]; u64 na[NWA]; bool full;', 2)
S = rep(S, 'child(w, mv, M, Ppos, Pact, Pbrd, BP, BA, PM, pos, act, nb, full)',
           'child(w, mv, M, Ppos, Pact, Pbrd, BP, BA, PM, Padj, pos, act, nb, na, full)', 2)
S = rep(S, 'evalc(w, M, pos, act, nb, cop, BP, nearT)', 'evalc(w, M, pos, act, nb, na, cop, BP, nearT)', 2)
S = rep(S, 'u64* __restrict__ Cbrd,', 'u64* __restrict__ Cbrd, u64* __restrict__ Cadj,')
S = rep(S, 'for (int k=0;k<NWP;k++) Cbrd[(size_t)i*NWP+k] = 0;',
           'for (int k=0;k<NWP;k++) Cbrd[(size_t)i*NWP+k] = 0;\n        for (int k=0;k<NWA;k++) Cadj[(size_t)i*NWA+k] = 0;')
S = rep(S, 'h = fmix(h ^ (nb[k] + 0x632BE59BD9B4E019ULL*(k+1))); }',
           'h = fmix(h ^ (nb[k] + 0x632BE59BD9B4E019ULL*(k+1))); }\n'
           '    for (int k=0;k<NWA;k++){ Cadj[(size_t)i*NWA+k] = na[k]; h = fmix(h ^ (na[k] + 0x2545F4914F6CDD1DULL*(k+1))); }')
# nearK: lines through adjacent matter are also "useful" (it must be destroyed before collecting)
S = rep(S, 'const u64* __restrict__ PM, unsigned char* __restrict__ nearT)',
           'const u64* __restrict__ PM, const u64* __restrict__ Padj, const u64* __restrict__ BA, unsigned char* __restrict__ nearT)')
if NEARADJ == 1:   # always: lines through adjacent matter are useful (biased: rewards making adj matter)
    S = rep(S, '        for (int k=0;k<NWP;k++) if (__ldg(BP + (size_t)(e*M+q)*NWP + k) & needed[k]) use = true;',
               '        for (int k=0;k<NWP;k++) if (__ldg(BP + (size_t)(e*M+q)*NWP + k) & needed[k]) use = true;\n'
               '        for (int k=0;k<NWA;k++) if (__ldg(BA + (size_t)(e*M+q)*NWA + k) & Padj[(size_t)w*NWA+k]) use = true;')
elif NEARADJ == 2:  # only once the pattern is full (cleanup phase)
    S = rep(S, '        for (int k=0;k<NWP;k++) if (__ldg(BP + (size_t)(e*M+q)*NWP + k) & needed[k]) use = true;',
               '        for (int k=0;k<NWP;k++) if (__ldg(BP + (size_t)(e*M+q)*NWP + k) & needed[k]) use = true;\n'
               '        if (!anyneed) for (int k=0;k<NWA;k++) if (__ldg(BA + (size_t)(e*M+q)*NWA + k) & Padj[(size_t)w*NWA+k]) use = true;')
    S = rep(S, '    u64 u0 = 0, u1 = 0;\n', '    bool anyneed = false;\n    for (int k=0;k<NWP;k++) if (needed[k]) anyneed = true;\n    u64 u0 = 0, u1 = 0;\n')
SRC = S

_mods = {}
def getmod(NWP, NWA):
    key = (NWP, NWA)
    if key not in _mods:
        m = cp.RawModule(code=SRC, options=('-DNWP=%d' % NWP, '-DNWA=%d' % NWA, '-DADJPEN=%d' % ADJPEN, '-std=c++14'))
        _mods[key] = (m.get_function('expand'), m.get_function('compact'), m.get_function('materialize'), m.get_function('nearK'))
    return _mods[key]

# validator: nano6.simulate (nano6.py calls main() at import, so exec it without that line)
_nsrc = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'nano6.py')).read()
_nsrc = _nsrc[:_nsrc.rindex('\nmain()')]
NANO = {'__name__': 'nano6x'}
exec(compile(_nsrc, 'nano6.py', 'exec'), NANO)
def valid(case, prog):
    R, rows, cols, need, pat = case
    return NANO['simulate'](NANO['Geo'](R), pat, [l.split() for l in prog]) == need

hist = None
def solve(case, W, KF=4.0, maxlayers=None):
    global hist
    NBK = g.NBK; MAXKF = g.MAXKF; INS = g.INS
    R, rows, cols, need, pat = case
    rows_, cols_, idg, ring, M, start, beam = g.geo(R)
    plist = [(i, j) for i in range(rows) for j in range(cols) if pat[i][j] == 'M']
    pidx = {c: k for k, c in enumerate(plist)}
    pset = set(plist)
    alist = []; aset = set()
    for (i, j) in plist:
        for dy, dx in g.NBd:
            y, x = i+dy, j+dx
            if 0 <= y < rows and 0 <= x < cols and idg[y][x] >= 0 and (y, x) not in pset and (y, x) not in aset:
                aset.add((y, x)); alist.append((y, x))
    aidx = {c: k for k, c in enumerate(alist)}
    npat = len(plist); nadj = len(alist)
    NWP = max(1, (npat+63)//64); NWA = max(1, (nadj+63)//64)
    fexp, fcomp, fmat, fnear = getmod(NWP, NWA)
    bp = np.zeros((6, M, NWP), np.uint64); ba = np.zeros((6, M, NWA), np.uint64)
    for e in range(6):
        for p in range(M):
            bp[e, p] = g.tomask([pidx[c] for c in beam[e][p] if c in pidx], NWP)
            ba[e, p] = g.tomask([aidx[c] for c in beam[e][p] if c in aidx], NWA)
    BP = cp.asarray(bp.reshape(-1)); BA = cp.asarray(ba.reshape(-1))
    PM = cp.asarray(g.tomask(range(npat), NWP))
    if hist is None: hist = cp.zeros(NBK, cp.int32)
    Ppos = cp.asarray(np.array(start, np.uint8))
    Pact = cp.zeros(1, cp.int32); Pcop = cp.zeros(1, cp.int32); Pbrd = cp.zeros(NWP, cp.uint64)
    Padj = cp.zeros(NWA, cp.uint64)
    done = cp.zeros(1, cp.int32); ctr = cp.zeros(2, cp.int32)
    layers = []
    limit = 100 + 4*npat*need
    if maxlayers: limit = min(limit, maxlayers)
    depth = 0
    K = int(W*KF)
    while depth < limit:
        Wc = int(Pact.shape[0])
        nearT = cp.empty(Wc*6*M, cp.uint8)
        nt = Wc*6
        fnear(((nt+127)//128,), (128,), (np.int32(Wc), np.int32(M), Pbrd, BP, PM, Padj, BA, nearT))
        total = Wc*4096
        scores = cp.empty(total, cp.int32)
        hist.fill(0); done.fill(2147483647)
        fexp((total//256,), (256,), (np.int32(Wc), np.int32(M), np.int32(need), Ppos, Pact, Pcop, Pbrd, Padj, nearT, BP, BA, PM,
                                     scores, hist, done))
        d = int(done.get()[0])
        if d != 2147483647:
            mvs = [d & 4095]; w = d >> 12
            for li in range(len(layers)-1, -1, -1):
                par, mva = layers[li]
                mvs.append(int(mva[w])); w = int(par[w])
            mvs.reverse()
            out = []
            for mv in mvs:
                m = mv; t = []
                for e in range(6): t.append(INS[m & 3]); m >>= 2
                out.append(' '.join(t))
            return out
        rc = cp.cumsum(hist[::-1])
        nvalid = int(rc[-1])
        if nvalid == 0: return None
        Kcur = K
        while True:
            Kp = min(Kcur, nvalid)
            j = int(cp.searchsorted(rc, Kp))
            T = NBK-1-j
            cntAbove = int(rc[j-1]) if j > 0 else 0
            needT = Kp - cntAbove
            ctr.fill(0)
            sel = cp.full(Kp, -1, cp.int32)
            fcomp(((total+255)//256,), (256,), (scores, np.int64(total), np.int32(T), np.int32(cntAbove), np.int32(needT), ctr, sel))
            Cpos = cp.empty(Kp*6, cp.uint8); Cact = cp.empty(Kp, cp.int32); Ccop = cp.empty(Kp, cp.int32)
            Cbrd = cp.empty(Kp*NWP, cp.uint64); Cadj = cp.empty(Kp*NWA, cp.uint64)
            Cscore = cp.empty(Kp, cp.int32); Chash = cp.empty(Kp, cp.uint64)
            Cpar = cp.empty(Kp, cp.int32); Cmv = cp.empty(Kp, cp.int32)
            fmat(((Kp+127)//128,), (128,), (np.int32(Kp), np.int32(Wc), sel, np.int32(M), Ppos, Pact, Pcop, Pbrd, Padj, nearT, BP, BA, PM,
                                            Cpos, Cact, Ccop, Cbrd, Cadj, Cscore, Chash, Cpar, Cmv))
            order = cp.argsort(Chash)
            hs = Chash[order]
            keep = cp.ones(Kp, dtype=cp.bool_)
            if Kp > 1: keep[1:] = hs[1:] != hs[:-1]
            uniq = order[keep]
            nu = int(uniq.shape[0])
            if nu >= W or Kp >= nvalid or Kcur >= MAXKF*W or Kcur*4 > (1 << 24): break
            Kcur *= 4
        del scores
        if bool((Cscore[uniq] == -2147483648).any()):
            print('WARN: bad sel entries', file=sys.stderr, flush=True)
            uniq = uniq[Cscore[uniq] != -2147483648]; nu = int(uniq.shape[0])
            if nu == 0: return None
        if nu > W:
            sc = Cscore[uniq]
            top = cp.argsort(-sc)[:W]
            uniq = uniq[top]
        Ppos = Cpos.reshape(Kp, 6)[uniq].reshape(-1)
        Pact = Cact[uniq]; Pcop = Ccop[uniq]
        Pbrd = Cbrd.reshape(Kp, NWP)[uniq].reshape(-1)
        Padj = Cadj.reshape(Kp, NWA)[uniq].reshape(-1)
        layers.append((cp.asnumpy(Cpar[uniq]), cp.asnumpy(Cmv[uniq])))
        depth += 1
    return None

FID = {'e': '4-enormous', 'l': '3-large', 'm': '2-medium'}

def writeout(path, res):   # g.writeout with retries (the merge loop may hold the file open on Windows)
    for t in range(20):
        try:
            g.writeout(path, res); return True
        except OSError as ex:
            time.sleep(0.25)
    print('WARN: could not write', path, file=sys.stderr, flush=True); return False
_cache = {}
def load(f):
    if f not in _cache:
        _cache[f] = (g.parse('../input/in_level-6_%s.txt' % FID[f]), g.refl('w_%s.out' % FID[f]))
    return _cache[f]

def solve_checked(case, W):
    r = solve(case, W)
    if r is not None and not valid(case, r):
        print('INVALID program (rejected)', file=sys.stderr, flush=True)
        return None
    return r

if __name__ == '__main__':
    if sys.argv[1] == 'test':
        W = int(sys.argv[2])
        spec = sys.argv[3].split(',')
        tot = {}
        for s in spec:
            f, i = s[0], int(s[1:])
            cs, best = load(f)
            t0 = time.time()
            r = solve_checked(cs[i], W)
            lr = len(r) if r else 999
            t = tot.setdefault(f, [0, 0]); t[0] += lr; t[1] += best[i]
            print('%s case %d need %d: adjrelax %s  (best %d)  %.1fs' % (f, i, cs[i][3], lr if r else 'FAIL', best[i], time.time()-t0), flush=True)
        print('TOTAL [adjrelax, best]', tot, flush=True)
    else:
        f, W, stop = sys.argv[2], int(sys.argv[3]), sys.argv[4]
        outp = sys.argv[5] if len(sys.argv) > 5 else 'x_%sA.out' % f
        cs, best = load(f)
        res = [None] * len(cs); tot = 0; totb = 0; nd = 0
        KEEPMIN = bool(os.environ.get('KEEPMIN'))   # rerun every case, keep the shorter of old/new per case
        if (os.environ.get('RESUME') or KEEPMIN) and os.path.exists(outp):   # keep solved blocks of an earlier run, skip those cases
            rb = [x for x in open(outp).read().replace('\r\n', '\n').split('\n\n') if x.strip()]
            if len(rb) == len(cs):
                for k, x in enumerate(rb):
                    if 'FAIL' not in x: res[k] = x.strip().split('\n')
        order = sorted(range(len(cs)), key=lambda i: -best[i])
        if os.environ.get('ORDER') == 'needlen':   # need>=6 first by need*len desc, then the rest longest first
            hi = sorted([i for i in range(len(cs)) if cs[i][3] >= 6], key=lambda i: -cs[i][3]*best[i])
            order = hi + [i for i in order if cs[i][3] < 6]
        for i in order:
            if res[i] is not None and not KEEPMIN: continue
            if time.strftime('%H%M', time.gmtime()) >= stop: break
            t0 = time.time()
            r = solve_checked(cs[i], W)
            old = res[i]
            if KEEPMIN and old is not None and (r is None or len(r) >= len(old)): r0 = r; r = old
            else: r0 = r
            res[i] = r
            if KEEPMIN: print('   new %s old %s' % (len(r0) if r0 else 'FAIL', len(old) if old else 'FAIL'), file=sys.stderr, flush=True)
            if r: tot += len(r); totb += best[i]; nd += 1
            print('%s case %d: %s (best %d) %.1fs  [done %d: %d vs best %d]' % (f, i, len(r) if r else 'FAIL', best[i], time.time()-t0, nd, tot, totb),
                  file=sys.stderr, flush=True)
            writeout(outp, res)
        writeout(outp, res)
        print('ALL DONE', file=sys.stderr, flush=True)
