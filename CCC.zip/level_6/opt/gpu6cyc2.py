#!/usr/bin/env python3
"""Cycle mode: from the state right after collection k of the current best program, search (GPU beam)
for a cycle of length P' returning to the same (pos, act) with empty pattern board and >= c copies; splice.
usage: python gpu6cyc.py <f: m|l|e> W [tag=Y] [minneed]"""
import sys, os, time, math
import numpy as np
import cupy as cp
import gpu6
from gpu6 import parse, geo, OFFSET, NBK, tomask, INS, NBd

SRC = gpu6.SRC
a = "int* __restrict__ scores, int* __restrict__ hist, int* __restrict__ doneidx)"
assert SRC.count(a) == 1
SRC = SRC.replace(a, "int* __restrict__ scores, int* __restrict__ hist, int* __restrict__ doneidx, const int cyc, const int rem, const int* __restrict__ cycp)")
b = "        if (child(w, mv, M, Ppos, Pact, Pbrd, BP, BA, PM, pos, act, nb, full)) {"
assert SRC.count(b) == 1
SRC = SRC.replace(b, "        if (child(w, mv, M, Ppos, Pact, Pbrd, BP, BA, PM, pos, act, nb, full) && cycok(M, pos, act, cyc, rem, cycp)) {")
c = "            if (cop == need) atomicMin(doneidx, (int)idx);"
assert SRC.count(c) == 1
SRC = SRC.replace(c, """            if (cyc) { if (rem == 0 && cop >= need) { bool z = true;
                #pragma unroll
                for (int k=0;k<NWP;k++) if (nb[k]) z = false;
                if (z) atomicMin(doneidx, (int)idx); } }
            else if (cop == need) atomicMin(doneidx, (int)idx);""")
d = 'extern "C" __global__ void expand('
assert SRC.count(d) == 1
e1 = "evalc(w, M, pos, act, nb, cop, BP, nearT)"
assert SRC.count(e1) == 2
SRC = SRC.replace(e1, "evalc(w, M, pos, act, nb, capc(cop, cycp), BP, nearT)")
e2 = "int* __restrict__ Cscore, u64* __restrict__ Chash, int* __restrict__ Cpar, int* __restrict__ Cmv)"
assert SRC.count(e2) == 1
SRC = SRC.replace(e2, "int* __restrict__ Cscore, u64* __restrict__ Chash, int* __restrict__ Cpar, int* __restrict__ Cmv, const int* __restrict__ cycp)")
e3 = "__device__ __forceinline__ int evalc("
assert SRC.count(e3) == 1
SRC = SRC.replace(e3, "__device__ __forceinline__ int capc(int cop, const int* __restrict__ cycp){ int c = cycp[7]; return (c >= 0 && cop > c) ? c : cop; }" + chr(10) + e3)
SRC = SRC.replace(d, """__device__ __forceinline__ bool cycok(int M, const int* pos, int act, int cyc, int rem, const int* __restrict__ cycp) {
    if (!cyc) return true;
    int Sact = cycp[0];
    #pragma unroll
    for (int e=0;e<6;e++){ int dd = pos[e] - cycp[1+e]; if (dd < 0) dd = -dd; if (M-dd < dd) dd = M-dd;
        dd += ((act ^ Sact) >> e) & 1; if (dd > rem) return false; }
    return true;
}
""" + d)

_mods = {}
def getmod(NWP, NWA):
    key = (NWP, NWA)
    if key not in _mods:
        m = cp.RawModule(code=SRC, options=('-DNWP=%d' % NWP, '-DNWA=%d' % NWA, '-std=c++14'))
        _mods[key] = (m.get_function('expand'), m.get_function('compact'), m.get_function('materialize'), m.get_function('nearK'))
    return _mods[key]

hist = None
_prep = {}

def prep(case):
    key = id(case)
    if key in _prep: return _prep[key]
    R, rows, cols, need, pat = case
    rows_, cols_, idg, ring, M, start, beam = geo(R)
    plist = [(i, j) for i in range(rows) for j in range(cols) if pat[i][j] == 'M']
    pidx = {cc: k for k, cc in enumerate(plist)}
    pset = set(plist)
    alist = []; aset = set()
    for (i, j) in plist:
        for dy, dx in NBd:
            y, x = i+dy, j+dx
            if 0 <= y < rows and 0 <= x < cols and idg[y][x] >= 0 and (y, x) not in pset and (y, x) not in aset:
                aset.add((y, x)); alist.append((y, x))
    aidx = {cc: k for k, cc in enumerate(alist)}
    npat = len(plist); nadj = len(alist)
    NWP = max(1, (npat+63)//64); NWA = max(1, (nadj+63)//64)
    bp = np.zeros((6, M, NWP), np.uint64); ba = np.zeros((6, M, NWA), np.uint64)
    for e in range(6):
        for p in range(M):
            bp[e, p] = tomask([pidx[cc] for cc in beam[e][p] if cc in pidx], NWP)
            ba[e, p] = tomask([aidx[cc] for cc in beam[e][p] if cc in aidx], NWA)
    BP = cp.asarray(bp.reshape(-1)); BA = cp.asarray(ba.reshape(-1))
    PM = cp.asarray(tomask(range(npat), NWP))
    # global-cell bitsets for fast exact simulation
    gid = {}
    for i in range(rows):
        for j in range(cols):
            if idg[i][j] >= 0: gid[(i, j)] = idg[i][j]
    bG = [[sum(1 << gid[cc] for cc in beam[e][p]) for p in range(M)] for e in range(6)]
    pmG = sum(1 << gid[cc] for cc in plist); amG = sum(1 << gid[cc] for cc in alist)
    r = dict(M=M, start=start, NWP=NWP, NWA=NWA, BP=BP, BA=BA, PM=PM, bG=bG, pmG=pmG, amG=amG, npat=npat)
    _prep[key] = r
    return r

def simulate(P, prog, pos0=None, act0=0):
    """exact game simulation; returns list of (tick, pos tuple, act) at each collection"""
    M = P['M']; pos = list(P['start'] if pos0 is None else pos0); act = act0; board = 0
    bG = P['bG']; pmG = P['pmG']; amG = P['amG']; cols = []
    for t, line in enumerate(prog):
        for e, ins in enumerate(line.split()):
            if ins == 'F': pos[e] = (pos[e]+1) % M
            elif ins == 'B': pos[e] = (pos[e]-1) % M
            elif ins == 'T': act ^= (1 << e)
        c1 = c2 = c3 = 0
        for e in range(6):
            if (act >> e) & 1:
                b = bG[e][pos[e]]; c3 |= c2 & b; c2 |= c1 & b; c1 |= b
        board = (board | (c2 & ~c3)) & ~c3
        if (board & pmG) == pmG and (board & amG) == 0:
            board &= ~pmG
            cols.append((t+1, tuple(pos), act))
    return cols

def solve_cycle(case, W, Spos, Sact, Pp, needc, KF=4.0):
    global hist
    R, rows, cols, need, pat = case
    P = prep(case); M = P['M']; NWP = P['NWP']
    fexp, fcomp, fmat, fnear = getmod(P['NWP'], P['NWA'])
    BP, BA, PM = P['BP'], P['BA'], P['PM']
    if hist is None: hist = cp.zeros(NBK, cp.int32)
    Ppos = cp.asarray(np.array(Spos, np.uint8))
    Pact = cp.full(1, Sact, cp.int32); Pcop = cp.zeros(1, cp.int32); Pbrd = cp.zeros(NWP, cp.uint64)
    cycp = cp.asarray(np.array([Sact] + list(Spos) + [needc-1], np.int32))
    done = cp.zeros(1, cp.int32); ctr = cp.zeros(2, cp.int32)
    layers = []
    K = int(W*KF)
    for depth in range(Pp):
        rem = Pp - (depth+1)
        Wc = int(Pact.shape[0])
        nearT = cp.empty(Wc*6*M, cp.uint8)
        nt = Wc*6
        fnear(((nt+127)//128,), (128,), (np.int32(Wc), np.int32(M), Pbrd, BP, PM, nearT))
        total = Wc*4096
        scores = cp.empty(total, cp.int32)
        hist.fill(0); done.fill(2147483647)
        fexp((total//256,), (256,), (np.int32(Wc), np.int32(M), np.int32(needc), Ppos, Pact, Pcop, Pbrd, nearT, BP, BA, PM,
                                     scores, hist, done, np.int32(1), np.int32(rem), cycp))
        d = int(done.get()[0])
        if d != 2147483647:
            mvs = [d & 4095]; w = d >> 12
            for li in range(len(layers)-1, -1, -1):
                par, mva = layers[li]
                mvs.append(int(mva[w])); w = int(par[w])
            mvs.reverse()
            out = []
            for mv in mvs:
                m = mv; t = []
                for e in range(6): t.append(INS[m & 3]); m >>= 2
                out.append(' '.join(t))
            return out
        if rem == 0: return None
        rc = cp.cumsum(hist[::-1])
        nvalid = int(rc[-1])
        if nvalid == 0: return None
        Kcur = K
        while True:
            Kp = min(Kcur, nvalid)
            j = int(cp.searchsorted(rc, Kp))
            T = NBK-1-j
            cntAbove = int(rc[j-1]) if j > 0 else 0
            needT = Kp - cntAbove
            ctr.fill(0)
            sel = cp.full(Kp, -1, cp.int32)
            fcomp(((total+255)//256,), (256,), (scores, np.int64(total), np.int32(T), np.int32(cntAbove), np.int32(needT), ctr, sel))
            Cpos = cp.empty(Kp*6, cp.uint8); Cact = cp.empty(Kp, cp.int32); Ccop = cp.empty(Kp, cp.int32)
            Cbrd = cp.empty(Kp*NWP, cp.uint64); Cscore = cp.empty(Kp, cp.int32); Chash = cp.empty(Kp, cp.uint64)
            Cpar = cp.empty(Kp, cp.int32); Cmv = cp.empty(Kp, cp.int32)
            fmat(((Kp+127)//128,), (128,), (np.int32(Kp), np.int32(Wc), sel, np.int32(M), Ppos, Pact, Pcop, Pbrd, nearT, BP, BA, PM,
                                            Cpos, Cact, Ccop, Cbrd, Cscore, Chash, Cpar, Cmv, cycp))
            order = cp.argsort(Chash)
            hs = Chash[order]
            keep = cp.ones(Kp, dtype=cp.bool_)
            if Kp > 1: keep[1:] = hs[1:] != hs[:-1]
            uniq = order[keep]
            nu = int(uniq.shape[0])
            if nu >= W or Kp >= nvalid or Kcur >= 64*W or Kcur*4 > (1 << 24): break
            Kcur *= 4
        del scores
        uniq = uniq[Cscore[uniq] != -2147483648]; nu = int(uniq.shape[0])
        if nu == 0: return None
        if nu > W:
            sc = Cscore[uniq]
            top = cp.argsort(-sc)[:W]
            uniq = uniq[top]
        Ppos = Cpos.reshape(Kp, 6)[uniq].reshape(-1)
        Pact = Cact[uniq]; Pcop = Ccop[uniq]
        Pbrd = Cbrd.reshape(Kp, NWP)[uniq].reshape(-1)
        layers.append((cp.asnumpy(Cpar[uniq]), cp.asnumpy(Cmv[uniq])))
    return None

def splice(P, best, tk, cyc, N, ncop):
    reps = (N + 2) // max(1, ncop) + 2
    prog = best[:tk] + cyc * reps
    cols = simulate(P, prog)
    if len(cols) < N: return None
    return prog[:cols[N-1][0]]

def main():
    f = sys.argv[1]; W = int(sys.argv[2]); tag = sys.argv[3] if len(sys.argv) > 3 else 'Y'
    fid = {'e': '4-enormous', 'l': '3-large', 'm': '2-medium'}[f]
    minneed = int(sys.argv[4]) if len(sys.argv) > 4 else (4 if f == 'm' else 3)
    cases = parse('../input/in_level-6_%s.txt' % fid)
    outp = 'x_%s%s.out' % (f, tag)
    rb = [x for x in open('w_%s.out' % fid).read().replace('\r\n', '\n').split('\n\n') if x.strip()]
    assert len(rb) == len(cases)
    best = [x.strip().split('\n') for x in rb]
    res = [None]*len(cases)
    jobs = []
    for i, cs in enumerate(cases):
        need = cs[3]
        if need < minneed or 'FAIL' in rb[i]: continue
        jobs.append(((need-1) * len(best[i]) / need, i))
    jobs.sort(reverse=True)
    t0 = time.time(); lastw = 0; saved = 0
    for n, (pri, i) in enumerate(jobs):
        cs = cases[i]; need = cs[3]; tc = time.time()
        P = prep(cs)
        cols = simulate(P, best[i])
        if len(cols) != need:
            print(f'case {i}: best sim count {len(cols)} != {need}, skip', file=sys.stderr, flush=True); continue
        L = len(best[i]); bl = L; bprog = None; info = ''
        ticks = [c[0] for c in cols]
        ks = sorted(set(k for k in (1, 2, 3, 4, need//2, need-2) if 1 <= k <= need-2))
        nsearch = 0
        for k in ks:
            tk, Spos, Sact = cols[k-1]
            remain = need - k
            avg = (L - tk) / remain
            for ncop in (1, 2):
                if remain < ncop: continue
                P0 = math.ceil(ncop*avg) - 1
                for Pp in range(P0, max(0, P0-3), -1):
                    if Pp < 1: break
                    lb = tk + (remain // ncop - 1) * Pp + 1 if remain >= ncop else tk + Pp
                    if lb >= bl: continue
                    nsearch += 1
                    try:
                        cyc = solve_cycle(cs, W, list(Spos), Sact, Pp, ncop)
                    except Exception as ex:
                        print('CRASH', i, repr(ex)[:200], file=sys.stderr, flush=True)
                        gpu6.writeout(outp, res); os._exit(3)
                    if cyc is None: break
                    cand = splice(P, best[i], tk, cyc, need, ncop)
                    if cand is not None and len(cand) < bl:
                        bl = len(cand); bprog = cand; info = f'k={k} P={Pp} c={ncop}'
        if bprog is not None:
            chk = simulate(P, bprog)
            if len(chk) == need:
                res[i] = bprog; saved += L - bl
            else:
                print(f'case {i}: splice check failed', file=sys.stderr, flush=True)
        print(f'case {i}: need {need} best {L} -> {bl} {info} searches {nsearch} {time.time()-tc:.2f}s saved {saved} elapsed {time.time()-t0:.0f}s', file=sys.stderr, flush=True)
        if time.time() - lastw > 15 or n == len(jobs)-1:
            gpu6.writeout(outp, res); lastw = time.time()
    gpu6.writeout(outp, res)
    print(f'ALL DONE {outp} saved {saved} time {time.time()-t0:.0f}s', file=sys.stderr, flush=True)

if __name__ == '__main__':
    main()
