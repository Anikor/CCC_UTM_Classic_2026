#!/bin/sh
cd "/Users/anikor/Documents/Documents - Karina’s MacBook Air/Work CaducStudio/CCC_auto" && git pull -q --no-rebase origin main 2>&1 | grep -v "^$" | head -2
cd games/ccc42/level_6/opt
for fid in 2-medium 3-large 4-enormous; do
  case $fid in 2-medium) p=m;; 3-large) p=l;; 4-enormous) p=e;; esac
  cands=$(ls *_$fid.out ${p}_*.out x_${p}*.out c_$fid.out 2>/dev/null | grep -v "^final_" | sort -u | tr '\n' ' ')
  python3 merge6.py ../input/in_level-6_$fid.txt final_$fid.out $cands 2>&1 | grep -o "score [0-9]*" | sed "s/^/$fid merged /"
done
cd ../../../.. && python3 autosub6.py
