#!/bin/sh
S="C:/Users/STUDEN~1/AppData/Local/Temp/claude/C--Users-Student-06/7e509993-7097-4227-b51b-ad21e0f7d3a6/scratchpad"
while [ "$(date -u +%H%M)" -lt 1656 ]; do
  echo "=== $(date -u +%H:%M:%S)"
  sh "$S/msub.sh" 2>&1 | grep -E "w_|SUBMITTED|no gain|invalid|TOTAL|Error|error"
  cd ~/CCC_auto && git add games/ccc42/level_6/opt/x_*.out 2>/dev/null && \
    git -c user.name=Anikor -c user.email=36260683+Anikor@users.noreply.github.com commit -q -m "Windows box: updated candidate outputs

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>" >/dev/null 2>&1 && \
    git pull -q --no-rebase origin main >/dev/null 2>&1 && git push -q origin main 2>&1 | tail -1 && echo pushed
  sleep 150
done
