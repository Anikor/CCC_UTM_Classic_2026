#!/bin/sh
# final submit loop: merge + validate + submit-if-better, tight cadence, last start 16:59:15 UTC
S="C:/Users/STUDEN~1/AppData/Local/Temp/claude/C--Users-Student-06/7e509993-7097-4227-b51b-ad21e0f7d3a6/scratchpad"
while [ "$(date -u +%H%M%S)" -lt 165915 ]; do
  echo "=== $(date -u +%H:%M:%S)"
  sh "$S/msub2.sh" 2>&1 | grep -E "w_|SUBMITTED|no gain|invalid|TOTAL|Error|error"
  echo "--- done $(date -u +%H:%M:%S)"
  sleep 10
done
echo "FINAL LOOP END $(date -u +%H:%M:%S)"
