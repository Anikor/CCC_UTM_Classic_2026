#!/bin/sh
# usage: lbrun.sh <f> <W> <KLB> <stopHHMM> ; retries on crash, resumes from the output file
cd ~/CCC_auto/games/ccc42/level_6/opt
while [ "$(date -u +%H%M)" -lt "$4" ]; do
  "/c/Users/Student 06/AppData/Local/Programs/Python/Python312/python.exe" -X faulthandler gpu6L.py run $1 $2 $3 $4 && break
  echo "RESTART $(date -u +%H:%M:%S)" >&2; sleep 3
done
