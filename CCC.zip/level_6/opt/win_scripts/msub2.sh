#!/bin/sh
# Pull, merge all candidates per file (shortest valid per case), submit if better than board.
PY="/c/Users/Student 06/AppData/Local/Programs/Python/Python312/python.exe"
cd games/ccc42/level_6/opt
for fid in 2-medium 3-large 4-enormous; do
  case $fid in 2-medium) p=m;; 3-large) p=l;; 4-enormous) p=e;; esac
  cands=$(ls final_$fid.out x_${p}*.out 2>/dev/null | tr '\n' ' ')
  "$PY" merge6.py ../input/in_level-6_$fid.txt w_$fid.out $cands 2>&1 | tail -1
done
cd ~/CCC_auto && "$PY" - <<'PY'
import subprocess
from codingcontest_api import CodingContestAPI
PYX=r"C:\Users\Student 06\AppData\Local\Programs\Python\Python312\python.exe"
api=CodingContestAPI('https://nanofabricator.codingcontest.org/')
per=api.info()['score']['state']['level6'].get('scoresPerFile',{})
opt='games/ccc42/level_6/opt'
for fid in ['2-medium','3-large','4-enormous']:
    out=subprocess.run([PYX,'nano6.py','score',f'../input/in_level-6_{fid}.txt',f'w_{fid}.out'],cwd=opt,capture_output=True,text=True).stdout.strip()
    if 'bad cases 0' not in out: print(fid,'invalid/missing:',out[:200]); continue
    score=int(out.split('score ')[1].split(',')[0]); board=-per.get(fid,0)
    if score<board:
        ev=api.submit(6,fid,f'{opt}/w_{fid}.out').get('evaluation') or {}
        print(fid,'SUBMITTED',score,'board was',board,'OK' if ev.get('isCorrect') else 'WRONG')
    else: print(fid,'no gain',score,'vs board',board)
i=api.info(); print('TOTAL',i['score']['gameScore'].get('displayScore'),i['score']['state']['level6'].get('scoresPerFile'))
PY
