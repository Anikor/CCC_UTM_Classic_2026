#!/bin/sh
# push candidate files every ~45 s so the Mac's watcher merges them within a minute
while [ "$(date -u +%H%M)" -lt 1659 ]; do
  cd ~/CCC_auto && git pull -q --no-rebase origin main >/dev/null 2>&1
  git add games/ccc42/level_6/opt/x_*.out 2>/dev/null && \
  git -c user.name=Anikor -c user.email=36260683+Anikor@users.noreply.github.com commit -q -m "Windows box: candidate outputs $(date -u +%H:%M)

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>" >/dev/null 2>&1 && git push -q origin main >/dev/null 2>&1 && echo "pushed $(date -u +%H:%M:%S)"
  sleep 45
done
