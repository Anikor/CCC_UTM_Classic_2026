#!/bin/sh
# merge + validate + submit every ~2 min (no git here; push loop owns git)
S="C:/Users/STUDEN~1/AppData/Local/Temp/claude/C--Users-Student-06/7e509993-7097-4227-b51b-ad21e0f7d3a6/scratchpad"
while [ "$(date -u +%H%M)" -lt 1657 ]; do
  echo "=== $(date -u +%H:%M:%S)"
  sh "$S/msub2.sh" 2>&1 | grep -E "w_|SUBMITTED|no gain|invalid|TOTAL|Error|error"
  sleep 75
done
