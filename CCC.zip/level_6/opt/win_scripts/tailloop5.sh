#!/bin/sh
# back-to-back GPU tail passes on enormous+large, fresh seeds (w_) and a new cut set each pass
cd ~/CCC_auto/games/ccc42/level_6/opt
i=0
while [ "$(date -u +%H%M)" -lt 1658 ]; do
  case $((i % 3)) in 0) c=0.22,0.4,0.57,0.77;; 1) c=0.25,0.5,0.7,0.9;; 2) c=0.1,0.35,0.55,0.75,0.95;; esac
  echo "PASS $i cuts $c $(date -u +%H:%M:%S)" >&2
  LB=600 "/c/Users/Student 06/AppData/Local/Programs/Python/Python312/python.exe" tail6g3.py el 65536 $c 1658
  i=$((i+1))
done
