#!/bin/sh
# back-to-back GPU tail passes on enormous+large, fresh seeds (w_) and a new cut set each pass
cd ~/CCC_auto/games/ccc42/level_6/opt
i=0
while [ "$(date -u +%H%M)" -lt 1653 ]; do
  case $((i % 3)) in 0) c=0.28,0.42,0.6,0.72,0.88;; 1) c=0.12,0.3,0.45,0.62,0.78,0.93;; 2) c=0.1,0.35,0.55,0.75,0.95;; esac
  echo "PASS $i cuts $c $(date -u +%H:%M:%S)" >&2
  LB=300 "/c/Users/Student 06/AppData/Local/Programs/Python/Python312/python.exe" tail6g3.py el 65536 $c 1653
  i=$((i+1))
done
