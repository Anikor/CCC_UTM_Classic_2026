#!/usr/bin/env python3
"""Two-row sweep planner for level 6.  python3 sweep2.py <in> <out> [fallback.out]"""
import sys
from collections import defaultdict
_argv = sys.argv; sys.argv = ['x']
exec(open('nano6.py').read().replace('\nmain()\n', '\n'))
sys.argv = _argv

def line_pos(geo, e, c):
    for (ee, p) in geo.cell_opts[c]:
        if ee == e: return p
    return None

def step_dir(geo, p, q):
    """+1/-1 direction of the shortest way from p to q (0 if equal)."""
    if p == q: return 0
    return 1 if dist(geo, p, q)[1] == 'F' else -1

class Exec:
    def __init__(s, geo, pat, pm):
        s.geo=geo; s.pat=pat; s.pm=pm
        pmset=set(pm); s.nb=set()
        for (i,j) in pm:
            for dr,dc in NB:
                c=(i+dr,j+dc)
                if c not in pmset and 0<=c[0]<geo.rows and 0<=c[1]<geo.cols and geo.g[c[0]][c[1]]=='O': s.nb.add(c)
        s.pos=list(geo.start); s.act=[False]*6; s.board=[r[:] for r in geo.g]; s.prog=[]; s.subs=0
    def tick(s, line):
        geo=s.geo
        for e in range(6):
            if line[e]=='F': s.pos[e]=(s.pos[e]+1)%geo.M
            elif line[e]=='B': s.pos[e]=(s.pos[e]-1)%geo.M
            elif line[e]=='T': s.act[e]=not s.act[e]
        cnt=defaultdict(int)
        for e in range(6):
            if s.act[e]:
                for cc in geo.beam[(e,s.pos[e])]: cnt[cc]+=1
        for cc,n in cnt.items():
            if n==2: s.board[cc[0]][cc[1]]='M'
            elif n>=3: s.board[cc[0]][cc[1]]='O'
        if all(s.board[i][j]=='M' for i,j in s.pm) and not any(s.board[i][j]=='M' for i,j in s.nb):
            s.subs+=1
            for i,j in s.pm: s.board[i][j]='O'
        s.prog.append(line)

def plan_passes(geo, pm, P, S, offset, reverse):
    """Returns list of passes: (rowkeys[(pe, rail)], diag_list) where diag_list is the ordered
    list of sweeper(S0) rail indices to visit; per diag, which primaries fire is derived from cells."""
    P0,P1,S0 = P,P+3,S
    lines=defaultdict(list)
    for c in pm: lines[line_pos(geo,P0,c)].append(c)
    keys=sorted(lines)
    if reverse: keys=keys[::-1]
    groups=[]
    i=0
    if offset and keys: groups.append([keys[0]]); i=1
    while i<len(keys):
        groups.append(keys[i:i+2]); i+=2
    passes=[]
    for g in groups:
        cells=[c for k in g for c in lines[k]]
        diags=sorted(set(line_pos(geo,S0,c) for c in cells))
        passes.append((g, diags))
    return passes

def run_copy(ex, P, S, passes, first_dir):
    geo=ex.geo; P0,P1,S0,S1=P,P+3,S,S+3
    cur=None   # current sweeper
    direction=first_dir
    for pi,(g, diags) in enumerate(passes):
        # primaries: row k uses P0 if first in group else P1 (keep each on its own emitter)
        prim = {}
        for idx,k in enumerate(g):
            pe = P0 if idx==0 else P1
            prim[pe] = line_pos(geo, pe, next(c for c in ex.pm if line_pos(geo,P0,c)==k))
        # ordered diag sequence for this pass
        ds = diags if direction>0 else diags[::-1]
        # cells per (diag, primary)
        want=defaultdict(set)
        for pe in prim:
            for c in ex.pm:
                if line_pos(geo,pe,c)==prim[pe]: want[line_pos(geo,S0,c)].add(pe)
        # segments of consecutive diags
        segs=[]; 
        for d in ds:
            if segs and abs(segs[-1][-1]-d)==1 or (segs and dist(geo,segs[-1][-1],d)[0]==1): segs[-1].append(d)
            else: segs.append([d])
        # choose sweeper for the first segment: the closer one (by rail distance to seg start)
        def spos(e,d): return line_pos(geo, e, next(c for c in ex.pm if line_pos(geo,S0,c)==d))
        if cur is None:
            cur = min((S0,S1), key=lambda e: dist(geo, ex.pos[e], spos(e, segs[0][0]))[0])
        twin = S1 if cur==S0 else S0
        # next pass start (for twin pre-positioning when no more segments)
        def next_pass_start():
            if pi+1<len(passes):
                g2,d2=passes[pi+1]; nd = d2 if -direction>0 else d2[::-1]
                return nd[0]
            return None
        si=0
        while si<len(segs):
            seg=segs[si]
            # ---- positioning phase: primaries to rows, cur sweeper to seg start, twin to next seg start
            tgt_cur=spos(cur,seg[0])
            nxt = segs[si+1][0] if si+1<len(segs) else next_pass_start()
            tgt_twin = spos(twin, nxt) if nxt is not None else None
            while any(ex.pos[pe]!=prim[pe] for pe in prim) or ex.pos[cur]!=tgt_cur:
                line=['-']*6
                for e in (S0,S1):
                    if ex.act[e]: line[e]='T'
                for pe in prim:
                    if ex.pos[pe]!=prim[pe] and line[pe]=='-': line[pe]=dist(geo,ex.pos[pe],prim[pe])[1]
                if ex.pos[cur]!=tgt_cur and line[cur]=='-': line[cur]=dist(geo,ex.pos[cur],tgt_cur)[1]
                if tgt_twin is not None and ex.pos[twin]!=tgt_twin and line[twin]=='-': line[twin]=dist(geo,ex.pos[twin],tgt_twin)[1]
                ex.tick(line)
            # ---- sweep phase over seg
            for di,d in enumerate(seg):
                line=['-']*6
                if di==0:
                    if not ex.act[cur]: line[cur]='T'
                else:
                    line[cur]='F' if step_dir(geo, ex.pos[cur], spos(cur,d))>0 else 'B'
                for pe in prim:
                    desired = pe in want[d]
                    if ex.act[pe]!=desired: line[pe]='T'
                # unused primary (single-row pass) must be off
                for pe in (P0,P1):
                    if pe not in prim and ex.act[pe] and line[pe]=='-': line[pe]='T'
                # twin keeps travelling
                if tgt_twin is not None and ex.pos[twin]!=tgt_twin and line[twin]=='-' and not ex.act[twin]:
                    line[twin]=dist(geo,ex.pos[twin],tgt_twin)[1]
                ex.tick(line)
            # ---- segment done: swap to twin if it is already at the next segment start
            if si+1<len(segs):
                nxt_seg=segs[si+1]
                if ex.pos[twin]==spos(twin,nxt_seg[0]) and not ex.act[twin]:
                    line=['-']*6; line[cur]='T'; line[twin]='T'
                    for pe in prim:
                        desired = pe in want[nxt_seg[0]]
                        if ex.act[pe]!=desired: line[pe]='T'
                    for pe in (P0,P1):
                        if pe not in prim and ex.act[pe] and line[pe]=='-': line[pe]='T'
                    ex.tick(line)
                    cur,twin=twin,cur
                    # continue the segment from its 2nd diag
                    seg2=nxt_seg[1:]
                    nxt2 = segs[si+2][0] if si+2<len(segs) else next_pass_start()
                    tgt_twin = spos(twin, nxt2) if nxt2 is not None else None
                    for d in seg2:
                        line=['-']*6
                        line[cur]='F' if step_dir(geo, ex.pos[cur], spos(cur,d))>0 else 'B'
                        for pe in prim:
                            desired = pe in want[d]
                            if ex.act[pe]!=desired: line[pe]='T'
                        if tgt_twin is not None and ex.pos[twin]!=tgt_twin and line[twin]=='-' and not ex.act[twin]:
                            line[twin]=dist(geo,ex.pos[twin],tgt_twin)[1]
                        ex.tick(line)
                    si+=2; continue
            si+=1
        direction=-direction
    return

def solve_case_v2(R, rows, cols, need, pat, P, S, offset):
    geo=Geo(R)
    pm=[(i,j) for i in range(rows) for j in range(cols) if pat[i][j]=='M']
    ex=Exec(geo,pat,pm)
    d=1
    for copy in range(need):
        passes=plan_passes(geo, pm, P, S, offset, copy%2==1)
        before=len(ex.prog)
        run_copy(ex, P, S, passes, d)
        if ex.subs!=copy+1: return None
        if len(ex.prog)-before>5000: return None
    if simulate(geo, pat, ex.prog)!=need: return None
    return ex.prog

def main():
    inp,outp=sys.argv[1:3]; fallback=sys.argv[3] if len(sys.argv)>3 else None
    cases=parse(inp)
    fb=[b for b in open(fallback).read().replace('\r\n','\n').split('\n\n') if b.strip()] if fallback else None
    out=[]; total=0; nfb=0
    for idx,(R,rows,cols,need,pat) in enumerate(cases):
        best=None
        for P in range(3):
            for S in range(3):
                if S==P: continue
                for off in (0,1):
                    try: prog=solve_case_v2(R,rows,cols,need,pat,P,S,off)
                    except Exception as e: prog=None
                    if prog is not None and (best is None or len(prog)<len(best)): best=prog
        if fb:
            blk=fb[idx].strip(); fl=blk.count('\n')+1
            if best is None or fl<len(best):
                nfb+=1; total+=fl; out.append(blk); continue
        total+=len(best); out.append('\n'.join(' '.join(l) for l in best))
    open(outp,'w').write('\n\n'.join(out)+'\n')
    print(f'{inp}: score {total} (fallbacks {nfb})', file=sys.stderr)
main()
