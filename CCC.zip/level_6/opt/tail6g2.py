#!/usr/bin/env python3
"""GPU tail re-search (intensification around the current best program).
usage: python tail6g.py <files: e/l/m> W cuts(e.g. 0.3,0.55,0.8) stopHHMM(UTC)
For each case (longest first across files), cut the best program from w_<fid>.out at each fraction,
simulate the prefix, and beam-search the remainder on the GPU from that exact state, accepting only
strictly shorter completions. Writes x_<f>T.out progressively (current best kept where not improved)."""
import sys, time, inspect
import numpy as np
import cupy as cp
import gpu6snap as g

src = inspect.getsource(g.solve)
src = src.replace('def solve(case, W, KF=2.0, maxlayers=None):', 'def solve_from(case, W, KF, maxlayers, init):')
a = 'Ppos = cp.asarray(np.array(start, np.uint8))'
b = 'Pact = cp.zeros(1, cp.int32); Pcop = cp.zeros(1, cp.int32); Pbrd = cp.zeros(NWP, cp.uint64)'
assert a in src and b in src
src = src.replace(a, 'Ppos = cp.asarray(np.array(init[0], np.uint8))')
src = src.replace(b, 'Pact = cp.asarray(np.array([init[1]], np.int32)); Pcop = cp.asarray(np.array([init[2]], np.int32)); '
                     'Pbrd = cp.asarray(tomask([pidx[c] for c in init[3] if c in pidx], NWP))')
exec(src, g.__dict__)
solve_from = g.solve_from
import os
CONT = os.environ.get('CONT') == '1'
if CONT:
    import gpu6c
RELAX = os.environ.get('RELAX') == '1'
if RELAX:
    import gpu6r
    gpu6r.MODE['relax'] = True

def sim(case, lines):
    """nano6-equivalent simulation of a prefix; returns (pos, act, copies, board cells, adjacent cells)."""
    R, rows, cols, need, pat = case
    _, _, idg, ring, M, start, beam = g.geo(R)
    plist = [(i, j) for i in range(rows) for j in range(cols) if pat[i][j] == 'M']; pset = set(plist)
    adj = set()
    for (i, j) in plist:
        for dy, dx in g.NBd:
            y, x = i + dy, j + dx
            if 0 <= y < rows and 0 <= x < cols and idg[y][x] >= 0 and (y, x) not in pset: adj.add((y, x))
    pos = list(start); act = 0; cop = 0; board = set()
    for ln in lines:
        ins = ln.split()
        for e in range(6):
            if ins[e] == 'F': pos[e] = (pos[e] + 1) % M
            elif ins[e] == 'B': pos[e] = (pos[e] - 1) % M
            elif ins[e] == 'T': act ^= (1 << e)
        cnt = {}
        for e in range(6):
            if (act >> e) & 1:
                for c in beam[e][pos[e]]: cnt[c] = cnt.get(c, 0) + 1
        for c, k in cnt.items():
            if k == 2: board.add(c)
            elif k >= 3: board.discard(c)
        if pset <= board and not (adj & board):
            cop += 1; board -= pset
    return pos, act, cop, board, adj

FID = {'e': '4-enormous', 'l': '3-large', 'm': '2-medium'}
fl, W = sys.argv[1], int(sys.argv[2])
fracs = [float(x) for x in sys.argv[3].split(',')]
stop = sys.argv[4]
cases, out, jobs = {}, {}, []
for f in fl:
    fid = FID[f]
    cases[f] = g.parse('../input/in_level-6_%s.txt' % fid)
    bl = [x for x in open('w_%s.out' % fid).read().replace('\r\n', '\n').split('\n\n') if x.strip()]
    assert len(bl) == len(cases[f]), (fid, len(bl))
    out[f] = [x.strip().split('\n') for x in bl]
    jobs += [(len(out[f][i]), f, i) for i in range(len(bl))]
jobs.sort(key=lambda t: -t[0])
saved = {f: 0 for f in fl}; lastw = 0; t0 = time.time()
for L, f, i in jobs:
    if time.strftime('%H%M', time.gmtime()) >= stop: break
    case = cases[f][i]; cur = out[f][i]; tc = time.time()
    for fr in fracs:
        cut = int(len(cur) * fr)
        if cut < 1 or cut >= len(cur) - 1: continue
        pos, act, cop, board, adj = sim(case, cur[:cut])
        if (board & adj) or cop >= case[3]: continue
        if CONT:
            gpu6c.CUR['cont'] = True; gpu6c.CUR['cw'] = 300 * sum(rr.count('M') for rr in case[4]) + 1000
        r = solve_from(case, W, 4.0, len(cur) - cut - 1, (pos, act, cop, board))
        if r is not None and cut + len(r) < len(cur):
            saved[f] += len(cur) - cut - len(r); cur = cur[:cut] + r; out[f][i] = cur
    print('%s case %d: %d -> %d  %.1fs  saved %s  elapsed %.0fs' % (f, i, L, len(cur), time.time() - tc, saved, time.time() - t0),
          file=sys.stderr, flush=True)
    if time.time() - lastw > 20:
        for h in fl: g.writeout('x_%sT%s%s.out' % (h, 'c' if CONT else '', 'r' if RELAX else ''), out[h])
        lastw = time.time()
for h in fl: g.writeout('x_%sT%s%s.out' % (h, 'c' if CONT else '', 'r' if RELAX else ''), out[h])
print('TAIL DONE saved %s' % saved, file=sys.stderr, flush=True)
