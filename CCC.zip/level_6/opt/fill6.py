#!/usr/bin/env python3
"""Row-fill sweep planner: fillers (same family, opposite ends) fill one line per tick, 4 destroyers
kill adjacent strays on that line in the same tick. python3 fill6.py <in> <out> [threads]"""
import sys, itertools
from collections import defaultdict
_argv=sys.argv; sys.argv=['x']
exec(open('nano6.py').read().replace('\nmain()\n','\n'))
sys.argv=_argv

def line_pos(geo,e,c):
    for (ee,p) in geo.cell_opts[c]:
        if ee==e: return p
    return None

class Sim:
    def __init__(s,geo,pat,pm):
        s.geo=geo; s.pm=pm; s.pmset=set(pm); s.adj=set()
        for (i,j) in pm:
            for dr,dc in NB:
                c=(i+dr,j+dc)
                if c not in s.pmset and 0<=c[0]<geo.rows and 0<=c[1]<geo.cols and geo.g[c[0]][c[1]]=='O': s.adj.add(c)
        s.pos=list(geo.start); s.act=[False]*6; s.M=set(); s.prog=[]; s.subs=0
    def step(s,line,commit=True):
        """returns (ok, newM, newpos, newact, submitted) ; ok=False if an adjacent stray is created or pattern matter destroyed"""
        geo=s.geo; pos=list(s.pos); act=list(s.act)
        for e in range(6):
            if line[e]=='F': pos[e]=(pos[e]+1)%geo.M
            elif line[e]=='B': pos[e]=(pos[e]-1)%geo.M
            elif line[e]=='T': act[e]=not act[e]
        cnt=defaultdict(int)
        for e in range(6):
            if act[e]:
                for cc in geo.beam[(e,pos[e])]: cnt[cc]+=1
        M=set(s.M); ok=True
        for cc,n in cnt.items():
            if n==2:
                if cc in s.adj: ok=False
                M.add(cc)
            elif n>=3:
                if cc in s.pmset and cc in s.M: ok=False
                M.discard(cc)
        sub=False
        if s.pmset<=M and not (M & s.adj):
            sub=True; M-=s.pmset
        if commit and ok:
            s.pos,s.act,s.M=pos,act,M; s.prog.append(line); s.subs+=sub
        return ok,sub

def plan(R,rows,cols,need,pat,P):
    geo=Geo(R); pm=[(i,j) for i in range(rows) for j in range(cols) if pat[i][j]=='M']
    sim=Sim(geo,pat,pm)
    F0,F1=P,P+3; D=[e for e in range(6) if e not in (F0,F1)]
    # lines of family P (keyed by F0 rail pos), ordered
    lines=defaultdict(list)
    for c in pm: lines[line_pos(geo,F0,c)].append(c)
    keys=sorted(lines)
    # consecutive check: F0 positions must be consecutive (each step = 1 rail move)
    if any(dist(geo,keys[i],keys[i+1])[0]!=1 for i in range(len(keys)-1)): return None
    # strays per line: cells of that line (beam cells of F0 at key) not in pattern but adjacent
    def strays(k):
        cells=geo.beam[(F0,k)]
        return [c for c in cells if c not in sim.pmset and c in sim.adj]
    for k in keys:
        if len(strays(k))>4: return None
    order=keys[:]
    def do_copy(order,first):
        # target positions for the first line
        k=order[0]; S=strays(k)
        if first:
            # choose destroyer assignment minimising travel; others park anywhere (keep)
            best=None
            for perm in itertools.permutations(D,len(S)):
                tgt={F0:line_pos(geo,F0,S[0]) if False else k, F1:line_pos(geo,F1,geo.beam[(F0,k)][0])}
                okp=True
                for e,c in zip(perm,S):
                    p=line_pos(geo,e,c)
                    if p is None: okp=False;break
                    tgt[e]=p
                if not okp: continue
                trav=max(dist(geo,sim.pos[e],tgt[e])[0] for e in tgt)
                if best is None or trav<best[0]: best=(trav,tgt)
            if best is None: return False
            trav,tgt=best
            # travel (all off)
            for _ in range(trav):
                line=['-']*6
                for e in range(6):
                    if e in tgt and sim.pos[e]!=tgt[e]: line[e]=dist(geo,sim.pos[e],tgt[e])[1]
                ok,_=sim.step(line)
                if not ok: return False
            # fire: toggle on fillers + assigned destroyers (unassigned stay off)
            line=['-']*6
            for e in tgt:
                if not sim.act[e]: line[e]='T'
            ok,_=sim.step(line)
            if not ok: return False
            start=1
        else:
            # re-fire current line by staying (if everything is already on and aligned) — try no-op tick
            ok,_=sim.step(['-']*6)
            if not ok: return False
            start=1
        for idx in range(start,len(order)):
            k=order[idx]; S=strays(k)
            # fillers step to next line
            fl=['-']*6
            fl[F0]=dist(geo,sim.pos[F0],k)[1]
            kk=line_pos(geo,F1,geo.beam[(F0,k)][0]); fl[F1]=dist(geo,sim.pos[F1],kk)[1]
            # try destroyer move combos (incl. toggles) and keep a valid one
            found=False
            opts=['-','F','B','T']
            for combo in itertools.product(opts,repeat=4):
                line=fl[:]
                for e,o in zip(D,combo): line[e]=o
                ok,sub=sim.step(line,commit=False)
                if not ok: continue
                # verify the line's pattern cells all created and strays gone: simulate on a copy
                save=(sim.pos,sim.act,set(sim.M),len(sim.prog),sim.subs)
                sim.step(line)
                good = all(c in sim.M for c in geo.beam[(F0,k)] if c in sim.pmset) and not any(c in sim.M for c in S)
                if good: found=True; break
                sim.pos,sim.act,sim.M,_,sim.subs=save[0],save[1],save[2],save[3],save[4]; sim.prog.pop()
            if not found: return False
        return True
    for cp in range(need):
        if not do_copy(order, cp==0): return None
        if sim.subs!=cp+1: return None
        order=order[::-1]
    if simulate(geo,pat,sim.prog)!=need: return None
    return sim.prog

def solve_case(args):
    R,rows,cols,need,pat=args
    best=None
    for P in range(3):
        try: prog=plan(R,rows,cols,need,pat,P)
        except Exception: prog=None
        if prog and (best is None or len(prog)<len(best)): best=prog
    return best

if __name__=='__main__':
    inp,outp=sys.argv[1:3]; th=int(sys.argv[3]) if len(sys.argv)>3 else 4
    cases=parse(inp)
    from multiprocessing import Pool
    with Pool(th) as pool: res=pool.map(solve_case,cases)
    out=[]; tot=0; ok=0
    for p in res:
        if p is None: out.append('FAIL')
        else: ok+=1; tot+=len(p); out.append('\n'.join(' '.join(l) for l in p))
    open(outp,'w').write('\n\n'.join(out)+'\n')
    print(f'{inp}: fill solved {ok}/{len(cases)}, lines of solved {tot}', file=sys.stderr)
