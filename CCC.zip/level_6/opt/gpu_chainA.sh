#!/bin/bash
cd "/c/Users/Student 06/CCC_auto/games/ccc42/level_6/opt/"
PY="/c/Users/Student 06/AppData/Local/Programs/Python/Python312/python.exe"
until grep -q "ALL DONE" glog_mA3.txt 2>/dev/null; do sleep 1; done
KEEPMIN=1 ORDER=needlen NEARADJ=2 ADJPEN=600 "$PY" -W ignore gpu6a_k.py run m 32768 1643 x_mA.out > glog_mA4.txt 2>&1
