#!/usr/bin/env python3
"""merge.py <in> <out> <cand1> <cand2> ...  -> per case the shortest VALID program among candidates."""
import sys
sys.argv_backup = sys.argv[:]
import importlib.util
spec = importlib.util.spec_from_file_location("n6", "nano6.py"); 
src = open("nano6.py").read().replace("\nmain()\n", "\n")
n6 = {}; exec(compile(src, "nano6.py", "exec"), n6)
inp, outp, *cands = sys.argv[1:]
cases = n6['parse'](inp)
def blocks(p): return [b.strip().split('\n') for b in open(p).read().replace('\r\n','\n').split('\n\n') if b.strip()]
cb = [blocks(c) for c in cands]
best = []; total = 0; src_count = [0]*len(cands)
for k, (R, rows, cols, need, pat) in enumerate(cases):
    geo = n6['Geo'](R); choice = None
    for ci, b in enumerate(cb):
        if k >= len(b): continue
        prog = [l.split() for l in b[k]]
        if choice is not None and len(prog) >= len(choice[1]): continue
        if n6['simulate'](geo, pat, prog) == need: choice = (ci, prog)
    assert choice is not None, f"case {k}: no valid candidate"
    src_count[choice[0]] += 1; best.append('\n'.join(' '.join(l) for l in choice[1])); total += len(choice[1])
open(outp, 'w').write('\n\n'.join(best) + '\n')
print(f"{outp}: score {total}  (picked per candidate: {dict(zip(cands, src_count))})")
