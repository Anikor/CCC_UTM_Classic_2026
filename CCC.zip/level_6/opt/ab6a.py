import sys, time
sys.argv = sys.argv[:1] + sys.argv[1:]
import gpu6r, gpu6a
W = int(sys.argv[1]); spec = sys.argv[2].split(','); doR = sys.argv[3] if len(sys.argv) > 3 else 'el'
tot = {}
for s in spec:
    f, i = s[0], int(s[1:])
    cs, best = gpu6a.load(f); c = cs[i]
    t0 = time.time(); a = gpu6a.solve_checked(c, W); ta = time.time() - t0
    la = len(a) if a else 999
    lr = -1
    if f in doR:
        t0 = time.time(); r = gpu6r.solve(c, W, True); tr = time.time() - t0
        if r is not None and not gpu6a.valid(c, r): r = None
        lr = len(r) if r else 999
    t = tot.setdefault(f, [0, 0, 0]); t[0] += la; t[1] += lr; t[2] += best[i]
    print('%s case %d need %d: A %d  R %d  best %d   (A %.1fs)' % (f, i, c[3], la, lr, best[i], ta), flush=True)
print('TOTAL [A, R, best]', tot, flush=True)
