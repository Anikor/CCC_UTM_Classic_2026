// post6: post-optimizer for CCC42 level 6.
// usage: post6 <in> <sol> <out> [W0=256] [Wmax=4096] [threads=2] [perCaseSec=20] [globalSec=1800]
// Verifies every case with an exact port of nano6.simulate (count must equal need),
// then shortens programs by (a) line deletion / adjacent merge, (b) tail beam re-search
// from cut points seeded with the known prefix state.  Only verified improvements are kept.
#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long u64;
typedef array<u64,8> B8;
static const int Dd[6][2]={{0,2},{1,1},{1,-1},{0,-2},{-1,-1},{-1,1}};
static const int NBd[6][2]={{0,2},{0,-2},{1,1},{1,-1},{-1,1},{-1,-1}};

struct Geo {
    int R,rows,cols,M,ncell,nw; vector<vector<int>> id; vector<pair<int,int>> ring; int start[6]; vector<B8> beam;
    Geo(int R_):R(R_){
        rows=2*R+1; cols=4*R+1; id.assign(rows,vector<int>(cols,-1)); ncell=0;
        for(int i=0;i<rows;i++){int off=abs(i-R); for(int j=off;j<=cols-1-off;j+=2){bool b=(i==0||i==rows-1||j==off||j==cols-1-off); if(!b) id[i][j]=ncell++;}}
        for(int t=0;t<R;t++) ring.push_back({0,R+2*t}); for(int t=0;t<R;t++) ring.push_back({t,3*R+t});
        for(int t=0;t<R;t++) ring.push_back({R+t,4*R-t}); for(int t=0;t<R;t++) ring.push_back({2*R,3*R-2*t});
        for(int t=0;t<R;t++) ring.push_back({2*R-t,R-t}); for(int t=0;t<R;t++) ring.push_back({R-t,t});
        M=ring.size(); int s[6]={5*R,0,R,2*R,3*R,4*R}; for(int e=0;e<6;e++)start[e]=s[e];
        nw=(ncell+63)/64;
        beam.assign(6*M,B8{});
        for(int e=0;e<6;e++)for(int p=0;p<M;p++){int y=ring[p].first+Dd[e][0],x=ring[p].second+Dd[e][1];
            while(y>=0&&y<rows&&x>=0&&x<cols){ int c=id[y][x]; if(c>=0) beam[e*M+p][c>>6]|=1ULL<<(c&63); y+=Dd[e][0];x+=Dd[e][1];}}
    }
};
struct Case { int R,rows,cols,need; vector<string> pat; };
struct CX { Geo* G; B8 pat{}, adj{}; int npat=0, need=0; };
struct SimSt { int pos[6]; int act; B8 board; int copies; };

static void simStep(const Geo&G,const CX&cx,SimSt&s,unsigned mv){
    int M=G.M;
    for(int e=0;e<6;e++){int o=(mv>>(2*e))&3; if(o==1)s.pos[e]=(s.pos[e]+1)%M; else if(o==2)s.pos[e]=(s.pos[e]+M-1)%M; else if(o==3)s.act^=1<<e;}
    B8 c1{},c2{},c3{};
    for(int e=0;e<6;e++) if(s.act>>e&1){const B8&b=G.beam[e*M+s.pos[e]]; for(int w=0;w<8;w++){c3[w]|=c2[w]&b[w]; c2[w]|=c1[w]&b[w]; c1[w]|=b[w];}}
    for(int w=0;w<8;w++) s.board[w]=(s.board[w]|(c2[w]&~c3[w]))&~c3[w];
    bool full=true, adjm=false; for(int w=0;w<8;w++){ if((s.board[w]&cx.pat[w])!=cx.pat[w]) full=false; if(s.board[w]&cx.adj[w]) adjm=true; }
    if(full&&!adjm){ s.copies++; for(int w=0;w<8;w++) s.board[w]&=~cx.pat[w]; }
}
static SimSt simInit(const Geo&G){ SimSt s; for(int e=0;e<6;e++)s.pos[e]=G.start[e]; s.act=0; s.board=B8{}; s.copies=0; return s; }
// returns final count; reach = first tick (1-based) at which count==need (or -1)
static int simulate(const Geo&G,const CX&cx,const vector<uint16_t>&prog,int&reach){
    SimSt s=simInit(G); reach=-1;
    for(size_t t=0;t<prog.size();t++){ simStep(G,cx,s,prog[t]); if(reach<0&&s.copies==cx.need) reach=(int)t+1; }
    return s.copies;
}
// valid iff exact count == need; also returns truncated program if prefix reaches need
static bool validTrunc(const Geo&G,const CX&cx,vector<uint16_t>&prog){
    int reach; simulate(G,cx,prog,reach);
    if(reach<0) return false;
    prog.resize(reach);
    int r2; int c=simulate(G,cx,prog,r2); return c==cx.need;
}

template<int NW> struct Beam {
    const Geo&G; const CX&cx; int M; bool prune; bool pruneDestroy=true; int noise; int wd,wp,wn; u64 salt=0; // weights
    struct St { u64 b[NW]; unsigned char pos[6]; unsigned char act; unsigned char copies; };
    struct Cand { long long key; int parent; uint16_t mv; u64 h; };
    vector<Cand> cand; long long thr; int W;
    const St* ps; int pi; u64 c1[7][NW],c2[7][NW],c3[7][NW]; unsigned char npos[6]; unsigned char nact; u64 bp[NW];
    vector<int> nearT; vector<array<u64,NW>> bpat; bool stop; int fpar; uint16_t fmv;
    Beam(const Geo&g,const CX&c):G(g),cx(c),M(g.M){ bpat.resize(6*M); for(int i=0;i<6*M;i++) for(int w=0;w<NW;w++) bpat[i][w]=G.beam[i][w]&cx.pat[w]; nearT.resize(6*M); }
    void apply(const St&s,unsigned mv,St&t){
        t=s; for(int e=0;e<6;e++){int o=(mv>>(2*e))&3; if(o==1)t.pos[e]=(t.pos[e]+1)%M; else if(o==2)t.pos[e]=(t.pos[e]+M-1)%M; else if(o==3)t.act^=1<<e;}
        u64 a1[NW]={},a2[NW]={},a3[NW]={};
        for(int e=0;e<6;e++) if(t.act>>e&1){const B8&b=G.beam[e*M+t.pos[e]]; for(int w=0;w<NW;w++){a3[w]|=a2[w]&b[w]; a2[w]|=a1[w]&b[w]; a1[w]|=b[w];}}
        for(int w=0;w<NW;w++) t.b[w]=(t.b[w]|(a2[w]&~a3[w]))&~a3[w];
        bool full=true, adjm=false; for(int w=0;w<NW;w++){ if((t.b[w]&cx.pat[w])!=cx.pat[w]) full=false; if(t.b[w]&cx.adj[w]) adjm=true; }
        if(full&&!adjm){ t.copies++; for(int w=0;w<NW;w++) t.b[w]&=~cx.pat[w]; }
    }
    static inline u64 mix(u64 h,u64 v){ h^=v+0x9e3779b97f4a7c15ULL+(h<<6)+(h>>2); h*=0xff51afd7ed558ccdULL; return h^(h>>29); }
    void leaf(unsigned mv){
        u64 nb[NW]; bool adjHit=false;
        for(int w=0;w<NW;w++){ u64 cr=c2[6][w]&~c3[6][w]; if(cr&cx.adj[w]) adjHit=true; nb[w]=(ps->b[w]|cr)&~c3[6][w]; }
        if(prune&&adjHit) return;
        int copies=ps->copies; bool full=true, adjm=false;
        for(int w=0;w<NW;w++){ if((nb[w]&cx.pat[w])!=cx.pat[w]) full=false; if(nb[w]&cx.adj[w]) adjm=true; }
        if(full&&!adjm){ copies++; for(int w=0;w<NW;w++) nb[w]&=~cx.pat[w]; }
        if(copies>=cx.need){ stop=true; fpar=pi; fmv=(uint16_t)mv; return; }
        int donec=0; for(int w=0;w<NW;w++) donec+=__builtin_popcountll(nb[w]&cx.pat[w]);
        int pot=0,dsum=0;
        for(int e=0;e<6;e++){ const u64*b=bpat[e*M+npos[e]].data(); int onl=0; for(int w=0;w<NW;w++) onl+=__builtin_popcountll(b[w]&~nb[w]); pot+=(nact>>e&1)?3*onl:onl; dsum+=nearT[e*M+npos[e]]; }
        long long score=copies*100000LL+donec*wd+pot*wp-dsum*wn;
        u64 h=nact|((u64)copies<<8); for(int e=0;e<6;e++) h=h*131+npos[e];
        for(int w=0;w<NW;w++) h=mix(h,nb[w]);
        u64 hs=salt?mix(h,salt):h;
        if(noise) score+=(long long)((hs>>33)%(u64)noise);
        long long key=score*65536+(long long)(hs&0xFFFF);
        if(key<thr) return;
        cand.push_back({key,pi,(uint16_t)mv,h});
        if((int)cand.size()>=4*W){
            nth_element(cand.begin(),cand.begin()+2*W,cand.end(),[](const Cand&a,const Cand&b){return a.key>b.key;});
            cand.resize(2*W); long long mn=LLONG_MAX; for(auto&c:cand) mn=min(mn,c.key); thr=mn;
        }
    }
    void rec(int e,unsigned mv){
        if(e==6){ leaf(mv); return; }
        int p=ps->pos[e]; int a=(ps->act>>e)&1;
        for(int o=0;o<4&&!stop;o++){
            int np=p,na=a;
            if(o==1) np=(p+1==M)?0:p+1; else if(o==2) np=(p==0)?M-1:p-1; else if(o==3) na^=1;
            npos[e]=(unsigned char)np;
            if(na){ const u64*b=G.beam[e*M+np].data(); u64 bad=0;
                for(int w=0;w<NW;w++){ c1[e+1][w]=c1[e][w]|b[w]; c2[e+1][w]=c2[e][w]|(c1[e][w]&b[w]); c3[e+1][w]=c3[e][w]|(c2[e][w]&b[w]); bad|=c3[e+1][w]&bp[w]; }
                if(pruneDestroy&&bad) continue;
                nact|=(unsigned char)(1<<e);
            } else { for(int w=0;w<NW;w++){c1[e+1][w]=c1[e][w];c2[e+1][w]=c2[e][w];c3[e+1][w]=c3[e][w];} nact&=(unsigned char)~(1<<e); }
            rec(e+1,mv|((unsigned)o<<(2*e)));
        }
    }
    void computeNear(const St&s){
        u64 needed[NW]; for(int w=0;w<NW;w++) needed[w]=cx.pat[w]&~s.b[w];
        for(int e=0;e<6;e++){
            int* d=&nearT[e*M]; bool any=false;
            for(int p=0;p<M;p++){ bool u=false; for(int w=0;w<NW;w++) if(G.beam[e*M+p][w]&needed[w]){u=true;break;} d[p]=u?0:1000000; any|=u; }
            if(!any){ for(int p=0;p<M;p++) d[p]=M; continue; }
            for(int it=0;it<2;it++) for(int p=0;p<M;p++){ int q=(p+M-1)%M; d[p]=min(d[p],d[q]+1); }
            for(int it=0;it<2;it++) for(int p=M-1;p>=0;p--){ int q=(p+1)%M; d[p]=min(d[p],d[q]+1); }
        }
    }
    // returns true and tail moves if target reached within maxDepth
    bool run(const SimSt&s0,int maxDepth,int W_,vector<uint16_t>&tail,chrono::steady_clock::time_point dl){
        W=W_; St r; for(int w=0;w<NW;w++) r.b[w]=s0.board[w]; for(int e=0;e<6;e++) r.pos[e]=(unsigned char)s0.pos[e]; r.act=(unsigned char)s0.act; r.copies=(unsigned char)s0.copies;
        if(s0.copies>=cx.need){ tail.clear(); return true; }
        vector<St> cur{r}; vector<vector<pair<int,uint16_t>>> back; back.push_back({{-1,0}});
        stop=false;
        for(int d=1; d<=maxDepth; d++){
            if(chrono::steady_clock::now()>dl) return false;
            cand.clear(); thr=LLONG_MIN;
            for(pi=0; pi<(int)cur.size() && !stop; pi++){
                ps=&cur[pi]; computeNear(*ps);
                for(int w=0;w<NW;w++){ c1[0][w]=c2[0][w]=c3[0][w]=0; bp[w]=ps->b[w]&cx.pat[w]; }
                nact=ps->act; rec(0,0);
                if(stop) break;
            }
            if(stop){
                tail.clear(); tail.push_back(fmv); int idx=fpar;
                for(int l=d-1;l>0;l--){ tail.push_back(back[l][idx].second); idx=back[l][idx].first; }
                reverse(tail.begin(),tail.end()); return true;
            }
            if(cand.empty()) return false;
            sort(cand.begin(),cand.end(),[](const Cand&a,const Cand&b){return a.key>b.key;});
            unordered_set<u64> seen; seen.reserve(W*2);
            vector<St> nxt; vector<pair<int,uint16_t>> bk; nxt.reserve(W); bk.reserve(W);
            for(auto&c:cand){ if((int)nxt.size()>=W) break; if(!seen.insert(c.h).second) continue; St t; apply(cur[c.parent],c.mv,t); nxt.push_back(t); bk.push_back({c.parent,c.mv}); }
            back.push_back(move(bk)); cur.swap(nxt);
        }
        return false;
    }
};

static bool runBeam(const Geo&G,const CX&cx,const SimSt&s0,int maxDepth,int W,int variant,vector<uint16_t>&tail,chrono::steady_clock::time_point dl,u64 salt=0){
    auto go=[&](auto&& b)->bool{
        b.prune=true; b.noise=0; b.wd=300; b.wp=4; b.wn=3; b.salt=salt; b.pruneDestroy=!getenv("NODESTROYPRUNE");
        if(variant==1){ b.noise=200; }
        else if(variant==2){ b.wd=300; b.wp=6; b.wn=2; b.noise=60; }
        else if(variant==3){ b.wd=250; b.wp=3; b.wn=5; b.noise=100; }
        else if(variant==4){ b.prune=false; b.noise=50; }
        return b.run(s0,maxDepth,W,tail,dl);
    };
    switch(G.nw){
        case 1: { Beam<1> b(G,cx); return go(b); }
        case 2: { Beam<2> b(G,cx); return go(b); }
        case 3: { Beam<3> b(G,cx); return go(b); }
        case 4: { Beam<4> b(G,cx); return go(b); }
        case 5: { Beam<5> b(G,cx); return go(b); }
        case 6: { Beam<6> b(G,cx); return go(b); }
        case 7: { Beam<7> b(G,cx); return go(b); }
        default: { Beam<8> b(G,cx); return go(b); }
    }
}

static bool localPass(const Geo&G,const CX&cx,vector<uint16_t>&prog){
    bool any=false, changed=true;
    while(changed){
        changed=false;
        for(int i=(int)prog.size()-1;i>=0;i--){
            if(i>=(int)prog.size()) continue;
            vector<uint16_t> c=prog; c.erase(c.begin()+i);
            if(validTrunc(G,cx,c) && c.size()<prog.size()){ prog=c; changed=any=true; }
        }
        for(int i=0;i+1<(int)prog.size();i++){
            unsigned a=prog[i], b=prog[i+1], m=0; bool ok=true;
            for(int e=0;e<6&&ok;e++){ int x=(a>>(2*e))&3, y=(b>>(2*e))&3, z;
                if(x==0) z=y; else if(y==0) z=x; else if((x==1&&y==2)||(x==2&&y==1)||(x==3&&y==3)) z=0; else { ok=false; break; }
                m|=(unsigned)z<<(2*e); }
            if(!ok) continue;
            vector<uint16_t> c=prog; c[i]=(uint16_t)m; c.erase(c.begin()+i+1);
            if(validTrunc(G,cx,c) && c.size()<prog.size()){ prog=c; changed=any=true; }
        }
    }
    return any;
}

// pumping: find a<b with identical emitter config and copies gained; repeat segment
static bool pumpPass(const Geo&G,const CX&cx,vector<uint16_t>&prog){
    bool any=false;
    for(int iter=0; iter<20; iter++){
        int L=prog.size(); vector<SimSt> st(L+1); st[0]=simInit(G);
        for(int t=0;t<L;t++){ st[t+1]=st[t]; simStep(G,cx,st[t+1],prog[t]); }
        vector<uint16_t> bestc=prog;
        for(int a=0;a<L;a++) for(int b=a+1;b<=L;b++){
            if(st[b].copies<=st[a].copies||st[a].act!=st[b].act) continue;
            bool same=true; for(int e=0;e<6;e++) if(st[a].pos[e]!=st[b].pos[e]){same=false;break;}
            if(!same) continue;
            int k=st[b].copies-st[a].copies, len=b-a;
            vector<uint16_t> seg(prog.begin()+a,prog.begin()+b);
            // (i) prefix to b, then repeat seg until done
            { vector<uint16_t> c(prog.begin(),prog.begin()+b); int rem=cx.need-st[b].copies; int m=(rem+k-1)/k+1;
              if((long long)c.size()+(long long)m*len < (long long)bestc.size()+len){
                for(int r=0;r<m;r++) c.insert(c.end(),seg.begin(),seg.end());
                if(validTrunc(G,cx,c)&&c.size()<bestc.size()) bestc=c; } }
            // (ii) insert m extra copies of seg at b, keep the rest
            for(int m=1; m<=cx.need; m++){
                if((long long)m*len >= (long long)L) break;
                vector<uint16_t> c(prog.begin(),prog.begin()+b);
                for(int r=0;r<m;r++) c.insert(c.end(),seg.begin(),seg.end());
                c.insert(c.end(),prog.begin()+b,prog.end());
                if(validTrunc(G,cx,c)&&c.size()<bestc.size()) bestc=c;
            }
        }
        if(bestc.size()<prog.size()){ prog=bestc; any=true; } else break;
    }
    return any;
}

// rewrite pass: delete line j and replace one nearby line i by any of the 4096 lines
static bool rewritePass(const Geo&G,const CX&cx,vector<uint16_t>&prog,chrono::steady_clock::time_point dl,int WIN){
    bool any=false;
    for(;;){
        int L=prog.size(); if(L<2) return any;
        vector<SimSt> st(L+1); st[0]=simInit(G); for(int t=0;t<L;t++){ st[t+1]=st[t]; simStep(G,cx,st[t+1],prog[t]); }
        bool found=false;
        for(int j=L-1;j>=0&&!found;j--){
            vector<uint16_t> q=prog; q.erase(q.begin()+j); int Lq=q.size();
            for(int i=max(0,j-WIN); i<min(Lq,j+WIN) && !found; i++){
                if(chrono::steady_clock::now()>dl) return any;
                int base=min(i,j); // q[0..base) == prog[0..base)
                SimSt s0=st[base]; for(int t=base;t<i;t++) simStep(G,cx,s0,q[t]);
                uint16_t orig=q[i];
                for(int v=0;v<4096;v++){
                    SimSt s=s0; simStep(G,cx,s,(unsigned)v);
                    int t=i+1; bool ok=(s.copies>=cx.need);
                    for(; t<Lq && !ok; t++){ simStep(G,cx,s,q[t]); if(s.copies>=cx.need) ok=true; }
                    if(ok){ vector<uint16_t> c=q; c[i]=(uint16_t)v; if(validTrunc(G,cx,c)&&c.size()<prog.size()){ prog=c; found=true; any=true; break; } }
                }
                q[i]=orig;
            }
        }
        if(!found) return any;
    }
}

// cycle search: from an anchor state whose relevant board (pattern+adj cells) is empty,
// enumerate closed walks of length c that return to the same emitter config with the
// relevant board empty again and >=1 copy produced; then repeat the cycle.
struct CycFinder {
    const Geo&G; const CX&cx; int c; SimSt anc; vector<uint16_t> path, best; int bestCopies; long long nodes;
    CycFinder(const Geo&g,const CX&x):G(g),cx(x){}
    int rd(int p,int q){int M=G.M; int f=((q-p)%M+M)%M; return min(f,M-f);}
    void dfs(const SimSt&s,int d){
        if(nodes>4000000) return;
        int r=c-d; // ticks remaining including this one
        int opts[6][4], no[6];
        for(int e=0;e<6;e++){ no[e]=0; for(int o=0;o<4;o++){ int p=s.pos[e], a=(s.act>>e)&1;
            if(o==1)p=(p+1)%G.M; else if(o==2)p=(p+G.M-1)%G.M; else if(o==3)a^=1;
            int cost=rd(p,anc.pos[e])+(a!=((anc.act>>e)&1)); if(cost<=r-1) opts[e][no[e]++]=o; } if(!no[e]) return; }
        int idx[6]={0,0,0,0,0,0};
        for(;;){
            unsigned mv=0; for(int e=0;e<6;e++) mv|=(unsigned)opts[e][idx[e]]<<(2*e);
            SimSt t=s; simStep(G,cx,t,mv); nodes++;
            path.push_back((uint16_t)mv);
            if(d==c-1){
                int gained=t.copies-anc.copies; bool empty=true; for(int w=0;w<8;w++) if(t.board[w]&(cx.pat[w]|cx.adj[w])){empty=false;break;}
                if(gained>bestCopies&&empty){ bestCopies=gained; best=path; }
            } else dfs(t,d+1);
            path.pop_back();
            int e=0; while(e<6){ if(++idx[e]<no[e]) break; idx[e]=0; e++; } if(e==6) break;
        }
    }
    bool run(const SimSt&a,int c_){ anc=a; c=c_; best.clear(); bestCopies=0; nodes=0; path.clear(); dfs(a,0); return bestCopies>0; }
};
static bool cyclePass(const Geo&G,const CX&cx,vector<uint16_t>&prog,int cmax){
    int L=prog.size(); vector<SimSt> st(L+1); st[0]=simInit(G);
    for(int t=0;t<L;t++){ st[t+1]=st[t]; simStep(G,cx,st[t+1],prog[t]); }
    vector<uint16_t> bestp=prog; CycFinder cf(G,cx);
    for(int t=0;t<L;t++){
        bool empty=true; for(int w=0;w<8;w++) if(st[t].board[w]&(cx.pat[w]|cx.adj[w])){empty=false;break;}
        if(!empty) continue;
        int rem=cx.need-st[t].copies; if(rem<=0) continue;
        for(int c=1;c<=cmax;c++){
            // lower bound on length with this cycle: t + ceil(rem/(c))... at best 1 copy per tick
            if((long long)t+rem >= (long long)bestp.size()) break;
            if(!cf.run(st[t],c)) continue;
            int k=cf.bestCopies; int reps=(rem+k-1)/k;
            if((long long)t+(long long)reps*c >= (long long)bestp.size()+c) continue;
            vector<uint16_t> cand(prog.begin(),prog.begin()+t);
            for(int r=0;r<reps;r++) cand.insert(cand.end(),cf.best.begin(),cf.best.end());
            if(validTrunc(G,cx,cand)&&cand.size()<bestp.size()) bestp=cand;
        }
    }
    if(bestp.size()<prog.size()){ prog=bestp; return true; }
    return false;
}

int main(int argc,char**argv){
    if(argc<4){fprintf(stderr,"usage: post6 in sol out [W0] [Wmax] [threads] [perCaseSec] [globalSec]\n");return 1;}
    int W0=argc>4?atoi(argv[4]):256, Wmax=argc>5?atoi(argv[5]):4096, TH=argc>6?atoi(argv[6]):2;
    double perCase=argc>7?atof(argv[7]):20, globalSec=argc>8?atof(argv[8]):1800;
    auto T0=chrono::steady_clock::now(); auto gdl=T0+chrono::milliseconds((long long)(globalSec*1000));
    ifstream in(argv[1]); int n; in>>n; vector<Case> cs(n);
    for(auto&c:cs){ in>>c.R>>c.rows>>c.cols>>c.need; c.pat.resize(c.rows); for(auto&r:c.pat) in>>r; }
    // parse solution
    auto readSol=[&](const string&fn){ vector<vector<uint16_t>> progs;
        ifstream sf(fn); string line; vector<uint16_t> cur; bool inb=false;
        while(getline(sf,line)){ while(!line.empty()&&(line.back()=='\r'||line.back()==' '))line.pop_back();
            if(line.empty()){ if(inb){progs.push_back(cur); cur.clear(); inb=false;} continue; }
            istringstream ss(line); string tok; unsigned mv=0; int e=0;
            while(ss>>tok){ int o=0; if(tok=="F")o=1; else if(tok=="B")o=2; else if(tok=="T")o=3; if(e<6) mv|=(unsigned)o<<(2*e); e++; }
            cur.push_back((uint16_t)mv); inb=true; }
        if(inb) progs.push_back(cur);
        return progs; };
    vector<string> solFiles; { string s=argv[2]; size_t p=0; while(true){ size_t q=s.find(',',p); solFiles.push_back(s.substr(p,q==string::npos?string::npos:q-p)); if(q==string::npos)break; p=q+1; } }
    vector<vector<uint16_t>> progs=readSol(solFiles[0]);
    if((int)progs.size()!=n){ fprintf(stderr,"block count %d != cases %d\n",(int)progs.size(),n); return 1; }
    vector<unique_ptr<Geo>> geos(20); for(auto&c:cs) if(!geos[c.R]) geos[c.R].reset(new Geo(c.R));
    vector<vector<vector<uint16_t>>> extra; for(size_t f=1;f<solFiles.size();f++){ auto p=readSol(solFiles[f]); if((int)p.size()==n) extra.push_back(p); else fprintf(stderr,"skip %s (%d blocks)\n",solFiles[f].c_str(),(int)p.size()); }
    vector<CX> cxs(n);
    for(int i=0;i<n;i++){ auto&c=cs[i]; Geo&G=*geos[c.R]; CX&x=cxs[i]; x.G=&G; x.need=c.need;
        for(int r=0;r<c.rows;r++)for(int j=0;j<c.cols;j++) if(c.pat[r][j]=='M'){int id=G.id[r][j]; x.pat[id>>6]|=1ULL<<(id&63); x.npat++;}
        for(int r=0;r<c.rows;r++)for(int j=0;j<c.cols;j++) if(c.pat[r][j]=='M') for(auto&d:NBd){int y=r+d[0],xx=j+d[1]; if(y>=0&&y<G.rows&&xx>=0&&xx<G.cols&&G.id[y][xx]>=0){int id=G.id[y][xx]; if(!(x.pat[id>>6]>>(id&63)&1)) x.adj[id>>6]|=1ULL<<(id&63);}}
    }
    { long long before=0, after=0; for(int i=0;i<n;i++){ before+=progs[i].size(); int r;
        int c0=simulate(*cxs[i].G,cxs[i],progs[i],r); bool ok0=(c0==cs[i].need);
        for(auto&ex:extra){ int r2; int c=simulate(*cxs[i].G,cxs[i],ex[i],r2); if(c==cs[i].need && (!ok0 || ex[i].size()<progs[i].size())){ progs[i]=ex[i]; ok0=true; } }
        after+=progs[i].size(); }
      fprintf(stderr,"seed merge: %lld -> %lld from %d extra files\n",before,after,(int)extra.size()); }
    vector<vector<uint16_t>> best=progs; vector<int> okOrig(n,0); long long tot0=0;
    for(int i=0;i<n;i++){ int r; int c=simulate(*cxs[i].G,cxs[i],progs[i],r); okOrig[i]=(c==cs[i].need); tot0+=progs[i].size(); }
    int bad=0; for(int i=0;i<n;i++) if(!okOrig[i]) bad++;
    fprintf(stderr,"%s: orig total %lld, cases %d, invalid-by-verifier %d\n",argv[2],tot0,n,bad);
    if(getenv("VERIFY_ONLY")) return 0;
    mutex mu; string outp=argv[3];
    auto writeOut=[&](){ string tmp=outp+".tmp"; { ofstream o(tmp); for(int i=0;i<n;i++){ for(auto mv:best[i]){ for(int e=0;e<6;e++){ int x=(mv>>(2*e))&3; o<<"-FBT"[x]<<(e==5?'\n':' ');} } if(i+1<n) o<<"\n"; } }
        if(!MoveFileExA(tmp.c_str(),outp.c_str(),MOVEFILE_REPLACE_EXISTING)) fprintf(stderr,"rename failed %lu\n",(unsigned long)GetLastError()); };
    // order: longest first
    vector<int> order(n); iota(order.begin(),order.end(),0);
    sort(order.begin(),order.end(),[&](int a,int b){return progs[a].size()>progs[b].size();});
    vector<int> order2=order;
    if(getenv("REVERSE")) reverse(order.begin(),order.end());
    string mark=getenv("MARK")?getenv("MARK"):"";
    auto claim=[&](const string&tag)->bool{ if(mark.empty()) return true; std::error_code ec; return std::filesystem::create_directory(mark+"/"+tag,ec); };
    if(!mark.empty()){ std::error_code ec; std::filesystem::create_directories(mark,ec); }
    if(getenv("SKIPLOGS")&&!mark.empty()){ string s=getenv("SKIPLOGS"); size_t p=0; vector<string> fl;
        while(true){ size_t q=s.find(',',p); fl.push_back(s.substr(p,q==string::npos?string::npos:q-p)); if(q==string::npos)break; p=q+1; }
        int nm=0; for(auto&f:fl){ ifstream lf(f); string ln; while(getline(lf,ln)){ size_t a=ln.find("] case "); if(a==string::npos) continue; int ci=atoi(ln.c_str()+a+7); claim("0_"+to_string(ci)); nm++; } }
        fprintf(stderr,"pre-marked %d done cases from logs\n",nm); }
    // ---- v6 dynamic job loop: re-reads seed file 0 (merged best) periodically, claims (case, program-hash, k) jobs ----
    int KMAX=getenv("KMAX")?atoi(getenv("KMAX")):4;
    auto phash=[](const vector<uint16_t>&p){ u64 h=1469598103934665603ULL; for(auto v:p){ h^=v; h*=1099511628211ULL; } return h; };
    auto lastRef=chrono::steady_clock::now()-chrono::hours(1);
    set<string> doneTags;
    auto refresh=[&](){ // call under mu
        auto now=chrono::steady_clock::now(); if(now-lastRef<chrono::seconds(40)) return; lastRef=now;
        auto p=readSol(solFiles[0]); if((int)p.size()!=n){ fprintf(stderr,"refresh: bad block count %d\n",(int)p.size()); return; }
        int upd=0; for(int i=0;i<n;i++){ if(!p[i].empty()&&p[i].size()<best[i].size()){ int r; if(simulate(*cxs[i].G,cxs[i],p[i],r)==cs[i].need){ best[i]=p[i]; upd++; } } }
        if(upd){ long long tt=0; for(int i=0;i<n;i++) tt+=best[i].size(); fprintf(stderr,"refresh: adopted %d shorter programs, total now %lld\n",upd,tt); writeOut(); }
    };
    atomic<long long> saved(0); atomic<int> jobsDone(0);
    vector<thread> th;
    for(int t=0;t<TH;t++) th.emplace_back([&,t]{ for(;;){
        if(chrono::steady_clock::now()>=gdl) break;
        int i=-1, kk=-1; vector<uint16_t> prog;
        { lock_guard<mutex> lk(mu); refresh();
          vector<tuple<double,int,int>> cl;
          if(getenv("ONLYK")){ int k=atoi(getenv("ONLYK")); for(int c=0;c<n;c++) if(okOrig[c]) cl.push_back(make_tuple((double)best[c].size(),c,k)); }
          else
          for(int k=0;k<KMAX;k++) for(int c=0;c<n;c++) if(okOrig[c]) cl.push_back(make_tuple((double)best[c].size()*pow(0.6,k),c,k));
          if(getenv("REWRITE")) for(int c=0;c<n;c++) if(okOrig[c]) cl.push_back(make_tuple((double)best[c].size()*1.01,c,9));
          stable_sort(cl.begin(),cl.end(),[](const tuple<double,int,int>&a,const tuple<double,int,int>&b){return get<0>(a)>get<0>(b);});
          for(auto&tp:cl){ int c=get<1>(tp), k=get<2>(tp); string tag=to_string(c)+"_"+to_string(phash(best[c]))+"_"+to_string(k);
              if(doneTags.count(tag)) continue;
              std::error_code ec; if(!mark.empty()&&std::filesystem::exists(mark+"/"+tag,ec)){ doneTags.insert(tag); continue; }
              doneTags.insert(tag);
              if(claim(tag)){ i=c; kk=k; prog=best[c]; break; } }
        }
        if(i<0) break;
        const Geo&G=*cxs[i].G; const CX&cx=cxs[i];
        size_t L0=prog.size();
        { vector<uint16_t> c=prog; if(validTrunc(G,cx,c)&&c.size()<prog.size()) prog=c; }
        localPass(G,cx,prog); if(pumpPass(G,cx,prog)) localPass(G,cx,prog);
        int cm=getenv("CMAX")?atoi(getenv("CMAX")):2;
        if(kk==0){ if(cyclePass(G,cx,prog,cm)) localPass(G,cx,prog); }
        auto cdl=chrono::steady_clock::now()+chrono::milliseconds((long long)(perCase*1000)); if(cdl>gdl) cdl=gdl;
        static const double FR[4][7]={{0.6,0.75,0.45,0.85,0.3,0.15,0.0},{0.5,0.7,0.9,0.35,0.2,0.05,0.8},{0.55,0.4,0.7,0.25,0.8,0.1,0.9},{0.65,0.5,0.35,0.8,0.2,0.0,0.9}};
        const double* fr=FR[kk%4];
        int variant=(kk==0?0:kk==1?2:kk==2?1:3); u64 salt=(u64)kk*0x9E3779B97F4A7C15ULL;
        if(kk==9){ int WIN=getenv("WIN")?atoi(getenv("WIN")):4; if(rewritePass(G,cx,prog,cdl,WIN)) localPass(G,cx,prog); }
        for(int W=W0<<(kk==0?0:kk<3?1:2); kk!=9 && W<=Wmax && chrono::steady_clock::now()<cdl; W*=2){
            for(int fi=0;fi<7;fi++){ double f=fr[fi];
                if(chrono::steady_clock::now()>=cdl) break;
                int L=prog.size(); int k=(int)(L*f); if(k>=L-1) continue;
                SimSt s=simInit(G); for(int t2=0;t2<k;t2++) simStep(G,cx,s,prog[t2]);
                if(s.copies>=cx.need) continue;
                vector<uint16_t> tail;
                if(runBeam(G,cx,s,L-k-1,W,variant,tail,cdl,salt)){
                    vector<uint16_t> c(prog.begin(),prog.begin()+k); c.insert(c.end(),tail.begin(),tail.end());
                    if(validTrunc(G,cx,c)&&c.size()<prog.size()){ prog=c; localPass(G,cx,prog); pumpPass(G,cx,prog); }
                }
            }
            variant=(variant+1)%4;
        }
        vector<uint16_t> chk=prog; bool ok=validTrunc(G,cx,chk)&&chk.size()==prog.size();
        lock_guard<mutex> lk(mu);
        if(ok&&prog.size()<best[i].size()){ saved+= (long long)best[i].size()-(long long)prog.size(); best[i]=prog;
            // mark the improved program's k=0 job as done by us only if we keep searching it later; leave it claimable
        }
        int jd=++jobsDone;
        fprintf(stderr,"[k%d #%d] case %d R=%d need=%d: %zu -> %zu %s (saved %lld, %.0fs)\n",kk,jd,i,cs[i].R,cs[i].need,L0,best[i].size(),ok?"":"VERIFY-FAIL",saved.load(),chrono::duration<double>(chrono::steady_clock::now()-T0).count());
        writeOut();
    } });
    for(auto&t:th) t.join();
    // final full verification
    long long tot=0; int fails=0;
    for(int i=0;i<n;i++){ int r; int c=simulate(*cxs[i].G,cxs[i],best[i],r); if(c!=cs[i].need){ fails++; best[i]=progs[i]; } tot+=best[i].size(); }
    writeOut();
    fprintf(stderr,"%s: final total %lld (orig %lld), verify-fails reverted %d\n",outp.c_str(),tot,tot0,fails);
}
