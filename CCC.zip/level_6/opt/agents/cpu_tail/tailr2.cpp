// tailr.cpp: CPU tail search for CCC42 level 6 (based on v3.cpp), destroyed-pattern prune REMOVED.
// usage: tailr <rankStart(0-based)> <W> <threads> [rankEnd] [log]
// reads ../input/in_level-6_{3-large,4-enormous}.txt and w_<fid>.out, writes x_lZ.out / x_eZ.out (atomic replace)
#include <bits/stdc++.h>
#include <windows.h>
using namespace std;
static int WDONE=300, WPOT=4, WACT=3, WNEAR=3;
template<int NW> struct BB {
    uint64_t w[NW];
    BB(){ for(int i=0;i<NW;i++) w[i]=0; }
    inline BB operator&(const BB&o)const{BB r; for(int i=0;i<NW;i++) r.w[i]=w[i]&o.w[i]; return r;}
    inline BB operator|(const BB&o)const{BB r; for(int i=0;i<NW;i++) r.w[i]=w[i]|o.w[i]; return r;}
    inline BB operator~()const{BB r; for(int i=0;i<NW;i++) r.w[i]=~w[i]; return r;}
    inline BB& operator|=(const BB&o){for(int i=0;i<NW;i++) w[i]|=o.w[i]; return *this;}
    inline BB& operator&=(const BB&o){for(int i=0;i<NW;i++) w[i]&=o.w[i]; return *this;}
    inline bool any()const{uint64_t x=0; for(int i=0;i<NW;i++) x|=w[i]; return x!=0;}
    inline int count()const{int c=0; for(int i=0;i<NW;i++) c+=__builtin_popcountll(w[i]); return c;}
    inline void set(int i){w[i>>6]|=1ULL<<(i&63);}
    inline bool test(int i)const{return (w[i>>6]>>(i&63))&1;}
    inline bool operator==(const BB&o)const{for(int i=0;i<NW;i++) if(w[i]!=o.w[i]) return false; return true;}
};
template<int NW> struct Geo {
    int R, rows, cols, M; vector<string> g; vector<pair<int,int>> ring; int start[6];
    vector<vector<int>> id; int ncell;
    vector<vector<BB<NW>>> beam; // [e][p]
    int D[6][2] = {{0,2},{1,1},{1,-1},{0,-2},{-1,-1},{-1,1}};
    Geo(int R_):R(R_){
        rows=2*R+1; cols=4*R+1; g.assign(rows,string(cols,'-')); id.assign(rows,vector<int>(cols,-1)); ncell=0;
        for(int i=0;i<rows;i++){int off=abs(i-R); for(int j=off;j<=cols-1-off;j+=2){bool b=(i==0||i==rows-1||j==off||j==cols-1-off); g[i][j]=b?'*':'O'; if(!b) id[i][j]=ncell++;}}
        for(int t=0;t<R;t++) ring.push_back({0,R+2*t}); for(int t=0;t<R;t++) ring.push_back({t,3*R+t});
        for(int t=0;t<R;t++) ring.push_back({R+t,4*R-t}); for(int t=0;t<R;t++) ring.push_back({2*R,3*R-2*t});
        for(int t=0;t<R;t++) ring.push_back({2*R-t,R-t}); for(int t=0;t<R;t++) ring.push_back({R-t,t});
        M=ring.size(); int s[6]={5*R,0,R,2*R,3*R,4*R}; for(int e=0;e<6;e++)start[e]=s[e];
        beam.assign(6,vector<BB<NW>>(M));
        for(int e=0;e<6;e++)for(int p=0;p<M;p++){int y=ring[p].first+D[e][0],x=ring[p].second+D[e][1]; while(y>=0&&y<rows&&x>=0&&x<cols){ if(id[y][x]>=0) beam[e][p].set(id[y][x]); y+=D[e][0];x+=D[e][1];}}
    }
};
struct Case { int R,rows,cols,need; vector<string> pat; };
typedef vector<uint16_t> Prog;
static inline unsigned long long mix64(unsigned long long x){x^=x>>30;x*=0xbf58476d1ce4e5b9ULL;x^=x>>27;x*=0x94d049bb133111ebULL;x^=x>>31;return x;}
template<int NW> struct ST { unsigned char pos[6]; unsigned char act; int copies; BB<NW> board; long long score; unsigned long long h; int parent; unsigned short mv; };

template<int NW> struct Solver {
    typedef BB<NW> BS; typedef ST<NW> S;
    const Case& c; Geo<NW> G; BS pat, adj; int npat;
    Solver(const Case& c_):c(c_),G(c_.R){
        vector<pair<int,int>> pm;
        for(int i=0;i<c.rows;i++)for(int j=0;j<c.cols;j++) if(c.pat[i][j]=='M'){pat.set(G.id[i][j]); pm.push_back({i,j});}
        npat=pat.count();
        int NBd[6][2]={{0,2},{0,-2},{1,1},{1,-1},{-1,1},{-1,-1}};
        for(auto&q:pm) for(auto&d:NBd){int y=q.first+d[0],x=q.second+d[1]; if(y>=0&&y<G.rows&&x>=0&&x<G.cols&&G.id[y][x]>=0&&!pat.test(G.id[y][x])) adj.set(G.id[y][x]);}
    }
    struct Full { unsigned char pos[6]; unsigned char act; int copies; BS board; int firstDone; };
    // exact port of nano6.simulate over first `upto` lines (full board incl. stray matter)
    Full sim(const Prog& p, int upto){
        Full f; for(int e=0;e<6;e++) f.pos[e]=G.start[e]; f.act=0; f.copies=0; f.firstDone=-1;
        for(int i=0;i<upto;i++){
            int m=p[i];
            for(int e=0;e<6;e++){int o=m&3; m>>=2; if(o==1)f.pos[e]=(f.pos[e]+1)%G.M; else if(o==2)f.pos[e]=(f.pos[e]+G.M-1)%G.M; else if(o==3)f.act^=(1<<e);}
            BS c1,c2,c3; for(int e=0;e<6;e++) if(f.act>>e&1){const BS&b=G.beam[e][f.pos[e]]; c3|=c2&b; c2|=c1&b; c1|=b;}
            f.board=(f.board|(c2&~c3))&~c3;
            if((f.board&pat)==pat && !(f.board&adj).any()){ f.copies++; f.board&=~pat; if(f.copies==c.need && f.firstDone<0) f.firstDone=i+1; }
        }
        return f;
    }
    bool valid(const Prog& p){ return sim(p,(int)p.size()).copies==c.need; }
    static void compact(vector<S>& b, size_t K){
        sort(b.begin(), b.end(), [](const S&x,const S&y){ return x.h!=y.h ? x.h<y.h : x.score>y.score; });
        size_t w=0; for(size_t i=0;i<b.size();i++){ if(w>0 && b[w-1].h==b[i].h) continue; if(w!=i) b[w]=b[i]; w++; } b.resize(w);
        if(b.size()>K){ nth_element(b.begin(), b.begin()+K, b.end(), [](const S&x,const S&y){return x.score>y.score;}); b.resize(K); }
    }
    vector<S> origStates(const Full& f0, const Prog& p, int cut, int maxD){
        vector<S> r; S s; memset(&s,0,sizeof s); for(int e=0;e<6;e++) s.pos[e]=f0.pos[e]; s.act=f0.act; s.copies=f0.copies; s.board=f0.board&pat;
        int M=G.M;
        for(int d=1; d<=maxD && cut+d-1<(int)p.size(); d++){
            int mv=p[cut+d-1], m=mv; S t=s;
            for(int e=0;e<6;e++){int o=m&3; m>>=2; if(o==1)t.pos[e]=(t.pos[e]+1)%M; else if(o==2)t.pos[e]=(t.pos[e]+M-1)%M; else if(o==3)t.act^=(1<<e);}
            BS c1,c2,c3; for(int e=0;e<6;e++) if(t.act>>e&1){const BS&b=G.beam[e][t.pos[e]]; c3|=c2&b; c2|=c1&b; c1|=b;}
            BS created=c2&~c3; if((created&adj).any()) break;
            BS nb=(s.board|created)&~c3; t.copies=s.copies;
            if((nb&pat)==pat){ t.copies++; nb&=~pat; }
            nb&=pat; t.board=nb; t.mv=(unsigned short)mv; t.score=0;
            unsigned long long h=t.act; for(int e=0;e<6;e++) h=h*131+t.pos[e]; h=h*1000003+t.copies;
            for(int w=0;w<NW;w++) h=h*1000000007ULL+t.board.w[w];
            t.h=mix64(h); r.push_back(t); s=t;
        }
        return r;
    }
    bool beam(const Full& f0, int W, int maxDepth, Prog& out, const vector<S>* orig=nullptr){
        S s0; memset(&s0,0,sizeof s0); for(int e=0;e<6;e++) s0.pos[e]=f0.pos[e]; s0.act=f0.act; s0.copies=f0.copies; s0.board=f0.board&pat; s0.parent=-1; s0.mv=0;
        vector<S> cur{s0}; vector<vector<pair<int,uint16_t>>> hist;
        const size_t C=(size_t)W*4, K=(size_t)W;
        vector<S> buf; buf.reserve(C+8);
        size_t HS=1; while(HS<4*C) HS<<=1; vector<uint32_t> hgen(HS,0), hidx(HS); vector<uint64_t> hkey(HS); uint32_t gen=1;
        auto hins=[&](const S& t){ size_t sl=t.h&(HS-1); while(hgen[sl]==gen){ if(hkey[sl]==t.h){ uint32_t ix=hidx[sl]; if(t.score>buf[ix].score) buf[ix]=t; return; } sl=(sl+1)&(HS-1);} hgen[sl]=gen; hkey[sl]=t.h; hidx[sl]=(uint32_t)buf.size(); buf.push_back(t); };
        auto hcompact=[&](size_t KK){ if(buf.size()>KK){ nth_element(buf.begin(), buf.begin()+KK, buf.end(), [](const S&x,const S&y){return x.score>y.score;}); buf.resize(KK);} gen++; for(uint32_t i=0;i<buf.size();i++){ size_t sl=buf[i].h&(HS-1); while(hgen[sl]==gen) sl=(sl+1)&(HS-1); hgen[sl]=gen; hkey[sl]=buf[i].h; hidx[sl]=i; } };
        int M=G.M; vector<int> nearv(6*M);
        int origPrev=0; // index of original-trajectory state in cur
        for(int d=1; d<=maxDepth; d++){
            buf.clear(); gen++; long long T=LLONG_MIN; int found=-1; int foundmv=0;
            for(int pi=0; pi<(int)cur.size() && found<0; pi++){
                const S& s=cur[pi]; BS needed=pat&~s.board;
                for(int e=0;e<6;e++){
                    int* nr=&nearv[e*M];
                    for(int p=0;p<M;p++) nr[p]=(G.beam[e][p]&needed).any()?0:1000;
                    for(int k=0;k<2*M;k++){int p=k%M, q=(p+M-1)%M; if(nr[q]+1<nr[p]) nr[p]=nr[q]+1;}
                    for(int k=2*M-1;k>=0;k--){int p=k%M, q=(p+1)%M; if(nr[q]+1<nr[p]) nr[p]=nr[q]+1;}
                    for(int p=0;p<M;p++) if(nr[p]>=1000) nr[p]=M;
                }
                // incremental enumeration over emitters: level arrays
                BS L1[7],L2[7],L3[7]; unsigned char LA[7]; int LM[7]; int oc[6]; unsigned char tp[6];
                L1[0]=BS(); L2[0]=BS(); L3[0]=BS(); LA[0]=s.act; LM[0]=0;
                int lev=0; oc[0]=-1;
                while(lev>=0){
                    if(found>=0) break;
                    oc[lev]++; if(oc[lev]>3){ lev--; continue; }
                    { int e=lev, o=oc[lev]; int p=s.pos[e]; unsigned char a=LA[e];
                      if(o==1) p=(p+1)%M; else if(o==2) p=(p+M-1)%M; else if(o==3) a^=(1<<e);
                      tp[e]=(unsigned char)p; LA[e+1]=a; LM[e+1]=LM[e]|(o<<(2*e));
                      if(a>>e&1){ const BS& b=G.beam[e][p]; L3[e+1]=L3[e]|(L2[e]&b); L2[e+1]=L2[e]|(L1[e]&b); L1[e+1]=L1[e]|b; }
                      else { L1[e+1]=L1[e]; L2[e+1]=L2[e]; L3[e+1]=L3[e]; }
                      if(lev<5){ lev++; oc[lev]=-1; continue; } }
                    int mv=LM[6];
                    S t; for(int e=0;e<6;e++) t.pos[e]=tp[e]; t.act=LA[6];
                    const BS& c2=L2[6]; const BS& c3=L3[6];
                    BS created=c2&~c3;
                    if((created&adj).any()) continue;            // matter adjacent to pattern blocks collection
                    BS nb=(s.board|created)&~c3;                 // NOTE: destroying pattern matter allowed
                    t.copies=s.copies;
                    if((nb&pat)==pat){ t.copies++; nb&=~pat; if(t.copies==c.need){ found=pi; foundmv=mv; break; } }
                    nb&=pat; t.board=nb;
                    int donec=nb.count(); BS need2=pat&~nb;
                    int pot=0, dsum=0, potA=0;
                    for(int e=0;e<6;e++){ const BS& b=G.beam[e][t.pos[e]]; int onl=(b&need2).count(); if(t.act>>e&1) potA+=onl; else pot+=onl; dsum+=nearv[e*M+t.pos[e]]; }
                    t.score=(long long)t.copies*100000 + (long long)donec*WDONE + (long long)(pot+potA*WACT)*WPOT - (long long)dsum*WNEAR;
                    if(t.score<=T) continue;
                    unsigned long long h=t.act; for(int e=0;e<6;e++) h=h*131+t.pos[e]; h=h*1000003+t.copies;
                    for(int w=0;w<NW;w++) h=h*1000000007ULL+t.board.w[w];
                    t.h=mix64(h); t.parent=pi; t.mv=(unsigned short)mv;
                    hins(t);
                    if(buf.size()>=C){ hcompact(K); if(buf.size()>=K){ long long mn=LLONG_MAX; for(auto&x:buf) mn=min(mn,x.score); T=mn; } }
                }
            }
            if(found>=0){
                Prog mv(d); mv[d-1]=(uint16_t)foundmv; int idx=found;
                for(int L=d-1; L>=1; L--){ mv[L-1]=hist[L-1][idx].second; idx=hist[L-1][idx].first; }
                out=mv; return true;
            }
            if(buf.empty()) return false;
            hcompact((size_t)W);
            if(orig && d-1 < (int)orig->size()){
                S o=(*orig)[d-1]; o.parent=origPrev; int fx=-1;
                size_t sl=o.h&(HS-1); while(hgen[sl]==gen){ if(hkey[sl]==o.h){ fx=(int)hidx[sl]; break; } sl=(sl+1)&(HS-1); }
                if(fx<0){ buf.push_back(o); fx=(int)buf.size()-1; }
                origPrev=fx;
            }
            vector<pair<int,uint16_t>> hh(buf.size()); for(size_t i=0;i<buf.size();i++) hh[i]={buf[i].parent,buf[i].mv};
            hist.push_back(move(hh)); cur.assign(buf.begin(),buf.end());
        }
        return false;
    }
};

struct FileData { string fid, tag; vector<Case> cs; vector<Prog> best; vector<int> orig; };
static vector<FileData> FD; static mutex MU; static atomic<bool> dirty(false);
static string OPT="C:/Users/Student 06/CCC_auto/games/ccc42/level_6/opt/";
static FILE* LOG;

static Prog parseBlock(const string& b, bool& ok){
    Prog p; ok=true; istringstream ss(b); string line;
    while(getline(ss,line)){ istringstream ls(line); string tok; int e=0, mv=0; bool any=false;
        while(ls>>tok){ any=true; int o; if(tok=="-")o=0; else if(tok=="F")o=1; else if(tok=="B")o=2; else if(tok=="T")o=3; else {ok=false; o=0;} if(e<6) mv|=o<<(2*e); e++; }
        if(!any) continue; if(e!=6) ok=false; p.push_back((uint16_t)mv); }
    return p;
}
static string progStr(const Prog& p){ static const char INS[4]={'-','F','B','T'}; string s; for(size_t i=0;i<p.size();i++){ int m=p[i]; for(int e=0;e<6;e++){ s+=INS[m&3]; m>>=2; s+=(e==5?'\n':' '); } } return s; }
static void writeAll(){
    lock_guard<mutex> lk(MU);
    for(auto& f: FD){
        string s; long long tot=0, orig=0;
        for(size_t i=0;i<f.best.size();i++){ string b=progStr(f.best[i]); if(!b.empty()&&b.back()=='\n') b.pop_back(); s+=b; s+= (i+1<f.best.size()? "\n\n" : "\n"); tot+=f.best[i].size(); orig+=f.orig[i]; }
        string fn=OPT+"x_"+f.tag+(getenv("OUTS")?getenv("OUTS"):"Z")+".out", tmp=fn+".tmp";
        FILE* o=fopen(tmp.c_str(),"wb"); if(!o) continue; fwrite(s.data(),1,s.size(),o); fclose(o);
        MoveFileExA(tmp.c_str(), fn.c_str(), MOVEFILE_REPLACE_EXISTING);
        fprintf(LOG,"WRITE %s total %lld orig %lld saved %lld\n", fn.c_str(), tot, orig, orig-tot); fflush(LOG);
    }
}
static int nwOf(int R){ int r=R-1; int ncell=3*r*(r+1)+1; return (ncell+63)/64; }

template<int NW> void doCase(int fi, int ci, int W, const vector<double>& fracs){
    const Case& c=FD[fi].cs[ci]; Solver<NW> sv(c);
    Prog p; { lock_guard<mutex> lk(MU); p=FD[fi].best[ci]; }
    if(!sv.valid(p)){ fprintf(LOG,"INVALID start %s #%d\n",FD[fi].fid.c_str(),ci); fflush(LOG); return; }
    { auto f=sv.sim(p,(int)p.size()); if(f.firstDone>0 && f.firstDone<(int)p.size()){ Prog q(p.begin(),p.begin()+f.firstDone); if(sv.valid(q)){ p=q; lock_guard<mutex> lk(MU); if(p.size()<FD[fi].best[ci].size()){FD[fi].best[ci]=p; dirty=true;} } } }
    for(double fr: fracs){
        int L=(int)p.size(); int cut=(int)llround(fr*L); if(cut<1) continue; int maxD=L-cut-1; if(maxD<1) continue;
        auto f=sv.sim(p,cut);
        if((f.board&sv.adj).any()) { fprintf(LOG,"skipcut %s #%d cut %d (adj matter)\n",FD[fi].fid.c_str(),ci,cut); continue; }
        if(f.copies>=c.need) continue;
        auto t0=chrono::steady_clock::now(); Prog suf;
        auto os=sv.origStates(f,p,cut,maxD);
        bool ok=sv.beam(f,W,maxD,suf,getenv("NOFORCE")?nullptr:&os);
        double dt=chrono::duration<double>(chrono::steady_clock::now()-t0).count();
        if(ok){
            Prog q(p.begin(),p.begin()+cut); q.insert(q.end(),suf.begin(),suf.end());
            if(q.size()<p.size() && sv.valid(q)){
                fprintf(LOG,"IMPROVED %s #%d cut %d/%d: %d -> %d (%.1fs W%d)\n",FD[fi].fid.c_str(),ci,cut,L,L,(int)q.size(),dt,W); fflush(LOG);
                p=q; lock_guard<mutex> lk(MU); if(p.size()<FD[fi].best[ci].size()){ FD[fi].best[ci]=p; dirty=true; }
            } else { fprintf(LOG,"REJECT %s #%d cut %d: len %d valid %d\n",FD[fi].fid.c_str(),ci,cut,(int)q.size(),(int)sv.valid(q)); fflush(LOG); }
        } else { fprintf(LOG,"nofind %s #%d cut %d/%d (%.1fs)\n",FD[fi].fid.c_str(),ci,cut,L,dt); fflush(LOG); }
    }
}
static void doAny(int fi,int ci,int W,const vector<double>& fr){
    switch(nwOf(FD[fi].cs[ci].R)){ case 1: doCase<1>(fi,ci,W,fr); break; case 2: doCase<2>(fi,ci,W,fr); break; case 3: doCase<3>(fi,ci,W,fr); break; case 4: doCase<4>(fi,ci,W,fr); break;
        case 5: doCase<5>(fi,ci,W,fr); break; case 6: doCase<6>(fi,ci,W,fr); break; case 7: doCase<7>(fi,ci,W,fr); break; default: doCase<8>(fi,ci,W,fr); break; }
}
template<int NW> static bool validAt(int k,int i){ Solver<NW> s(FD[k].cs[i]); return s.valid(FD[k].best[i]); }

int main(int argc,char**argv){
    int rs=argc>1?atoi(argv[1]):59; int W=argc>2?atoi(argv[2]):2048; int TH=argc>3?atoi(argv[3]):10; int re=argc>4?atoi(argv[4]):1000000;
    string logfn=argc>5?argv[5]:"tailr.log"; LOG=fopen(logfn.c_str(),"a"); if(!LOG) LOG=stderr;
    if(argc>6) OPT=argv[6];
    vector<double> fracs={0.7,0.5,0.25};
    if(getenv("FRACS")){ fracs.clear(); string fs=getenv("FRACS"); stringstream q(fs); string tok; while(getline(q,tok,',')) fracs.push_back(atof(tok.c_str())); }
    const char* fids[2]={"3-large","4-enormous"}; const char* tags[2]={"l","e"};
    for(int k=0;k<2;k++){
        FileData f; f.fid=fids[k]; f.tag=tags[k];
        ifstream in(OPT+"../input/in_level-6_"+f.fid+".txt"); int n; in>>n; f.cs.resize(n);
        for(auto&c:f.cs){ in>>c.R>>c.rows>>c.cols>>c.need; c.pat.resize(c.rows); for(auto&r:c.pat) in>>r; }
        ifstream wi(OPT+"w_"+f.fid+".out", ios::binary); stringstream ss; ss<<wi.rdbuf(); string all=ss.str();
        string t; for(char ch: all) if(ch!='\r') t+=ch;
        vector<string> blocks; size_t pos=0; while(true){ size_t q=t.find("\n\n",pos); string b=t.substr(pos, q==string::npos? string::npos : q-pos); bool nonws=false; for(char ch:b) if(!isspace((unsigned char)ch)) nonws=true; if(nonws) blocks.push_back(b); if(q==string::npos) break; pos=q+2; }
        if((int)blocks.size()!=n){ fprintf(stderr,"block count mismatch %s %d vs %d\n",f.fid.c_str(),(int)blocks.size(),n); return 1; }
        for(auto&b:blocks){ bool ok; Prog p=parseBlock(b,ok); if(!ok){fprintf(stderr,"parse fail\n"); return 1;} f.best.push_back(p); f.orig.push_back((int)p.size()); }
        FD.push_back(f);
    }
    int bad=0; long long tot=0;
    for(int k=0;k<2;k++) for(size_t i=0;i<FD[k].cs.size();i++){ bool v;
        switch(nwOf(FD[k].cs[i].R)){ case 1: v=validAt<1>(k,i); break; case 2: v=validAt<2>(k,i); break; case 3: v=validAt<3>(k,i); break; case 4: v=validAt<4>(k,i); break;
            case 5: v=validAt<5>(k,i); break; case 6: v=validAt<6>(k,i); break; case 7: v=validAt<7>(k,i); break; default: v=validAt<8>(k,i); break; }
        if(!v) bad++; tot+=FD[k].best[i].size(); }
    fprintf(LOG,"start: total %lld, invalid(by C++ sim) %d\n",tot,bad); fflush(LOG);
    if(getenv("EXTRA")){ string ex=getenv("EXTRA"); stringstream q(ex); string nm;
        while(getline(q,nm,',')) for(int k=0;k<2;k++){
            string fn=OPT+"x_"+FD[k].tag+nm+".out"; ifstream wi(fn, ios::binary); if(!wi) continue; stringstream ss; ss<<wi.rdbuf(); string all=ss.str();
            string t; for(char ch: all) if(ch!='\r') t+=ch;
            vector<string> blocks; size_t pos=0; while(true){ size_t qq=t.find("\n\n",pos); string b=t.substr(pos, qq==string::npos? string::npos : qq-pos); bool nonws=false; for(char ch:b) if(!isspace((unsigned char)ch)) nonws=true; if(nonws) blocks.push_back(b); if(qq==string::npos) break; pos=qq+2; }
            if(blocks.size()!=FD[k].cs.size()) { fprintf(LOG,"EXTRA %s: block mismatch\n",fn.c_str()); continue; }
            int took=0;
            for(size_t i=0;i<blocks.size();i++){ bool ok; Prog p=parseBlock(blocks[i],ok); if(!ok || p.size()>=FD[k].best[i].size()) continue;
                Prog sv=FD[k].best[i]; FD[k].best[i]=p; bool v;
                switch(nwOf(FD[k].cs[i].R)){ case 1: v=validAt<1>(k,i); break; case 2: v=validAt<2>(k,i); break; case 3: v=validAt<3>(k,i); break; case 4: v=validAt<4>(k,i); break;
                    case 5: v=validAt<5>(k,i); break; case 6: v=validAt<6>(k,i); break; case 7: v=validAt<7>(k,i); break; default: v=validAt<8>(k,i); break; }
                if(!v) FD[k].best[i]=sv; else took++; }
            fprintf(LOG,"EXTRA %s: took %d\n",fn.c_str(),took); fflush(LOG);
        } }
    vector<tuple<int,int,int>> jobs; for(int k=0;k<2;k++) for(size_t i=0;i<FD[k].cs.size();i++) jobs.push_back({-(int)FD[k].best[i].size(),k,(int)i});
    stable_sort(jobs.begin(),jobs.end());
    vector<pair<int,int>> order; for(int r=rs;r<(int)jobs.size()&&r<re;r++) order.push_back({get<1>(jobs[r]),get<2>(jobs[r])});
    fprintf(LOG,"jobs %d (ranks %d..), W=%d TH=%d\n",(int)order.size(),rs+1,W,TH); fflush(LOG);
    if(TH==0) return 0;
    writeAll();
    atomic<int> idx(0); atomic<int> doneCnt(0); atomic<bool> fin(false);
    thread wr([&]{ while(!fin){ for(int i=0;i<100&&!fin;i++) this_thread::sleep_for(chrono::milliseconds(200)); if(dirty.exchange(false)) writeAll(); } });
    vector<thread> th; for(int t=0;t<TH;t++) th.emplace_back([&]{ for(;;){ int i=idx++; if(i>=(int)order.size()) break; doAny(order[i].first,order[i].second,W,fracs);
        int dc=++doneCnt; fprintf(LOG,"done %d/%d (%s #%d)\n",dc,(int)order.size(),FD[order[i].first].fid.c_str(),order[i].second); fflush(LOG); } });
    for(auto&t:th) t.join(); fin=true; wr.join(); dirty=false; writeAll();
    fprintf(LOG,"FINISHED\n"); fflush(LOG);
}
