// static6: find a static beam configuration that creates the whole pattern in one tick (1 line per copy).
// usage: static6 <in> <prog> <out>
#include <bits/stdc++.h>
using namespace std;
struct Geo {
    int R, rows, cols, M; vector<string> g; vector<pair<int,int>> ring; int start[6];
    vector<vector<int>> id; int ncell; vector<vector<int>> bc;
    int D[6][2] = {{0,2},{1,1},{1,-1},{0,-2},{-1,-1},{-1,1}};
    Geo(int R_):R(R_){
        rows=2*R+1; cols=4*R+1; g.assign(rows,string(cols,'-')); id.assign(rows,vector<int>(cols,-1)); ncell=0;
        for(int i=0;i<rows;i++){int off=abs(i-R); for(int j=off;j<=cols-1-off;j+=2){bool b=(i==0||i==rows-1||j==off||j==cols-1-off); g[i][j]=b?'*':'O'; if(!b) id[i][j]=ncell++;}}
        for(int t=0;t<R;t++) ring.push_back({0,R+2*t}); for(int t=0;t<R;t++) ring.push_back({t,3*R+t});
        for(int t=0;t<R;t++) ring.push_back({R+t,4*R-t}); for(int t=0;t<R;t++) ring.push_back({2*R,3*R-2*t});
        for(int t=0;t<R;t++) ring.push_back({2*R-t,R-t}); for(int t=0;t<R;t++) ring.push_back({R-t,t});
        M=ring.size(); int s[6]={5*R,0,R,2*R,3*R,4*R}; for(int e=0;e<6;e++)start[e]=s[e];
        bc.assign(6*M,{});
        for(int e=0;e<6;e++)for(int p=0;p<M;p++){int y=ring[p].first+D[e][0],x=ring[p].second+D[e][1]; while(y>=0&&y<rows&&x>=0&&x<cols){ if(id[y][x]>=0) bc[e*M+p].push_back(id[y][x]); y+=D[e][0];x+=D[e][1];}}
    }
    int rd(int p,int q)const{int f=((q-p)%M+M)%M; return min(f,M-f);}
    int dir(int p,int q)const{int f=((q-p)%M+M)%M; return f<=M-f?1:-1;}
};
struct Case { int R, rows, cols, need; vector<string> pat; };
int main(int argc,char**argv){
    ifstream in(argv[1]); int n; in>>n; vector<Case> cs(n);
    for(auto&c:cs){ in>>c.R>>c.rows>>c.cols>>c.need; c.pat.resize(c.rows); for(auto&r:c.pat) in>>r; }
    ifstream pf(argv[2]); stringstream ss; ss<<pf.rdbuf(); string all=ss.str(); all.erase(remove(all.begin(),all.end(),'\r'),all.end());
    vector<vector<string>> blocks; { vector<string> cur; string line; stringstream ls(all);
        while(getline(ls,line)){ bool blank=line.find_first_not_of(" \t")==string::npos; if(blank){ if(!cur.empty()){blocks.push_back(cur);cur.clear();} continue; } cur.push_back(line);} if(!cur.empty()) blocks.push_back(cur); }
    if((int)blocks.size()!=n){ fprintf(stderr,"block mismatch\n"); return 1; }
    ofstream out(argv[3]); long long tot0=0,tot1=0; int imp=0, found=0;
    for(int ci=0;ci<n;ci++){
        const Case& c=cs[ci]; Geo G(c.R); int M=G.M;
        vector<int> cidx(G.ncell,-1); int npat=0; vector<pair<int,int>> pm;
        for(int r=0;r<G.rows;r++) for(int q=0;q<G.cols;q++) if(c.pat[r][q]=='M'&&G.id[r][q]>=0){ cidx[G.id[r][q]]=npat++; pm.push_back({r,q}); }
        int ntot=npat; int NBd[6][2]={{0,2},{0,-2},{1,1},{1,-1},{-1,1},{-1,-1}};
        for(auto&p:pm) for(auto&d:NBd){ int y=p.first+d[0], z=p.second+d[1]; if(y>=0&&y<G.rows&&z>=0&&z<G.cols&&G.id[y][z]>=0&&cidx[G.id[y][z]]<0) cidx[G.id[y][z]]=ntot++; }
        vector<vector<int>> bcc(6*M); for(int k=0;k<6*M;k++) for(int gid:G.bc[k]) if(cidx[gid]>=0) bcc[k].push_back(cidx[gid]);
        vector<vector<int>> cand(6); for(int e=0;e<6;e++){ cand[e].push_back(-1); for(int p=0;p<M;p++){ bool hit=false; for(int x:bcc[e*M+p]) if(x<npat){hit=true;break;} if(hit) cand[e].push_back(p);} }
        vector<int> cnt(ntot,0); int bestT=INT_MAX; int bestCfg[6];
        int cfg[6];
        function<void(int)> dfs=[&](int e){
            if(e==6){
                for(int i=0;i<npat;i++) if(cnt[i]!=2) return;
                for(int i=npat;i<ntot;i++) if(cnt[i]==2) return;
                int T=0; for(int k=0;k<6;k++) if(cfg[k]>=0) T=max(T,G.rd(G.start[k],cfg[k])+1);
                if(T<bestT){bestT=T; memcpy(bestCfg,cfg,sizeof cfg);} return;
            }
            for(int p:cand[e]){
                cfg[e]=p; bool bad=false;
                if(p>=0){ for(int x:bcc[e*M+p]){ cnt[x]++; if(x<npat&&cnt[x]>2) bad=true; } }
                if(!bad){
                    // feasibility: remaining emitters can add at most (5-e) hits per pattern cell
                    bool ok=true; int rem=5-e; for(int i=0;i<npat;i++) if(cnt[i]+rem<2){ok=false;break;}
                    if(ok) dfs(e+1);
                }
                if(p>=0) for(int x:bcc[e*M+p]) cnt[x]--;
            }
        };
        dfs(0);
        int L0=blocks[ci].size(); tot0+=L0;
        vector<string> best=blocks[ci];
        if(bestT<INT_MAX){
            found++;
            int L1=bestT+c.need-1;
            if(L1<L0 && !(blocks[ci].size()==1 && blocks[ci][0].find("FAIL")!=string::npos)){
                vector<string> prog; int pos[6]; for(int e=0;e<6;e++) pos[e]=G.start[e];
                for(int t=1;t<=bestT;t++){ string s="------";
                    for(int e=0;e<6;e++){ if(bestCfg[e]<0) continue; int d=G.rd(pos[e],bestCfg[e]);
                        if(d>0){ int dr=G.dir(pos[e],bestCfg[e]); s[e]= dr>0?'F':'B'; pos[e]=(pos[e]+dr+M)%M; }
                        else if(t==bestT) s[e]='T'; }
                    string o; for(int e=0;e<6;e++){ o+=s[e]; if(e<5) o+=' '; } prog.push_back(o); }
                for(int k=1;k<c.need;k++) prog.push_back("- - - - - -");
                best=prog; imp++;
                fprintf(stderr,"case %d R%d need %d npat %d: static T=%d -> %d lines (was %d)\n",ci,c.R,c.need,npat,bestT,L1,L0);
            }
        }
        tot1+=best.size();
        if(ci) out<<"\n"; for(auto&L:best) out<<L<<"\n";
    }
    fprintf(stderr,"%s: %lld -> %lld, static configs found in %d cases, improved %d\n",argv[3],tot0,tot1,found,imp);
}
