// cyc6: cycle splicing for CCC42 L6.  cyc6 <in> <prog> <out> [W=256] [threads=12] [lambda=4] [useC2=1] [extraDepth=3]
#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long u64;

struct Case { int R, rows, cols, need; vector<string> pat; };
struct Geo {
    int R, rows, cols, M; vector<string> g; vector<pair<int,int>> ring; int start[6];
    vector<vector<int>> id; int ncell; vector<vector<int>> bc; // [e*M+p] grid ids
    int D[6][2] = {{0,2},{1,1},{1,-1},{0,-2},{-1,-1},{-1,1}};
    Geo(int R_):R(R_){
        rows=2*R+1; cols=4*R+1; g.assign(rows,string(cols,'-')); id.assign(rows,vector<int>(cols,-1)); ncell=0;
        for(int i=0;i<rows;i++){int off=abs(i-R); for(int j=off;j<=cols-1-off;j+=2){bool b=(i==0||i==rows-1||j==off||j==cols-1-off); g[i][j]=b?'*':'O'; if(!b) id[i][j]=ncell++;}}
        for(int t=0;t<R;t++) ring.push_back({0,R+2*t}); for(int t=0;t<R;t++) ring.push_back({t,3*R+t});
        for(int t=0;t<R;t++) ring.push_back({R+t,4*R-t}); for(int t=0;t<R;t++) ring.push_back({2*R,3*R-2*t});
        for(int t=0;t<R;t++) ring.push_back({2*R-t,R-t}); for(int t=0;t<R;t++) ring.push_back({R-t,t});
        M=ring.size(); int s[6]={5*R,0,R,2*R,3*R,4*R}; for(int e=0;e<6;e++)start[e]=s[e];
        bc.assign(6*M,{});
        for(int e=0;e<6;e++)for(int p=0;p<M;p++){int y=ring[p].first+D[e][0],x=ring[p].second+D[e][1]; while(y>=0&&y<rows&&x>=0&&x<cols){ if(id[y][x]>=0) bc[e*M+p].push_back(id[y][x]); y+=D[e][0];x+=D[e][1];}}
    }
    int rd(int p,int q)const{int f=((q-p)%M+M)%M; return min(f,M-f);}
};

struct Ctx {
    Case c; Geo* G; int npat=0, nadj=0, ntot=0; vector<int> cidx; vector<vector<int>> bcc; // [e*M+p] combined idx
    vector<string> prog; bool fail=false;
    vector<int> tcol; // tick count (1-based) at each collection
    vector<array<int,7>> anc; // pos[6], act  ; anc[0]=start
    vector<int> ancNode; vector<array<int,7>> nodes;
};

// exact sim on pattern+adj cells. returns collection tick indices (0-based); final pos/act in st.
static vector<int> simulate(const Ctx& cx, array<int,7> st, const vector<string>& lines, vector<array<int,7>>* after=nullptr, array<int,7>* fin=nullptr){
    const Geo& G=*cx.G; int M=G.M; vector<char> board(cx.ntot,0); vector<int> cnt(cx.ntot,0); vector<int> res;
    for(size_t t=0;t<lines.size();t++){
        const string& L=lines[t];
        for(int e=0;e<6;e++){ char o=L[e]; if(o=='F') st[e]=(st[e]+1)%M; else if(o=='B') st[e]=(st[e]+M-1)%M; else if(o=='T') st[6]^=(1<<e); }
        fill(cnt.begin(),cnt.end(),0);
        for(int e=0;e<6;e++) if(st[6]>>e&1) for(int ci:cx.bcc[e*M+st[e]]) cnt[ci]++;
        for(int i=0;i<cx.ntot;i++){ if(cnt[i]==2) board[i]=1; else if(cnt[i]>=3) board[i]=0; }
        bool all=true; for(int i=0;i<cx.npat;i++) if(!board[i]){all=false;break;}
        if(all){ for(int i=cx.npat;i<cx.ntot;i++) if(board[i]){all=false;break;} }
        if(all){ res.push_back(t); for(int i=0;i<cx.npat;i++) board[i]=0; if(after) after->push_back(st); }
    }
    if(fin) *fin=st; return res;
}

template<int NW> struct Mk { u64 w[NW]; };
template<int NW> static inline Mk<NW> zero(){ Mk<NW> r; for(int i=0;i<NW;i++) r.w[i]=0; return r; }
template<int NW> static inline bool anyb(const Mk<NW>& a){ u64 x=0; for(int i=0;i<NW;i++) x|=a.w[i]; return x!=0; }
template<int NW> static inline int popm(const Mk<NW>& a){ int s=0; for(int i=0;i<NW;i++) s+=__builtin_popcountll(a.w[i]); return s; }
template<int NW> struct St { Mk<NW> board; u64 key; int score; int parent; unsigned short mv; unsigned char pos[6]; unsigned char act, copies; };

static inline u64 mix(u64 x){ x+=0x9e3779b97f4a7c15ULL; x=(x^(x>>30))*0xbf58476d1ce4e5b9ULL; x=(x^(x>>27))*0x94d049bb133111ebULL; return x^(x>>31); }

struct SearchRes { bool ok=false; vector<string> lines; int target=-1; };
static int g_prune=0;

template<int NW>
SearchRes searchCycle(const Ctx& cx, const array<int,7>& home, int C, int W, int maxDepth, int lambda, const vector<array<int,7>>* tg){
    const Geo& G=*cx.G; int M=G.M; SearchRes R;
    vector<array<int,7>> tgts; if(tg) tgts=*tg; else tgts.push_back(home); int NT=tgts.size();
    const bool PRUNE = (tg==nullptr) && g_prune;
    vector<int> rdT(NT*6*M); for(int t=0;t<NT;t++) for(int e=0;e<6;e++) for(int p=0;p<M;p++) rdT[(t*6+e)*M+p]=G.rd(p,tgts[t][e]);
    vector<Mk<NW>> bm(6*M, zero<NW>()); Mk<NW> PAT=zero<NW>(), ADJ=zero<NW>();
    for(int i=0;i<cx.npat;i++) PAT.w[i>>6]|=1ULL<<(i&63);
    for(int i=cx.npat;i<cx.ntot;i++) ADJ.w[i>>6]|=1ULL<<(i&63);
    for(int k=0;k<6*M;k++) for(int ci:cx.bcc[k]) bm[k].w[ci>>6]|=1ULL<<(ci&63);
    vector<vector<St<NW>>> layers; St<NW> s0; s0.board=zero<NW>(); s0.key=0; s0.score=0; s0.parent=-1; s0.mv=0;
    for(int e=0;e<6;e++) s0.pos[e]=home[e]; s0.act=home[6]; s0.copies=0; layers.push_back({s0});
    vector<St<NW>> buf; buf.reserve(8*W+8);
    vector<int> nearT(6*M); vector<int> rdh(6*M);
    for(int e=0;e<6;e++) for(int p=0;p<M;p++) rdh[e*M+p]=G.rd(p,home[e]);
    int foundParent=-1; unsigned short foundMv=0;
    auto prune=[&](size_t keep){
        sort(buf.begin(),buf.end(),[](const St<NW>&a,const St<NW>&b){ return a.key<b.key || (a.key==b.key && a.score>b.score); });
        buf.erase(unique(buf.begin(),buf.end(),[](const St<NW>&a,const St<NW>&b){return a.key==b.key;}),buf.end());
        if(buf.size()>keep){ nth_element(buf.begin(),buf.begin()+keep,buf.end(),[](const St<NW>&a,const St<NW>&b){return a.score>b.score;}); buf.resize(keep); }
    };
    for(int depth=0; depth<maxDepth && foundParent<0; depth++){
        vector<St<NW>>& cur=layers.back(); buf.clear(); int thr=INT_MIN;
        for(int pi=0; pi<(int)cur.size() && foundParent<0; pi++){
            const St<NW>& s=cur[pi]; bool phaseB = s.copies>=C;
            if(!phaseB){
                Mk<NW> needed; for(int i=0;i<NW;i++) needed.w[i]=PAT.w[i]&~s.board.w[i];
                for(int e=0;e<6;e++){
                    int* d=&nearT[e*M]; bool anyu=false;
                    for(int q=0;q<M;q++){ Mk<NW> x; for(int i=0;i<NW;i++) x.w[i]=bm[e*M+q].w[i]&needed.w[i]; d[q]=anyb(x)?0:1000000; if(!d[q]) anyu=true; }
                    if(!anyu){ for(int q=0;q<M;q++) d[q]=M; continue; }
                    for(int r=0;r<2;r++) for(int q=0;q<M;q++){ int pq=(q+M-1)%M; d[q]=min(d[q],d[pq]+1); }
                    for(int r=0;r<2;r++) for(int q=M-1;q>=0;q--){ int nq=(q+1)%M; d[q]=min(d[q],d[nq]+1); }
                }
            }
            unsigned char opos[6][4], oact[6][4]; Mk<NW> om[6][4]; bool okk[6][4];
            int remain = PRUNE ? (maxDepth-(depth+1)) : 1000;
            for(int e=0;e<6;e++) for(int o=0;o<4;o++){
                int np=s.pos[e]; if(o==1) np=(np+1)%M; else if(o==2) np=(np+M-1)%M; int a=(s.act>>e)&1; if(o==3) a^=1;
                opos[e][o]=np; oact[e][o]=a; om[e][o]= a? bm[e*M+np] : zero<NW>();
                okk[e][o] = rdh[e*M+np] + (a ^ ((home[6]>>e)&1)) <= remain;
            }
            // iterative DFS over 6 levels
            Mk<NW> c1[7],c2[7],c3[7]; c1[0]=c2[0]=c3[0]=zero<NW>(); int oc[6]; int lvl=0; oc[0]=-1;
            while(lvl>=0){
                oc[lvl]++; if(oc[lvl]>=4){ lvl--; continue; }
                if(!okk[lvl][oc[lvl]]) continue;
                const Mk<NW>& m=om[lvl][oc[lvl]];
                bool bad=false;
                for(int i=0;i<NW;i++){ c3[lvl+1].w[i]=c3[lvl].w[i]|(c2[lvl].w[i]&m.w[i]); c2[lvl+1].w[i]=c2[lvl].w[i]|(c1[lvl].w[i]&m.w[i]); c1[lvl+1].w[i]=c1[lvl].w[i]|m.w[i]; if(c3[lvl+1].w[i]&s.board.w[i]) bad=true; }
                if(bad) continue;
                if(lvl<5){ lvl++; oc[lvl]=-1; continue; }
                // leaf
                Mk<NW> cr; bool adjc=false, patc=false;
                for(int i=0;i<NW;i++){ cr.w[i]=c2[6].w[i]&~c3[6].w[i]; if(cr.w[i]&ADJ.w[i]) adjc=true; if(cr.w[i]&PAT.w[i]) patc=true; }
                if(adjc) continue;
                St<NW> t; t.copies=s.copies; t.parent=pi; unsigned short mv=0; unsigned char act=0;
                for(int e=0;e<6;e++){ mv|=oc[e]<<(2*e); t.pos[e]=opos[e][oc[e]]; act|=oact[e][oc[e]]<<e; }
                t.act=act; t.mv=mv;
                if(phaseB){ if(patc) continue; t.board=zero<NW>(); }
                else { bool full=true; for(int i=0;i<NW;i++){ t.board.w[i]=(s.board.w[i]|cr.w[i])&PAT.w[i]; if(t.board.w[i]!=PAT.w[i]) full=false; } if(full){ t.copies++; t.board=zero<NW>(); } }
                int sc;
                if(t.copies>=C){
                    int maxd=INT_MAX,sumd=0; int ft=-1;
                    for(int tt=0;tt<NT;tt++){ int mx=0,sm=0; for(int e=0;e<6;e++){ int d=rdT[(tt*6+e)*M+t.pos[e]] + (((t.act^tgts[tt][6])>>e)&1); mx=max(mx,d); sm+=d; } if(mx<maxd||(mx==maxd&&sm<sumd)){maxd=mx;sumd=sm;ft=tt;} }
                    if(maxd==0){ foundParent=pi; foundMv=mv; R.target=ft; break; }
                    sc=50000000 - maxd*10000 - sumd*10;
                } else {
                    int donec=popm(t.board); int pot=0,dsum=0,hm=0;
                    for(int e=0;e<6;e++){ Mk<NW> x; const Mk<NW>& b=bm[e*M+t.pos[e]]; for(int i=0;i<NW;i++) x.w[i]=b.w[i]&PAT.w[i]&~t.board.w[i]; int onl=popm(x); bool ac=(t.act>>e)&1; pot+= ac?3*onl:onl; dsum+=nearT[e*M+t.pos[e]]; hm+=rdh[e*M+t.pos[e]] + (((t.act^home[6])>>e)&1); }
                    sc=t.copies*100000 + donec*300 + pot*4 - dsum*3 - lambda*hm;
                }
                if(sc<thr) continue;
                t.score=sc;
                u64 k=0; for(int e=0;e<6;e++) k=(k<<8)|t.pos[e]; k=(k<<8)|t.act; k=(k<<4)|t.copies; k=mix(k);
                for(int i=0;i<NW;i++) k=mix(k^t.board.w[i]);
                t.key=k; buf.push_back(t);
                if((int)buf.size()>=8*W){ prune(W); if((int)buf.size()>=W){ int mn=INT_MAX; for(auto&x:buf) mn=min(mn,x.score); thr=mn; } }
            }
        }
        if(foundParent>=0) break;
        if(buf.empty()) return R;
        prune(W); layers.push_back(buf);
    }
    if(foundParent<0) return R;
    vector<int> mvs; mvs.push_back(foundMv); int li=layers.size()-1, si=foundParent;
    while(li>0){ mvs.push_back(layers[li][si].mv); si=layers[li][si].parent; li--; }
    reverse(mvs.begin(),mvs.end());
    const char INS[4]={'-','F','B','T'};
    for(int mv:mvs){ string s(6,'-'); for(int e=0;e<6;e++) s[e]=INS[(mv>>(2*e))&3]; R.lines.push_back(s); }
    R.ok=true; return R;
}

SearchRes runSearch(const Ctx& cx, const array<int,7>& home, int C, int W, int maxDepth, int lambda, const vector<array<int,7>>* tg){
    int nw=(cx.ntot+63)/64;
    if(nw<=1) return searchCycle<1>(cx,home,C,W,maxDepth,lambda,tg);
    if(nw==2) return searchCycle<2>(cx,home,C,W,maxDepth,lambda,tg);
    if(nw==3) return searchCycle<3>(cx,home,C,W,maxDepth,lambda,tg);
    return searchCycle<4>(cx,home,C,W,maxDepth,lambda,tg);
}

int main(int argc,char**argv){
    if(argc<4){fprintf(stderr,"usage\n");return 1;}
    int W=argc>4?atoi(argv[4]):256; int TH=argc>5?atoi(argv[5]):12; vector<int> lams; { string ls=argc>6?argv[6]:"4"; stringstream q(ls); string tok; while(getline(q,tok,',')) lams.push_back(atoi(tok.c_str())); } int useC2=argc>7?atoi(argv[7]):1; int extra=argc>8?atoi(argv[8]):3; int modes=argc>9?atoi(argv[9]):1; g_prune=argc>10?atoi(argv[10]):0;
    ifstream in(argv[1]); int n; in>>n; vector<Case> cs(n);
    for(auto&c:cs){ in>>c.R>>c.rows>>c.cols>>c.need; c.pat.resize(c.rows); for(auto&r:c.pat) in>>r; }
    // read program blocks
    ifstream pf(argv[2]); stringstream ss; ss<<pf.rdbuf(); string all=ss.str(); all.erase(remove(all.begin(),all.end(),'\r'),all.end());
    vector<vector<string>> blocks; { vector<string> cur; string line; stringstream ls(all);
        while(getline(ls,line)){ bool blank=line.find_first_not_of(" \t")==string::npos; if(blank){ if(!cur.empty()){blocks.push_back(cur);cur.clear();} continue; } cur.push_back(line);} if(!cur.empty()) blocks.push_back(cur); }
    if((int)blocks.size()!=n){ fprintf(stderr,"block count %zu != %d\n",blocks.size(),n); return 1; }
    vector<Ctx> cx(n); map<int,Geo*> geos;
    for(int i=0;i<n;i++){ if(!geos.count(cs[i].R)) geos[cs[i].R]=new Geo(cs[i].R); }
    struct Task{ int ci, node, C, maxDepth; double prio; int lam; int mode; };
    vector<Task> tasks;
    for(int i=0;i<n;i++){
        Ctx& x=cx[i]; x.c=cs[i]; x.G=geos[cs[i].R]; const Geo& G=*x.G;
        if(blocks[i].size()==1 && blocks[i][0].find("FAIL")!=string::npos){ x.fail=true; continue; }
        for(auto& L:blocks[i]){ string s; for(char ch:L) if(ch=='-'||ch=='F'||ch=='B'||ch=='T') s+=ch; if(s.size()!=6){ x.fail=true; } x.prog.push_back(s); }
        if(x.fail) continue;
        x.cidx.assign(G.ncell,-1); vector<pair<int,int>> pm;
        for(int r=0;r<G.rows;r++) for(int q=0;q<G.cols;q++) if(x.c.pat[r][q]=='M' && G.id[r][q]>=0){ x.cidx[G.id[r][q]]=x.npat++; pm.push_back({r,q}); }
        int NBd[6][2]={{0,2},{0,-2},{1,1},{1,-1},{-1,1},{-1,-1}}; x.ntot=x.npat;
        for(auto&p:pm) for(auto&d:NBd){ int y=p.first+d[0], z=p.second+d[1]; if(y>=0&&y<G.rows&&z>=0&&z<G.cols&&G.id[y][z]>=0&&x.cidx[G.id[y][z]]<0){ x.cidx[G.id[y][z]]=x.ntot++; } }
        x.nadj=x.ntot-x.npat; x.bcc.assign(6*G.M,{});
        for(int k=0;k<6*G.M;k++) for(int gid:G.bc[k]) if(x.cidx[gid]>=0) x.bcc[k].push_back(x.cidx[gid]);
        array<int,7> st0; for(int e=0;e<6;e++) st0[e]=G.start[e]; st0[6]=0;
        vector<array<int,7>> after; vector<int> col=simulate(x,st0,x.prog,&after);
        if((int)col.size()!=x.c.need){ fprintf(stderr,"case %d: orig collects %zu need %d -> skip\n",i,col.size(),x.c.need); x.fail=true; continue; }
        x.anc.push_back(st0); for(auto&a:after) x.anc.push_back(a);
        x.tcol.push_back(0); for(int t:col) x.tcol.push_back(t+1);
        for(auto&a:x.anc){ int f=-1; for(int k=0;k<(int)x.nodes.size();k++) if(x.nodes[k]==a){f=k;break;} if(f<0){f=x.nodes.size(); x.nodes.push_back(a);} x.ancNode.push_back(f); }
        if(x.c.need<3) continue;
        double avg=(double)x.tcol.back()/x.c.need;
        vector<char> added(x.nodes.size(),0);
        if(getenv("CYC_RMAX") && x.c.R>atoi(getenv("CYC_RMAX"))) continue;
        if(g_prune){
            for(int k=0;k+2<=x.c.need;k++){ int v=x.ancNode[k]; if(added[v]) continue; added[v]=1;
                double avA=(double)(x.tcol.back()-x.tcol[k])/(x.c.need-k);
                for(int C=1;C<=(useC2?2:1);C++){ int md=(int)ceil(C*avA-1e-9)-1+extra; if(md<1) continue; md=min(md,40);
                    for(int lm:lams) tasks.push_back({i,v,C,md,(double)(x.c.need-k)*avA,lm,0}); } }
            continue;
        }
        for(int k=0;k<x.c.need;k++){ int v=x.ancNode[k]; if(added[v]) continue; added[v]=1;
            for(int C=1;C<=(useC2?2:1);C++){ int md=min(60,(int)ceil(avg*C)+extra); for(int lm:lams){ if(modes&1) tasks.push_back({i,v,C,md,(double)(x.c.need-k)*avg,lm,0}); if((modes&2) && C==1) tasks.push_back({i,v,C,md,(double)(x.c.need-k)*avg,lm,1}); } } }
    }
    sort(tasks.begin(),tasks.end(),[](const Task&a,const Task&b){return a.prio>b.prio;});
    fprintf(stderr,"tasks %zu\n",tasks.size());
    vector<SearchRes> tres(tasks.size()); atomic<int> idx(0); atomic<int> doneCnt(0);
    auto t0=chrono::steady_clock::now();
    vector<thread> th; for(int t=0;t<TH;t++) th.emplace_back([&]{ for(;;){ int k=idx++; if(k>=(int)tasks.size()) break; const Task& T=tasks[k]; const Ctx& x=cx[T.ci];
        tres[k]=runSearch(x,x.nodes[T.node],T.C,W,T.maxDepth,T.lam,T.mode?&x.nodes:nullptr); if(getenv("CYCDBG")) fprintf(stderr,"T case %d node %d C %d need %d avg %.2f found %d len %zu\n",T.ci,T.node,T.C,x.c.need,(double)x.tcol.back()/x.c.need,(int)tres[k].ok,tres[k].lines.size()); int d=++doneCnt; if(d%50==0){ double el=chrono::duration<double>(chrono::steady_clock::now()-t0).count(); fprintf(stderr,"  %d/%zu tasks %.1fs\n",d,tasks.size(),el);} } });
    for(auto&t:th) t.join();
    // per-case DP
    vector<vector<int>> tasksOf(n); for(int k=0;k<(int)tasks.size();k++) tasksOf[tasks[k].ci].push_back(k);
    long long totOrig=0,totNew=0; int improved=0; ofstream out(argv[3]);
    for(int i=0;i<n;i++){
        Ctx& x=cx[i]; vector<string> best;
        if(x.fail){ if(i) out<<"\n"; if(blocks[i].size()==1 && blocks[i][0].find("FAIL")!=string::npos) out<<"FAIL\n"; else { for(auto&L:blocks[i]) out<<L<<"\n"; } continue; }
        int origLen=x.prog.size(); totOrig+=origLen; best=x.prog;
        if(x.c.need>=3){
            struct Edge{ int from,to,copies; vector<string> lines; vector<int> colls; };
            vector<Edge> E;
            for(int k=0;k<x.c.need;k++){ Edge e; e.from=x.ancNode[k]; e.to=x.ancNode[k+1]; e.copies=1; e.lines.assign(x.prog.begin()+x.tcol[k],x.prog.begin()+x.tcol[k+1]); e.colls={(int)e.lines.size()-1}; E.push_back(e); }
            for(int k:tasksOf[i]){ if(!tres[k].ok) continue; const Task& T=tasks[k]; Edge e; e.from=T.node; e.to=T.mode?tres[k].target:T.node; e.copies=T.C; e.lines=tres[k].lines;
                vector<array<int,7>> af; array<int,7> fs; e.colls=simulate(x,x.nodes[T.node],e.lines,&af,&fs);
                if(e.to<0 || (int)e.colls.size()!=T.C || fs!=x.nodes[e.to]) { fprintf(stderr,"case %d bad cycle\n",i); continue; }
                // verify end state equals home
                E.push_back(e); }
            int V=x.nodes.size(), N=x.c.need; const long long INF=1e18;
            vector<vector<long long>> dp(N+1,vector<long long>(V,INF)); vector<vector<pair<int,int>>> par(N+1,vector<pair<int,int>>(V,{-1,-1}));
            dp[0][x.ancNode[0]]=0;
            long long bestCost=INF; int bj=-1,bv=-1,be=-1,bc=-1;
            for(int j=0;j<N;j++) for(int v=0;v<V;v++){ if(dp[j][v]>=INF) continue;
                for(int ei=0;ei<(int)E.size();ei++){ const Edge& e=E[ei]; if(e.from!=v) continue;
                    if(j+e.copies<N){ long long c=dp[j][v]+e.lines.size(); if(c<dp[j+e.copies][e.to]){ dp[j+e.copies][e.to]=c; par[j+e.copies][e.to]={ei,v}; } }
                    for(int cp=1;cp<=e.copies;cp++) if(j+cp==N){ long long c=dp[j][v]+e.colls[cp-1]+1; if(c<bestCost){bestCost=c;bj=j;bv=v;be=ei;bc=cp;} }
                } }
            if(bestCost<origLen){
                vector<string> prog; vector<int> seq; int j=bj,v=bv;
                while(j>0){ auto pr=par[j][v]; seq.push_back(pr.first); int c=E[pr.first].copies; v=pr.second; j-=c; }
                reverse(seq.begin(),seq.end());
                for(int ei:seq) for(auto&L:E[ei].lines) prog.push_back(L);
                for(int t=0;t<=E[be].colls[bc-1];t++) prog.push_back(E[be].lines[t]);
                array<int,7> st0; for(int e=0;e<6;e++) st0[e]=x.G->start[e]; st0[6]=0;
                vector<int> col=simulate(x,st0,prog);
                if((int)col.size()==N && col.back()==(int)prog.size()-1){ best=prog; improved++; }
                else fprintf(stderr,"case %d verify fail (%zu vs %d)\n",i,col.size(),N);
            }
        }
        totNew+=best.size();
        if(i) out<<"\n";
        for(auto&L:best){ for(int e=0;e<6;e++){ out<<L[e]; out<<(e==5?'\n':' '); } }
    }
    fprintf(stderr,"%s: orig %lld new %lld improved %d\n",argv[3],totOrig,totNew,improved);
}
