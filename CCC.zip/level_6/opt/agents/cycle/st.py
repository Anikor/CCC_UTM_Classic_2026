import sys
from collections import Counter
D='C:/Users/Student 06/CCC_auto/games/ccc42/level_6/'
def parse(path):
    L=[l.rstrip('\n').rstrip('\r') for l in open(path)]
    i=0;n=int(L[i]);i+=1;cases=[]
    for _ in range(n):
        while L[i].strip()=='':i+=1
        R,rows,cols,cnt=map(int,L[i].split());i+=1
        pat=L[i:i+rows];i+=rows
        cases.append((R,rows,cols,cnt,pat))
    return cases
for fid in ['2-medium','3-large']:
    cs=parse(D+'input/in_level-6_%s.txt'%fid)
    blocks=[b for b in open(D+'opt/w_%s.out'%fid).read().replace('\r\n','\n').split('\n\n') if b.strip()]
    Rs=Counter(c[0] for c in cs)
    npat=[sum(r.count('M') for r in c[4]) for c in cs]
    tot=0; pot=0; rows=[]
    for c,b,np_ in zip(cs,blocks,npat):
        L=len(b.strip().split('\n'))
        tot+=L
        if c[3]>=3: pot+=L; rows.append((c[0],c[3],np_,L,round(L/c[3],2)))
    print(fid,len(cs),'R',sorted(Rs.items()),'npat max',max(npat),'tot',tot,'lines in need>=3',pot, 'n',len(rows))
    print(' need dist',sorted(Counter(c[3] for c in cs).items()))
    print(rows[:40])
