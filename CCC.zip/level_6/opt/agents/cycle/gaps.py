import sys
sys.argv=[sys.argv[0]]+sys.argv[1:]
D='C:/Users/Student 06/CCC_auto/games/ccc42/level_6/'
sys.path.insert(0, D+'opt')
from collections import defaultdict
exec(open(D+'opt/nano6.py').read().split('def main():')[0])
inp, outp = sys.argv[1], sys.argv[2]
cases = parse(inp)
blocks=[b for b in open(outp).read().replace('\r\n','\n').split('\n\n') if b.strip()]
def sim_gaps(geo, pat, prog):
    rows, cols = geo.rows, geo.cols
    board = [row[:] for row in geo.g]
    pm = [(i,j) for i in range(rows) for j in range(cols) if pat[i][j]=='M']
    pmset=set(pm); nb=set()
    for (i,j) in pm:
        for dr,dc in NB:
            c=(i+dr,j+dc)
            if c not in pmset and 0<=c[0]<rows and 0<=c[1]<cols and board[c[0]][c[1]] in 'OM': nb.add(c)
    pos=list(geo.start); act=[False]*6; ts=[]
    for t,line in enumerate(prog):
        for e, ins in enumerate(line):
            if ins=='F': pos[e]=(pos[e]+1)%geo.M
            elif ins=='B': pos[e]=(pos[e]-1)%geo.M
            elif ins=='T': act[e]=not act[e]
        cnt=defaultdict(int)
        for e in range(6):
            if act[e]:
                for c in geo.beam[(e,pos[e])]: cnt[c]+=1
        for c,k in cnt.items():
            if k==2: board[c[0]][c[1]]='M'
            elif k>=3: board[c[0]][c[1]]='O'
        if all(board[i][j]=='M' for i,j in pm) and not any(board[i][j]=='M' for i,j in nb):
            ts.append(t+1)
            for i,j in pm: board[i][j]='O'
    return ts
for ci,((R,rows,cols,need,pat), b) in enumerate(zip(cases, blocks)):
    if need<3: continue
    prog=[l.split() for l in b.strip().split('\n')]
    ts=sim_gaps(Geo(R),pat,prog)
    g=[ts[0]]+[ts[k]-ts[k-1] for k in range(1,len(ts))]
    print(ci,'R',R,'need',need,'npat',sum(r.count('M') for r in pat),'len',len(prog),'gaps',g)
