// Beam search for level 6.  ./v3 <in> <out> [W=64] [threads=8] [budget] [Wmax]
// v3: same move/board rules as bs6s.cpp. Search changes only:
//  - board masked to pattern cells (stray non-adjacent matter never matters) -> better dedupe
//  - word-sized bitsets templated on board size (1..8 x 64-bit words), fast hash, no retained capacity
//  - optional 1-ply lookahead rerank (LAK): top W*LAK children get + WLA * (max needed cells creatable next tick)
//  - env-tunable eval weights
#include <bits/stdc++.h>
using namespace std;
static double envd(const char*n,double d){const char*s=getenv(n); return s?atof(s):d;}
static int WDONE, WPOT, WACT, WNEAR, WMASK, LAK, WLA, WLC, WCROSS;
template<int NW> struct BB {
    uint64_t w[NW];
    BB(){ for(int i=0;i<NW;i++) w[i]=0; }
    inline BB operator&(const BB&o)const{BB r; for(int i=0;i<NW;i++) r.w[i]=w[i]&o.w[i]; return r;}
    inline BB operator|(const BB&o)const{BB r; for(int i=0;i<NW;i++) r.w[i]=w[i]|o.w[i]; return r;}
    inline BB operator~()const{BB r; for(int i=0;i<NW;i++) r.w[i]=~w[i]; return r;}
    inline BB& operator|=(const BB&o){for(int i=0;i<NW;i++) w[i]|=o.w[i]; return *this;}
    inline BB& operator&=(const BB&o){for(int i=0;i<NW;i++) w[i]&=o.w[i]; return *this;}
    inline bool any()const{uint64_t x=0; for(int i=0;i<NW;i++) x|=w[i]; return x!=0;}
    inline int count()const{int c=0; for(int i=0;i<NW;i++) c+=__builtin_popcountll(w[i]); return c;}
    inline void set(int i){w[i>>6]|=1ULL<<(i&63);}
    inline bool test(int i)const{return (w[i>>6]>>(i&63))&1;}
    inline bool operator==(const BB&o)const{for(int i=0;i<NW;i++) if(w[i]!=o.w[i]) return false; return true;}
};
template<int NW> struct Geo {
    int R, rows, cols, M; vector<string> g; vector<pair<int,int>> ring; int start[6];
    vector<vector<int>> id; int ncell;
    vector<vector<BB<NW>>> beam; // [e][p]
    int D[6][2] = {{0,2},{1,1},{1,-1},{0,-2},{-1,-1},{-1,1}};
    Geo(int R_):R(R_){
        rows=2*R+1; cols=4*R+1; g.assign(rows,string(cols,'-')); id.assign(rows,vector<int>(cols,-1)); ncell=0;
        for(int i=0;i<rows;i++){int off=abs(i-R); for(int j=off;j<=cols-1-off;j+=2){bool b=(i==0||i==rows-1||j==off||j==cols-1-off); g[i][j]=b?'*':'O'; if(!b) id[i][j]=ncell++;}}
        for(int t=0;t<R;t++) ring.push_back({0,R+2*t}); for(int t=0;t<R;t++) ring.push_back({t,3*R+t});
        for(int t=0;t<R;t++) ring.push_back({R+t,4*R-t}); for(int t=0;t<R;t++) ring.push_back({2*R,3*R-2*t});
        for(int t=0;t<R;t++) ring.push_back({2*R-t,R-t}); for(int t=0;t<R;t++) ring.push_back({R-t,t});
        M=ring.size(); int s[6]={5*R,0,R,2*R,3*R,4*R}; for(int e=0;e<6;e++)start[e]=s[e];
        beam.assign(6,vector<BB<NW>>(M));
        for(int e=0;e<6;e++)for(int p=0;p<M;p++){int y=ring[p].first+D[e][0],x=ring[p].second+D[e][1]; while(y>=0&&y<rows&&x>=0&&x<cols){ if(id[y][x]>=0) beam[e][p].set(id[y][x]); y+=D[e][0];x+=D[e][1];}}
    }
    int rd(int p,int q)const{int f=((q-p)%M+M)%M; return min(f,M-f);}
};
template<int NW> struct State { unsigned char pos[6]; unsigned char act; BB<NW> board; int copies; long long score; int parent; unsigned short mv; };

struct Case { int R,rows,cols,need; vector<string> pat; };

static inline unsigned long long mix64(unsigned long long x){x^=x>>30;x*=0xbf58476d1ce4e5b9ULL;x^=x>>27;x*=0x94d049bb133111ebULL;x^=x>>31;return x;}

template<int NW> struct LA {
    const Geo<NW>* G; BB<NW> need2, adj, boardpat; int best, nneed; unsigned char pos0[6], act0;
    void dfs(int e, const BB<NW>& c1, const BB<NW>& c2, const BB<NW>& c3){
        if(best>=nneed) return;
        if(e==6){ BB<NW> cr=c2&~c3; int g=(cr&need2).count(); if(g>best && !(cr&adj).any() && !(c3&boardpat).any()) best=g; return; }
        for(int o=0;o<4;o++){
            int p=pos0[e]; bool a=(act0>>e)&1;
            if(o==1) p=(p+1)%G->M; else if(o==2) p=(p+G->M-1)%G->M; else if(o==3) a=!a;
            if(a){ const BB<NW>& b=G->beam[e][p]; BB<NW> n3=c3|(c2&b), n2=c2|(c1&b), n1=c1|b; dfs(e+1,n1,n2,n3); }
            else dfs(e+1,c1,c2,c3);
        }
    }
};

template<int NW> string solve(const Case& c, int W, long long& outlines){
    typedef BB<NW> BS; typedef State<NW> ST;
    Geo<NW> G(c.R); BS pat; vector<pair<int,int>> pm;
    for(int i=0;i<c.rows;i++)for(int j=0;j<c.cols;j++) if(c.pat[i][j]=='M'){pat.set(G.id[i][j]); pm.push_back({i,j});}
    int npat=pat.count();
    BS adj; { int NBd[6][2]={{0,2},{0,-2},{1,1},{1,-1},{-1,1},{-1,-1}};
      for(auto&c:pm) for(auto&d:NBd){int y=c.first+d[0],x=c.second+d[1]; if(y>=0&&y<G.rows&&x>=0&&x<G.cols&&G.id[y][x]>=0&&!pat.test(G.id[y][x])) adj.set(G.id[y][x]);} }
    vector<vector<ST>> layers;
    ST s0; memset(&s0,0,sizeof s0); for(int e=0;e<6;e++)s0.pos[e]=G.start[e]; s0.act=0; s0.copies=0; s0.parent=-1; s0.mv=0;
    layers.push_back({s0});
    const char INS[4]={'-','F','B','T'};
    int done=-1; int depth=0;
    vector<int> near(6*G.M);
    vector<ST> nxt; nxt.reserve(4096*8);
    unordered_set<unsigned long long> seen;
    while(done<0 && depth<(100+4*npat*c.need)){
        vector<ST>& cur=layers.back(); nxt.clear();
        seen.clear(); seen.reserve(cur.size()*4096/2+16);
        for(int pi=0;pi<(int)cur.size();pi++){
            const ST& s=cur[pi]; BS needed = pat & ~s.board;
            int useful[6][80]; for(int e=0;e<6;e++)for(int p=0;p<G.M;p++) useful[e][p]=((G.beam[e][p]&needed).any()?1:0);
            for(int e=0;e<6;e++){
                for(int p=0;p<G.M;p++){int best=G.M; for(int q=0;q<G.M;q++) if(useful[e][q]) best=min(best,G.rd(p,q)); near[e*G.M+p]=best;}
            }
            for(int mv=0;mv<4096;mv++){
                ST t=s; t.parent=pi; t.mv=mv; int m=mv;
                for(int e=0;e<6;e++){int o=m&3; m>>=2; if(o==1)t.pos[e]=(t.pos[e]+1)%G.M; else if(o==2)t.pos[e]=(t.pos[e]+G.M-1)%G.M; else if(o==3)t.act^=(1<<e);}
                BS c1,c2,c3; for(int e=0;e<6;e++) if(t.act>>e&1){const BS&b=G.beam[e][t.pos[e]]; c3|=c2&b; c2|=c1&b; c1|=b;}
                BS created=c2&~c3; BS destroyed=c3;
                if((created&adj).any()) continue;            // stray adjacent to the pattern blocks collection
                if((destroyed&t.board&pat).any()) continue;  // destroying pattern matter
                BS nb=(t.board|created)&~destroyed;
                t.copies=s.copies;
                if((nb&pat)==pat){ t.copies++; nb&=~pat; }
                if(WMASK) nb&=pat;                            // stray (non-pattern, non-adjacent) matter never matters
                t.board=nb;
                unsigned long long h=t.act; for(int e=0;e<6;e++) h=h*131+t.pos[e]; h=h*1000003+t.copies;
                for(int w=0;w<NW;w++) h=h*1000000007ULL+t.board.w[w];
                h=mix64(h);
                if(!seen.insert(h).second) continue;
                int donec=(t.board&pat).count(); BS need2=pat&~t.board;
                int pot=0, dsum=0, potA=0; BS a1,a2;
                for(int e=0;e<6;e++){ const BS& b=G.beam[e][t.pos[e]]; int onl=(b&need2).count(); if(t.act>>e&1){potA+=onl; if(WCROSS){a2|=a1&b; a1|=b;}} else pot+=onl; dsum+=near[e*G.M+t.pos[e]]; }
                int cross = WCROSS? (a1&~a2&need2).count() : 0;
                t.score = (long long)t.copies*100000 + (long long)donec*WDONE + (long long)(pot + potA*WACT)*WPOT - (long long)dsum*WNEAR + (long long)cross*WCROSS;
                nxt.push_back(t);
                if(t.copies==c.need){ done=(int)nxt.size()-1; }
            }
            if(done>=0) break;
        }
        if(nxt.empty()) return "";
        if(done<0 && (int)nxt.size()>W){
            auto cmp=[](const ST&a,const ST&b){return a.score>b.score;};
            if(LAK>0){
                size_t K=min(nxt.size(),(size_t)W*LAK/2);
                if(nxt.size()>K){ nth_element(nxt.begin(), nxt.begin()+K, nxt.end(), cmp); nxt.resize(K); }
                LA<NW> la; la.G=&G; la.adj=adj;
                for(auto& st: nxt){
                    la.need2=pat&~st.board; la.nneed=la.need2.count(); la.best=0; la.boardpat=st.board&pat;
                    for(int e=0;e<6;e++) la.pos0[e]=st.pos[e]; la.act0=st.act;
                    BS z; la.dfs(0,z,z,z);
                    st.score += (long long)la.best*WLA + (la.best==la.nneed && la.nneed>0 ? WLC : 0);
                }
            }
            if((int)nxt.size()>W){ nth_element(nxt.begin(), nxt.begin()+W, nxt.end(), cmp); nxt.resize(W); }
        }
        layers.push_back(vector<ST>(nxt.begin(), nxt.end())); depth++;
    }
    if(done<0) return "";
    vector<int> mvs; int li=layers.size()-1, si=done;
    while(li>0){ mvs.push_back(layers[li][si].mv); si=layers[li][si].parent; li--; }
    reverse(mvs.begin(),mvs.end()); string out;
    for(int mv:mvs){ int m=mv; for(int e=0;e<6;e++){ out+=INS[m&3]; m>>=2; out+= (e==5?'\n':' ');} }
    outlines=mvs.size(); return out;
}
static string solveAny(const Case& c, int W, long long& l){
    int r=c.R-1; int ncell=3*r*(r+1)+1; int nw=(ncell+63)/64;
    switch(nw){ case 1: return solve<1>(c,W,l); case 2: return solve<2>(c,W,l); case 3: return solve<3>(c,W,l); case 4: return solve<4>(c,W,l);
        case 5: return solve<5>(c,W,l); case 6: return solve<6>(c,W,l); case 7: return solve<7>(c,W,l); default: return solve<8>(c,W,l); }
}

int main(int argc,char**argv){
    if(argc<3){fprintf(stderr,"usage\n");return 1;}
    WDONE=(int)envd("WDONE",300); WPOT=(int)envd("WPOT",4); WACT=(int)envd("WACT",3); WNEAR=(int)envd("WNEAR",3);
    WMASK=(int)envd("WMASK",1); LAK=(int)envd("LAK",0); WLA=(int)envd("WLA",300); WLC=(int)envd("WLC",3000); WCROSS=(int)envd("WCROSS",0);
    int W0=argc>3?atoi(argv[3]):64; int TH=argc>4?atoi(argv[4]):8; double budget=argc>5?atof(argv[5]):20.0; int Wmax=argc>6?atoi(argv[6]):4096;
    ifstream in(argv[1]); int n; in>>n; vector<Case> cs(n);
    for(auto&c:cs){ in>>c.R>>c.rows>>c.cols>>c.need; c.pat.resize(c.rows); for(auto&r:c.pat) in>>r; }
    vector<string> res(n); vector<long long> lines(n,0); atomic<int> idx(0);
    vector<thread> th; for(int t=0;t<TH;t++) th.emplace_back([&]{ for(;;){ int i=idx++; if(i>=n)break;
        auto t0=chrono::steady_clock::now(); double spent=0, last=0; long long bestl=LLONG_MAX; string bests;
        for(int W=W0; W<=Wmax; W*=2){
            auto t1=chrono::steady_clock::now(); long long l=0; string r=solveAny(cs[i],W,l);
            last=chrono::duration<double>(chrono::steady_clock::now()-t1).count(); spent=chrono::duration<double>(chrono::steady_clock::now()-t0).count();
            if(!r.empty() && l<bestl){bestl=l; bests=r;}
            if(spent + last*2.2 > budget) break;
        }
        res[i]=bests; lines[i]=(bestl==LLONG_MAX?0:bestl); } });
    for(auto&t:th)t.join();
    long long tot=0; int fail=0; ofstream out(argv[2]);
    for(int i=0;i<n;i++){ if(res[i].empty()){fail++; out<<"FAIL\n";} else {out<<res[i];} if(i+1<n) out<<"\n"; tot+=lines[i]; }
    fprintf(stderr,"%s: score %lld fails %d (W0=%d) D%d P%d A%d N%d M%d LAK%d LA%d LC%d C%d\n",argv[1],tot,fail,W0,WDONE,WPOT,WACT,WNEAR,WMASK,LAK,WLA,WLC,WCROSS);
}
