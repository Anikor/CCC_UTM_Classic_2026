#!/bin/sh
# usage: run.sh <exe> <in> <out> <W> "ENV=val ENV2=val"
cd "C:/Users/Student 06/CCC_auto/.claude/worktrees/agent-a706ee51a5e43aa3d/games/ccc42/level_6/opt"
exe=$1; in=$2; out=$3; W=$4; envs=$5
s=$(date +%s)
env $envs ./$exe $in $out $W 6 0.1 $W 2>&1 | tr '\n' ' '
e=$(date +%s)
echo " [$envs] time=$((e-s))s"
