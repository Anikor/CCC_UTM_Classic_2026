// Validator mirroring nano6.py simulate():  ./val6 <in> <out>   -> prints score and bad cases
#include <bits/stdc++.h>
using namespace std;
int main(int argc,char**argv){
    ifstream in(argv[1]); int n; in>>n;
    struct C{int R,rows,cols,need; vector<string> pat;}; vector<C> cs(n);
    for(auto&c:cs){ in>>c.R>>c.rows>>c.cols>>c.need; c.pat.resize(c.rows); for(auto&r:c.pat) in>>r; }
    ifstream fo(argv[2]); string all((istreambuf_iterator<char>(fo)),istreambuf_iterator<char>());
    all.erase(remove(all.begin(),all.end(),'\r'),all.end());
    vector<vector<string>> blocks; { vector<string> cur; stringstream ss(all); string line;
        while(getline(ss,line)){ if(line.find_first_not_of(" \t")==string::npos){ if(!cur.empty()){blocks.push_back(cur); cur.clear();} } else cur.push_back(line); }
        if(!cur.empty()) blocks.push_back(cur); }
    if((int)blocks.size()!=n){ printf("block count %zu != %d\n",blocks.size(),n); return 1; }
    long long tot=0; int bad=0;
    int D[6][2]={{0,2},{1,1},{1,-1},{0,-2},{-1,-1},{-1,1}};
    int NB[6][2]={{0,2},{0,-2},{1,1},{1,-1},{-1,1},{-1,-1}};
    for(int ci=0;ci<n;ci++){
        auto&c=cs[ci]; int R=c.R, rows=2*R+1, cols=4*R+1;
        vector<string> g(rows,string(cols,'-'));
        for(int i=0;i<rows;i++){int off=abs(i-R); for(int j=off;j<=cols-1-off;j+=2){bool b=(i==0||i==rows-1||j==off||j==cols-1-off); g[i][j]=b?'*':'O';}}
        vector<pair<int,int>> ring;
        for(int t=0;t<R;t++) ring.push_back({0,R+2*t}); for(int t=0;t<R;t++) ring.push_back({t,3*R+t});
        for(int t=0;t<R;t++) ring.push_back({R+t,4*R-t}); for(int t=0;t<R;t++) ring.push_back({2*R,3*R-2*t});
        for(int t=0;t<R;t++) ring.push_back({2*R-t,R-t}); for(int t=0;t<R;t++) ring.push_back({R-t,t});
        int M=ring.size(); int pos[6]={5*R,0,R,2*R,3*R,4*R}; bool act[6]={0};
        vector<pair<int,int>> pm; set<pair<int,int>> pms;
        for(int i=0;i<rows;i++)for(int j=0;j<cols;j++) if(c.pat[i][j]=='M'){pm.push_back({i,j}); pms.insert({i,j});}
        set<pair<int,int>> nb;
        for(auto&p:pm) for(auto&d:NB){int y=p.first+d[0],x=p.second+d[1]; if(y>=0&&y<rows&&x>=0&&x<cols&&!pms.count({y,x})&&(g[y][x]=='O'||g[y][x]=='M')) nb.insert({y,x});}
        vector<string> board=g; int count=0; bool okfmt=true;
        for(auto&line:blocks[ci]){
            stringstream ls(line); vector<string> tk; string t; while(ls>>t) tk.push_back(t);
            if(tk.size()!=6){okfmt=false; break;}
            for(int e=0;e<6;e++){ if(tk[e]=="F") pos[e]=(pos[e]+1)%M; else if(tk[e]=="B") pos[e]=(pos[e]-1+M)%M; else if(tk[e]=="T") act[e]=!act[e]; else if(tk[e]!="-") okfmt=false; }
            map<pair<int,int>,int> cnt;
            for(int e=0;e<6;e++) if(act[e]){ int y=ring[pos[e]].first+D[e][0], x=ring[pos[e]].second+D[e][1];
                while(y>=0&&y<rows&&x>=0&&x<cols){ if(g[y][x]=='O') cnt[{y,x}]++; y+=D[e][0]; x+=D[e][1]; } }
            for(auto&kv:cnt){ if(kv.second==2) board[kv.first.first][kv.first.second]='M'; else if(kv.second>=3) board[kv.first.first][kv.first.second]='O'; }
            bool all=true; for(auto&p:pm) if(board[p.first][p.second]!='M'){all=false;break;}
            bool anyn=false; for(auto&p:nb) if(board[p.first][p.second]=='M'){anyn=true;break;}
            if(all&&!anyn){ count++; for(auto&p:pm) board[p.first][p.second]='O'; }
        }
        if(!okfmt || count!=c.need){ bad++; printf("case %d bad: got %d need %d fmt %d\n",ci,count,c.need,(int)okfmt); }
        tot+=blocks[ci].size();
    }
    printf("%s: score %lld bad %d\n",argv[2],tot,bad);
}
