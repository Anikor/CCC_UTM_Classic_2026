#!/bin/sh
# usage: contrib.sh <level-letter m|l|e>  : merged per-case-min of all candidates in the main opt dir, with/without x_<p>H256.out
D="C:/Users/Student 06/CCC_auto/games/ccc42/level_6/opt"
case $1 in m) f=2-medium;; l) f=3-large;; e) f=4-enormous;; esac
me="$D/x_$1H256.out"
awk -v me="$me" 'BEGIN{RS=""}
{ if($0 ~ /FAIL/) next; n=split($0,a,"\n"); c=0; for(i=1;i<=n;i++) if(a[i]!="") c++; k=FNR;
  if(FILENAME==me){ mine[k]=c } else { if(!(k in best) || c<best[k]) best[k]=c } }
END{ for(k in best){ s+=best[k]; m=best[k]; if((k in mine) && mine[k]<m){m=mine[k]; w++} s2+=m }
     print me, "others", s, "with_mine", s2, "cases_improved", w+0, "ncases", length(best) }' "$D"/x_$1*.out "$D/final_$f.out" "$D/w_$f.out"
