#!/bin/sh
# usage: mergecount.sh <best.out> <cand.out> ... : prints per-case-min total (assumes all candidates valid & same case count)
awk 'BEGIN{RS=""} { n=split($0,a,"\n"); c=0; for(i=1;i<=n;i++) if(a[i]!="") c++; k=FNR; if(!(k in best) || c<best[k]) best[k]=c; if(FILENAME==ARGV[1]) base+=c } END{ for(k in best) s+=best[k]; print "base", base, "merged", s }' "$@"
