#!/bin/sh
# usage: final.sh <m|l|e> <W> [extra env]
cd "C:/Users/Student 06/CCC_auto/.claude/worktrees/agent-a706ee51a5e43aa3d/games/ccc42/level_6/opt"
case $1 in m) f=2-medium;; l) f=3-large;; e) f=4-enormous;; esac
OUT="C:/Users/Student 06/CCC_auto/games/ccc42/level_6/opt/x_$1H$2.out"
s=$(date +%s)
env LAK=8 WLA=600 $3 ./v3.exe ../input/in_level-6_$f.txt "$OUT" $2 6 0.1 $2 2>&1 | tr '\n' ' '
e=$(date +%s)
echo " -> $OUT time=$((e-s))s at $(date -u +%H:%M:%S)"
