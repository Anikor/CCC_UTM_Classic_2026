// Beam search for level 6.  ./bs6 <in> <out> [W=64] [threads=8]
// v1: board masked to pattern cells (stray matter is irrelevant -> better dedupe), fast hash,
//     no retained vector capacity, env-tunable eval weights + optional tie-break jitter.
#include <bits/stdc++.h>
using namespace std;
typedef bitset<512> BS;
static double envd(const char*n,double d){const char*s=getenv(n); return s?atof(s):d;}
static int WDONE, WPOT, WACT, WNEAR, WJIT, WCROSS, WMASK, WLINE, LAK, WLA, WLC, PCAP;
struct Geo {
    int R, rows, cols, M; vector<string> g; vector<pair<int,int>> ring; int start[6];
    vector<vector<int>> id; int ncell;
    vector<vector<BS>> beam; // [e][p]
    int D[6][2] = {{0,2},{1,1},{1,-1},{0,-2},{-1,-1},{-1,1}};
    Geo(int R_):R(R_){
        rows=2*R+1; cols=4*R+1; g.assign(rows,string(cols,'-')); id.assign(rows,vector<int>(cols,-1)); ncell=0;
        for(int i=0;i<rows;i++){int off=abs(i-R); for(int j=off;j<=cols-1-off;j+=2){bool b=(i==0||i==rows-1||j==off||j==cols-1-off); g[i][j]=b?'*':'O'; if(!b) id[i][j]=ncell++;}}
        for(int t=0;t<R;t++) ring.push_back({0,R+2*t}); for(int t=0;t<R;t++) ring.push_back({t,3*R+t});
        for(int t=0;t<R;t++) ring.push_back({R+t,4*R-t}); for(int t=0;t<R;t++) ring.push_back({2*R,3*R-2*t});
        for(int t=0;t<R;t++) ring.push_back({2*R-t,R-t}); for(int t=0;t<R;t++) ring.push_back({R-t,t});
        M=ring.size(); int s[6]={5*R,0,R,2*R,3*R,4*R}; for(int e=0;e<6;e++)start[e]=s[e];
        beam.assign(6,vector<BS>(M));
        for(int e=0;e<6;e++)for(int p=0;p<M;p++){int y=ring[p].first+D[e][0],x=ring[p].second+D[e][1]; while(y>=0&&y<rows&&x>=0&&x<cols){ if(id[y][x]>=0) beam[e][p].set(id[y][x]); y+=D[e][0];x+=D[e][1];}}
    }
    int rd(int p,int q)const{int f=((q-p)%M+M)%M; return min(f,M-f);}
};
struct State { unsigned char pos[6]; unsigned char act; BS board; int copies; long long score; int parent; unsigned short mv; };
static inline int popc(const BS&b){return (int)b.count();}

struct Case { int R,rows,cols,need; vector<string> pat; };

static inline unsigned long long mix64(unsigned long long x){x^=x>>30;x*=0xbf58476d1ce4e5b9ULL;x^=x>>27;x*=0x94d049bb133111ebULL;x^=x>>31;return x;}

string solve(const Case& c, int W, long long& outlines){
    Geo G(c.R); BS pat; vector<pair<int,int>> pm;
    for(int i=0;i<c.rows;i++)for(int j=0;j<c.cols;j++) if(c.pat[i][j]=='M'){pat.set(G.id[i][j]); pm.push_back({i,j});}
    int npat=popc(pat);
    BS adj; { int NBd[6][2]={{0,2},{0,-2},{1,1},{1,-1},{-1,1},{-1,-1}};
      for(auto&c:pm) for(auto&d:NBd){int y=c.first+d[0],x=c.second+d[1]; if(y>=0&&y<G.rows&&x>=0&&x<G.cols&&G.id[y][x]>=0&&!pat[G.id[y][x]]) adj.set(G.id[y][x]);} }
    vector<vector<State>> layers;
    State s0; memset(&s0,0,sizeof s0); for(int e=0;e<6;e++)s0.pos[e]=G.start[e]; s0.act=0; s0.copies=0; s0.parent=-1; s0.mv=0;
    layers.push_back({s0});
    const char INS[4]={'-','F','B','T'};
    int done=-1; int depth=0;
    vector<int> near(6*G.M);
    vector<State> nxt; nxt.reserve(4096*8);
    unordered_set<unsigned long long> seen;
    while(done<0 && depth<(100+4*npat*c.need)){
        vector<State>& cur=layers.back(); nxt.clear();
        seen.clear(); seen.reserve(cur.size()*4096/2+16);
        for(int pi=0;pi<(int)cur.size();pi++){
            const State& s=cur[pi]; BS needed = pat & ~s.board;
            int useful[6][80]; for(int e=0;e<6;e++)for(int p=0;p<G.M;p++) useful[e][p]=((G.beam[e][p]&needed).any()?1:0);
            for(int e=0;e<6;e++){
                for(int p=0;p<G.M;p++){int best=G.M; for(int q=0;q<G.M;q++) if(useful[e][q]) best=min(best,G.rd(p,q)); near[e*G.M+p]=best;}
            }
            for(int mv=0;mv<4096;mv++){
                State t=s; t.parent=pi; t.mv=mv; int m=mv;
                for(int e=0;e<6;e++){int o=m&3; m>>=2; if(o==1)t.pos[e]=(t.pos[e]+1)%G.M; else if(o==2)t.pos[e]=(t.pos[e]+G.M-1)%G.M; else if(o==3)t.act^=(1<<e);}
                BS c1,c2,c3; for(int e=0;e<6;e++) if(t.act>>e&1){const BS&b=G.beam[e][t.pos[e]]; c3|=c2&b; c2|=c1&b; c1|=b;}
                BS created=c2&~c3; BS destroyed=c3;
                if((created&adj).any()) continue;            // stray adjacent to the pattern blocks collection
                if((destroyed&t.board&pat).any()) continue;  // destroying pattern matter
                BS nb=(t.board|created)&~destroyed;
                t.copies=s.copies;
                if((nb&pat)==pat){ t.copies++; nb&=~pat; }
                if(WMASK) nb&=pat;                            // stray (non-pattern, non-adjacent) matter never matters
                t.board=nb;
                // dedupe
                unsigned long long h=t.act; for(int e=0;e<6;e++) h=h*131+t.pos[e]; h=h*1000003+t.copies;
                { unsigned long long wv[8]; memcpy(wv,&t.board,64); for(int w=0;w<8;w++) h=h*1000000007ULL+wv[w]; }
                h=mix64(h);
                if(!seen.insert(h).second) continue;
                // eval
                int donec=popc(t.board&pat); BS need2=pat&~t.board;
                int pot=0, dsum=0, potA=0;
                BS a1,a2;
                for(int e=0;e<6;e++){ const BS& b=G.beam[e][t.pos[e]]; int onl=popc(b&need2); if(t.act>>e&1){potA+=onl; a2|=a1&b; a1|=b;} else pot+=onl; dsum+=near[e*G.M+t.pos[e]]; }
                int cross = WCROSS? popc(a1&~a2&need2) : 0;   // needed cells on exactly one active line
                long long sc = (long long)t.copies*100000 + (long long)donec*WDONE + (long long)(pot + potA*WACT)*WPOT - (long long)dsum*WNEAR + (long long)cross*WCROSS;
                if(WJIT) sc = sc*16 + (long long)(h>>60);
                t.score = sc;
                nxt.push_back(t);
                if(t.copies==c.need){ done=(int)nxt.size()-1; }
            }
            if(done>=0) break;
        }
        if(nxt.empty()) return "";
        if(done<0 && (int)nxt.size()>W){
            auto cmp=[](const State&a,const State&b){return a.score>b.score;};
            if(LAK>0){
                size_t K=min(nxt.size(),(size_t)W*LAK);
                if(nxt.size()>K){ nth_element(nxt.begin(), nxt.begin()+K, nxt.end(), cmp); nxt.resize(K); }
                for(auto& st: nxt){ // 1-ply lookahead: best number of needed cells creatable next tick
                    BS need2=pat&~st.board; int nneed=popc(need2); int best=0;
                    for(int mv=0;mv<4096;mv++){
                        unsigned char pos[6]; unsigned char act=st.act; int m=mv;
                        for(int e=0;e<6;e++){int o=m&3; m>>=2; pos[e]=st.pos[e]; if(o==1)pos[e]=(pos[e]+1)%G.M; else if(o==2)pos[e]=(pos[e]+G.M-1)%G.M; else if(o==3)act^=(1<<e);}
                        if(__builtin_popcount(act)<2) continue;
                        BS c1,c2,c3; for(int e=0;e<6;e++) if(act>>e&1){const BS&b=G.beam[e][pos[e]]; c3|=c2&b; c2|=c1&b; c1|=b;}
                        BS cr=c2&~c3;
                        int g=popc(cr&need2); if(g<=best) continue;
                        if((cr&adj).any()) continue;
                        if((c3&st.board&pat).any()) continue;
                        best=g; if(best==nneed) break;
                    }
                    st.score += (long long)best*WLA + (best==nneed && nneed>0 ? WLC : 0);
                }
            }
            if(PCAP>0){ // per-parent cap for diversity
                size_t K=min(nxt.size(),(size_t)W*4);
                if(nxt.size()>K){ nth_element(nxt.begin(), nxt.begin()+K, nxt.end(), cmp); nxt.resize(K); }
                sort(nxt.begin(), nxt.end(), cmp);
                int cap=max(1,W*PCAP/100); vector<int> cnt(cur.size(),0); vector<State> sel, rest; sel.reserve(W);
                for(auto&st:nxt){ if((int)sel.size()>=W) break; if(cnt[st.parent]<cap){cnt[st.parent]++; sel.push_back(st);} else rest.push_back(st); }
                for(auto&st:rest){ if((int)sel.size()>=W) break; sel.push_back(st); }
                nxt.swap(sel);
            } else { nth_element(nxt.begin(), nxt.begin()+W, nxt.end(), cmp); nxt.resize(W); } }
        layers.push_back(vector<State>(nxt.begin(), nxt.end())); depth++;
    }
    if(done<0) return "";
    vector<int> mvs; int li=layers.size()-1, si=done;
    while(li>0){ mvs.push_back(layers[li][si].mv); si=layers[li][si].parent; li--; }
    reverse(mvs.begin(),mvs.end()); string out;
    for(int mv:mvs){ int m=mv; for(int e=0;e<6;e++){ out+=INS[m&3]; m>>=2; out+= (e==5?'\n':' ');} }
    outlines=mvs.size(); return out;
}

int main(int argc,char**argv){
    if(argc<3){fprintf(stderr,"usage\n");return 1;}
    WDONE=(int)envd("WDONE",300); WPOT=(int)envd("WPOT",4); WACT=(int)envd("WACT",3); WNEAR=(int)envd("WNEAR",3);
    WJIT=(int)envd("WJIT",0); WCROSS=(int)envd("WCROSS",0); WMASK=(int)envd("WMASK",1); WLINE=(int)envd("WLINE",0); LAK=(int)envd("LAK",0); WLA=(int)envd("WLA",300); WLC=(int)envd("WLC",3000); PCAP=(int)envd("PCAP",0);
    int W0=argc>3?atoi(argv[3]):64; int TH=argc>4?atoi(argv[4]):8; double budget=argc>5?atof(argv[5]):20.0; int Wmax=argc>6?atoi(argv[6]):4096;
    ifstream in(argv[1]); int n; in>>n; vector<Case> cs(n);
    for(auto&c:cs){ in>>c.R>>c.rows>>c.cols>>c.need; c.pat.resize(c.rows); for(auto&r:c.pat) in>>r; }
    vector<string> res(n); vector<long long> lines(n,0); atomic<int> idx(0);
    vector<thread> th; for(int t=0;t<TH;t++) th.emplace_back([&]{ for(;;){ int i=idx++; if(i>=n)break;
        auto t0=chrono::steady_clock::now(); double spent=0, last=0; long long bestl=LLONG_MAX; string bests;
        for(int W=W0; W<=Wmax; W*=2){
            auto t1=chrono::steady_clock::now(); long long l=0; string r=solve(cs[i],W,l);
            last=chrono::duration<double>(chrono::steady_clock::now()-t1).count(); spent=chrono::duration<double>(chrono::steady_clock::now()-t0).count();
            if(!r.empty() && l<bestl){bestl=l; bests=r;}
            if(spent + last*2.2 > budget) break;
        }
        res[i]=bests; lines[i]=(bestl==LLONG_MAX?0:bestl); } });
    for(auto&t:th)t.join();
    long long tot=0; int fail=0; ofstream out(argv[2]);
    for(int i=0;i<n;i++){ if(res[i].empty()){fail++; out<<"FAIL\n";} else {out<<res[i];} if(i+1<n) out<<"\n"; tot+=lines[i]; }
    fprintf(stderr,"%s: score %lld fails %d (W0=%d) D%d P%d A%d N%d J%d C%d M%d\n",argv[1],tot,fail,W0,WDONE,WPOT,WACT,WNEAR,WJIT,WCROSS,WMASK);
}
