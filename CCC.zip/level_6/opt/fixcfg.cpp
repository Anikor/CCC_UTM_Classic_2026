// Fixed-configuration solver: choose up to 2 lines per family (one per emitter), park emitters there,
// then produce each copy by toggling only (BFS over created-cell subsets). ./fixcfg <in> <out> [threads]
#include <bits/stdc++.h>
using namespace std;
typedef bitset<512> BS;
struct Geo { int R,rows,cols,M; vector<string> g; vector<pair<int,int>> ring; int start[6]; vector<vector<int>> id; int ncell; vector<vector<BS>> beam; int D[6][2]={{0,2},{1,1},{1,-1},{0,-2},{-1,-1},{-1,1}};
  Geo(int R_):R(R_){ rows=2*R+1; cols=4*R+1; g.assign(rows,string(cols,'-')); id.assign(rows,vector<int>(cols,-1)); ncell=0;
    for(int i=0;i<rows;i++){int off=abs(i-R); for(int j=off;j<=cols-1-off;j+=2){bool b=(i==0||i==rows-1||j==off||j==cols-1-off); g[i][j]=b?'*':'O'; if(!b) id[i][j]=ncell++;}}
    for(int t=0;t<R;t++) ring.push_back({0,R+2*t}); for(int t=0;t<R;t++) ring.push_back({t,3*R+t}); for(int t=0;t<R;t++) ring.push_back({R+t,4*R-t}); for(int t=0;t<R;t++) ring.push_back({2*R,3*R-2*t}); for(int t=0;t<R;t++) ring.push_back({2*R-t,R-t}); for(int t=0;t<R;t++) ring.push_back({R-t,t});
    M=ring.size(); int s[6]={5*R,0,R,2*R,3*R,4*R}; for(int e=0;e<6;e++)start[e]=s[e]; beam.assign(6,vector<BS>(M));
    for(int e=0;e<6;e++)for(int p=0;p<M;p++){int y=ring[p].first+D[e][0],x=ring[p].second+D[e][1]; while(y>=0&&y<rows&&x>=0&&x<cols){ if(id[y][x]>=0) beam[e][p].set(id[y][x]); y+=D[e][0];x+=D[e][1];}} }
  int rd(int p,int q)const{int f=((q-p)%M+M)%M; return min(f,M-f);} };
struct Case{int R,rows,cols,need; vector<string> pat;};

string solve(const Case&c, long long& lines){
    Geo G(c.R); BS pat, adj; vector<pair<int,int>> pm;
    for(int i=0;i<c.rows;i++)for(int j=0;j<c.cols;j++) if(c.pat[i][j]=='M'){pat.set(G.id[i][j]); pm.push_back({i,j});}
    int NB[6][2]={{0,2},{0,-2},{1,1},{1,-1},{-1,1},{-1,-1}};
    for(auto&cc:pm)for(auto&d:NB){int y=cc.first+d[0],x=cc.second+d[1]; if(y>=0&&y<G.rows&&x>=0&&x<G.cols&&G.id[y][x]>=0&&!pat[G.id[y][x]]) adj.set(G.id[y][x]);}
    // candidate positions per emitter: those whose beam hits >=1 pattern cell; plus -1 = unused
    vector<vector<int>> cand(6);
    for(int e=0;e<6;e++){ cand[e].push_back(-1); for(int p=0;p<G.M;p++) if((G.beam[e][p]&pat).any()) cand[e].push_back(p); }
    long long best=LLONG_MAX; string bestprog;
    int pos[6];
    // enumerate (cap total combos)
    long long combos=1; for(int e=0;e<6;e++) combos*=cand[e].size(); if(combos>3000000) return "";
    vector<int> idx(6,0);
    for(long long it=0;it<combos;it++){
        long long r=it; for(int e=0;e<6;e++){ pos[e]=cand[e][r%cand[e].size()]; r/=cand[e].size(); }
        // lines
        BS L[6]; int used=0; for(int e=0;e<6;e++){ if(pos[e]>=0){L[e]=G.beam[e][pos[e]]; used|=1<<e;} }
        if(used==0) continue;
        // crossing coverage: each pattern cell must be hit by >=2 of the chosen lines
        BS c1,c2; for(int e=0;e<6;e++) if(used>>e&1){ c2|=c1&L[e]; c1|=L[e]; }
        if((pat&~c2).any()) continue;
        // travel cost
        int travel=0; for(int e=0;e<6;e++) if(pos[e]>=0) travel=max(travel,G.rd(G.start[e],pos[e]));
        if(travel + (long long)c.need >= best) continue;
        // per subset A of used: created / destroyed sets
        vector<BS> cr(64), ds(64); vector<bool> ok(64,false);
        for(int A=1;A<64;A++){ if(A&~used) continue; BS a1,a2,a3; for(int e=0;e<6;e++) if(A>>e&1){ a3|=a2&L[e]; a2|=a1&L[e]; a1|=L[e]; }
            cr[A]=a2&~a3; ds[A]=a3; if((cr[A]&adj).any()) continue; ok[A]=true; }
        // BFS over created pattern subsets (as bitset of pat cells) — state = board restricted to pat ∪ strays? ignore strays (non-adjacent only)
        // state key: pattern cells created (<=12 cells typically); map to index
        vector<int> pc; for(int i=0;i<512;i++) if(pat[i]) pc.push_back(i);
        int np=pc.size(); if(np>16) continue;
        vector<int> dist(1<<np,-1), par(1<<np,-1), pmv(1<<np,0); dist[0]=0; deque<int> q; q.push_back(0); int goal=(1<<np)-1; int found=-1;
        while(!q.empty()){ int s=q.front(); q.pop_front(); if(dist[s]+1>=(int)min<long long>(64, (best-travel)/c.need+1)) break;
            for(int A=1;A<64;A++){ if(!ok[A]) continue; int ns=s; bool badd=false;
                for(int k=0;k<np;k++){ int cell=pc[k]; if(ds[A][cell] && (s>>k&1)){badd=true;break;} if(cr[A][cell]) ns|=1<<k; }
                if(badd) continue; if(dist[ns]<0){dist[ns]=dist[s]+1; par[ns]=s; pmv[ns]=A; if(ns==goal){found=ns;break;} q.push_back(ns);} }
            if(found>=0) break; }
        if(found<0) continue;
        int k=dist[goal]; long long total=travel+(long long)k*c.need;
        if(total>=best) continue;
        // build program: travel phase (parallel moves, inactive), then need × (sequence of subsets with toggles)
        vector<int> seq; for(int s=goal;s!=0;s=par[s]) seq.push_back(pmv[s]); reverse(seq.begin(),seq.end());
        string prog; int cur[6]; for(int e=0;e<6;e++)cur[e]=G.start[e];
        for(int t=0;t<travel;t++){ string ln; for(int e=0;e<6;e++){ char ch='-'; if(pos[e]>=0&&cur[e]!=pos[e]){ int f=((pos[e]-cur[e])%G.M+G.M)%G.M; if(f<=G.M-f){ch='F';cur[e]=(cur[e]+1)%G.M;} else {ch='B';cur[e]=(cur[e]+G.M-1)%G.M;} } ln+=ch; ln+=(e==5?'\n':' ');} prog+=ln; }
        int act=0;
        for(int cp=0;cp<c.need;cp++) for(int A:seq){ string ln; for(int e=0;e<6;e++){ bool want=A>>e&1; char ch=(want!=(bool)(act>>e&1))?'T':'-'; ln+=ch; ln+=(e==5?'\n':' ');} act=A; prog+=ln; }
        best=total; bestprog=prog;
    }
    lines=best; return bestprog;
}
int main(int argc,char**argv){ int TH=argc>3?atoi(argv[3]):4; ifstream in(argv[1]); int n; in>>n; vector<Case> cs(n);
    for(auto&c:cs){ in>>c.R>>c.rows>>c.cols>>c.need; c.pat.resize(c.rows); for(auto&r:c.pat) in>>r; }
    vector<string> res(n); vector<long long> ln(n,0); atomic<int> idx(0); vector<thread> th;
    for(int t=0;t<TH;t++) th.emplace_back([&]{ for(;;){int i=idx++; if(i>=n)break; res[i]=solve(cs[i],ln[i]);} }); for(auto&t:th)t.join();
    ofstream out(argv[2]); long long tot=0; int fail=0; for(int i=0;i<n;i++){ if(res[i].empty()){fail++; out<<"FAIL\n";} else {out<<res[i]; tot+=ln[i];} if(i+1<n) out<<"\n"; }
    fprintf(stderr,"%s: fixcfg solved %d/%d, lines of solved %lld\n",argv[1],n-fail,n,tot); }
