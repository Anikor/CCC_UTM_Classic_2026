#!/usr/bin/env python3
"""Adjacent-relaxed GPU tail search for multi-copy medium cases: cut the best program right after
collections 1..3 (state is clean there: empty pattern board, no adjacent matter), beam-search the
remaining copies with gpu6a's kernel, keep strictly shorter completions.
  python tailA.py <W> <stopHHMM>   -> x_mTA.out (current best kept where not improved)"""
import sys, time, inspect
import numpy as np
import cupy as cp
import gpu6a as ga
import gpu6snap as g

src = inspect.getsource(ga.solve)
src = src.replace('def solve(case, W, KF=4.0, maxlayers=None):', 'def solve_from(case, W, KF, maxlayers, init):')
a = 'Ppos = cp.asarray(np.array(start, np.uint8))'
b = 'Pact = cp.zeros(1, cp.int32); Pcop = cp.zeros(1, cp.int32); Pbrd = cp.zeros(NWP, cp.uint64)'
assert a in src and b in src
src = src.replace(a, 'Ppos = cp.asarray(np.array(init[0], np.uint8))')
src = src.replace(b, 'Pact = cp.asarray(np.array([init[1]], np.int32)); Pcop = cp.asarray(np.array([init[2]], np.int32)); '
                     'Pbrd = cp.zeros(NWP, cp.uint64)')
exec(src, ga.__dict__)
solve_from = ga.solve_from

def collections(case, lines):
    """(tick, pos, act, copies) right after each collection, nano6 rules."""
    R, rows, cols, need, pat = case
    _, _, idg, ring, M, start, beam = g.geo(R)
    plist = [(i, j) for i in range(rows) for j in range(cols) if pat[i][j] == 'M']; pset = set(plist)
    adj = set()
    for (i, j) in plist:
        for dy, dx in g.NBd:
            y, x = i + dy, j + dx
            if 0 <= y < rows and 0 <= x < cols and idg[y][x] >= 0 and (y, x) not in pset: adj.add((y, x))
    pos = list(start); act = 0; cop = 0; board = set(); out = []
    for t, ln in enumerate(lines, 1):
        ins = ln.split()
        for e in range(6):
            if ins[e] == 'F': pos[e] = (pos[e] + 1) % M
            elif ins[e] == 'B': pos[e] = (pos[e] - 1) % M
            elif ins[e] == 'T': act ^= (1 << e)
        cnt = {}
        for e in range(6):
            if (act >> e) & 1:
                for c in beam[e][pos[e]]: cnt[c] = cnt.get(c, 0) + 1
        for c, k in cnt.items():
            if k == 2: board.add(c)
            elif k >= 3: board.discard(c)
        if pset <= board and not (adj & board):
            cop += 1; board -= pset
            out.append((t, list(pos), act, cop, not (board & adj)))
    return out

W, stop = int(sys.argv[1]), sys.argv[2]
cs = g.parse('../input/in_level-6_2-medium.txt')
bl = [x for x in open('w_2-medium.out').read().replace('\r\n', '\n').split('\n\n') if x.strip()]
out = [x.strip().split('\n') for x in bl]
order = sorted([i for i in range(len(cs)) if cs[i][3] >= 6], key=lambda i: -cs[i][3] * len(out[i]))
saved = 0; lastw = 0; t0 = time.time()
for i in order:
    if time.strftime('%H%M', time.gmtime()) >= stop: break
    case = cs[i]; cur = out[i]; tc = time.time()
    for (t, pos, act, cop, clean) in collections(case, cur)[:3]:
        if not clean or cop >= case[3] or t >= len(cur) - 1: continue
        r = solve_from(case, W, 4.0, len(cur) - t - 1, (pos, act, cop))
        if r is not None and t + len(r) < len(cur):
            saved += len(cur) - t - len(r); cur = cur[:t] + r; out[i] = cur; break
    print('m case %d need %d: %d -> %d  %.1fs  saved %d  elapsed %.0fs' % (i, case[3], len(bl[i].strip().split('\n')), len(cur),
          time.time() - tc, saved, time.time() - t0), file=sys.stderr, flush=True)
    if time.time() - lastw > 20: g.writeout('x_mTA.out', out); lastw = time.time()
g.writeout('x_mTA.out', out)
print('TAILA DONE saved %d' % saved, file=sys.stderr, flush=True)
