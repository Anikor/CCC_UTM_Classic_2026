#!/bin/bash
cd "/c/Users/Student 06/CCC_auto/games/ccc42/level_6/opt/"
PY="/c/Users/Student 06/AppData/Local/Programs/Python/Python312/python.exe"
until grep -q "total" glog_mG65536.txt 2>/dev/null; do sleep 2; done
for W in 16384 32768; do
ORDER_REF=w_2-medium.out "$PY" -W ignore gpu6.py ../input/in_level-6_2-medium.txt x_mG$W.out $W > glog_mG$W.txt 2>&1
done
