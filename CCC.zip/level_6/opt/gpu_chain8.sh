#!/bin/bash
cd "/c/Users/Student 06/CCC_auto/games/ccc42/level_6/opt/"
until grep -q "ALL DONE" glog_relG65536.txt 2>/dev/null; do sleep 2; done
MINLEN=16 ./gpu_allwrap2.sh 131072 el
