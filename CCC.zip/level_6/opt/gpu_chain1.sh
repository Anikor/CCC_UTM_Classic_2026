#!/bin/bash
cd "/c/Users/Student 06/CCC_auto/games/ccc42/level_6/opt/"
PY="/c/Users/Student 06/AppData/Local/Programs/Python/Python312/python.exe"
W=$1; shift
for f in "$@"; do
  case $f in e) fid=4-enormous;; l) fid=3-large;; m) fid=2-medium;; esac
  "$PY" -W ignore gpu6.py ../input/in_level-6_$fid.txt x_${f}G$W.out $W > glog_${f}G$W.txt 2>&1
done
