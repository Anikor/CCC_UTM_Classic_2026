#!/bin/bash
# usage: gpu_resume.sh f W   (restarts on crash, skipping solved cases)
cd "/c/Users/Student 06/CCC_auto/games/ccc42/level_6/opt/"
PY="/c/Users/Student 06/AppData/Local/Programs/Python/Python312/python.exe"
f=$1; W=$2
case $f in e) fid=4-enormous;; l) fid=3-large;; m) fid=2-medium;; esac
for it in 1 2 3 4 5 6 7 8; do
  RESUME=1 ORDER_REF=w_$fid.out "$PY" -W ignore gpu6.py ../input/in_level-6_$fid.txt x_${f}G$W.out $W >> glog_${f}G$W.txt 2>&1 && break
done
