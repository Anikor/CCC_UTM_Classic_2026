// bs6b: bs6s + copy-boundary branching with next-copy lookahead.  ./bs6b <in> <out> W threads [K=3] [D=2]
#include <bits/stdc++.h>
using namespace std;
typedef bitset<512> BS;
struct Geo {
    int R, rows, cols, M; vector<string> g; vector<pair<int,int>> ring; int start[6];
    vector<vector<int>> id; int ncell; vector<vector<BS>> beam;
    int D[6][2] = {{0,2},{1,1},{1,-1},{0,-2},{-1,-1},{-1,1}};
    Geo(int R_):R(R_){
        rows=2*R+1; cols=4*R+1; g.assign(rows,string(cols,'-')); id.assign(rows,vector<int>(cols,-1)); ncell=0;
        for(int i=0;i<rows;i++){int off=abs(i-R); for(int j=off;j<=cols-1-off;j+=2){bool b=(i==0||i==rows-1||j==off||j==cols-1-off); g[i][j]=b?'*':'O'; if(!b) id[i][j]=ncell++;}}
        for(int t=0;t<R;t++) ring.push_back({0,R+2*t}); for(int t=0;t<R;t++) ring.push_back({t,3*R+t});
        for(int t=0;t<R;t++) ring.push_back({R+t,4*R-t}); for(int t=0;t<R;t++) ring.push_back({2*R,3*R-2*t});
        for(int t=0;t<R;t++) ring.push_back({2*R-t,R-t}); for(int t=0;t<R;t++) ring.push_back({R-t,t});
        M=ring.size(); int s[6]={5*R,0,R,2*R,3*R,4*R}; for(int e=0;e<6;e++)start[e]=s[e];
        beam.assign(6,vector<BS>(M));
        for(int e=0;e<6;e++)for(int p=0;p<M;p++){int y=ring[p].first+D[e][0],x=ring[p].second+D[e][1]; while(y>=0&&y<rows&&x>=0&&x<cols){ if(id[y][x]>=0) beam[e][p].set(id[y][x]); y+=D[e][0];x+=D[e][1];}}
    }
    int rd(int p,int q)const{int f=((q-p)%M+M)%M; return min(f,M-f);}
};
struct State { unsigned char pos[6]; unsigned char act; BS board; int copies; int score; int parent; unsigned short mv; };
static inline int popc(const BS&b){return (int)b.count();}
struct Case { int R,rows,cols,need; vector<string> pat; };
struct Ctx { Geo G; BS pat, adj; int npat; Ctx(const Case&c):G(c.R){ vector<pair<int,int>> pm;
    for(int i=0;i<c.rows;i++)for(int j=0;j<c.cols;j++) if(c.pat[i][j]=='M'){pat.set(G.id[i][j]); pm.push_back({i,j});}
    npat=popc(pat); int NBd[6][2]={{0,2},{0,-2},{1,1},{1,-1},{-1,1},{-1,-1}};
    for(auto&cc:pm) for(auto&d:NBd){int y=cc.first+d[0],x=cc.second+d[1]; if(y>=0&&y<G.rows&&x>=0&&x<G.cols&&G.id[y][x]>=0&&!pat[G.id[y][x]]) adj.set(G.id[y][x]);} } };
struct Cand { string prog; int len; int copies; State end; long long pre; };
static const char INS[4]={'-','F','B','T'};

static string reconstruct(const vector<vector<State>>& layers, int li, int si){
    vector<int> mvs; while(li>0){ mvs.push_back(layers[li][si].mv); si=layers[li][si].parent; li--; }
    reverse(mvs.begin(),mvs.end()); string out;
    for(int mv:mvs){ int m=mv; for(int e=0;e<6;e++){ out+=INS[m&3]; m>>=2; out+=(e==5?'\n':' ');} } return out;
}
// beam search from start; target copies NEED; if D>=0 collect completed states for D extra ticks after first completion
static vector<Cand> run(const Ctx& X, int W, const State& start, int NEED, int D, int maxDepth){
    const Geo& G=X.G; const BS& pat=X.pat; const BS& adj=X.adj;
    vector<vector<State>> layers; State s0=start; s0.copies=0; s0.parent=-1; s0.mv=0; layers.push_back({s0});
    int depth=0, firstDone=-1; vector<pair<int,int>> found; vector<int> near(6*G.M);
    while(depth<maxDepth){
        if(firstDone>=0 && depth>firstDone+D) break;
        vector<State>& cur=layers.back(); vector<State> nxt; nxt.reserve(cur.size()*64);
        unordered_set<unsigned long long> seen;
        for(int pi=0;pi<(int)cur.size();pi++){
            const State& s=cur[pi]; BS needed=pat&~s.board;
            int useful[6][80]; for(int e=0;e<6;e++)for(int p=0;p<G.M;p++) useful[e][p]=((G.beam[e][p]&needed).any()?1:0);
            for(int e=0;e<6;e++) for(int p=0;p<G.M;p++){int best=G.M; for(int q=0;q<G.M;q++) if(useful[e][q]) best=min(best,G.rd(p,q)); near[e*G.M+p]=best;}
            for(int mv=0;mv<4096;mv++){
                State t=s; t.parent=pi; t.mv=mv; int m=mv;
                for(int e=0;e<6;e++){int o=m&3; m>>=2; if(o==1)t.pos[e]=(t.pos[e]+1)%G.M; else if(o==2)t.pos[e]=(t.pos[e]+G.M-1)%G.M; else if(o==3)t.act^=(1<<e);}
                BS c1,c2,c3; for(int e=0;e<6;e++) if(t.act>>e&1){const BS&b=G.beam[e][t.pos[e]]; c3|=c2&b; c2|=c1&b; c1|=b;}
                BS created=c2&~c3, destroyed=c3;
                if((created&adj).any()) continue;
                if((destroyed&t.board&pat).any()) continue;
                BS nb=(t.board|created)&~destroyed; t.copies=s.copies;
                if((nb&pat)==pat){ t.copies++; nb&=~pat; }
                if(t.copies>NEED) continue;
                t.board=nb;
                unsigned long long h=t.act; for(int e=0;e<6;e++) h=h*131+t.pos[e]; h=h*1000003+t.copies;
                for(int w=0;w<8;w++){ unsigned long long wv=0; for(int b=0;b<64;b++) if(t.board[w*64+b]) wv|=1ULL<<b; h=h*1000000007ULL+wv; }
                if(!seen.insert(h).second) continue;
                int donec=popc(t.board&pat); BS need2=pat&~t.board; int pot=0,dsum=0;
                for(int e=0;e<6;e++){ int onl=popc(G.beam[e][t.pos[e]]&need2); pot+=(t.act>>e&1)?3*onl:onl; dsum+=near[e*G.M+t.pos[e]]; }
                t.score=t.copies*100000+donec*300+pot*4-dsum*3;
                nxt.push_back(t);
                if(t.copies==NEED){ if(firstDone<0) firstDone=depth+1; found.push_back({depth+1,(int)nxt.size()-1}); }
            }
        }
        if(nxt.empty()) break;
        if((int)nxt.size()>W){ nth_element(nxt.begin(),nxt.begin()+W,nxt.end(),[](const State&a,const State&b){return a.score>b.score;}); nxt.resize(W); }
        // after resize, indices in 'found' for this layer are stale: recollect from nxt
        found.erase(remove_if(found.begin(),found.end(),[&](const pair<int,int>&f){return f.first==depth+1;}),found.end());
        for(int i=0;i<(int)nxt.size();i++) if(nxt[i].copies==NEED) found.push_back({depth+1,i});
        layers.push_back(move(nxt)); depth++;
        if(D<0 && firstDone>=0) break;
    }
    vector<Cand> out;
    for(auto&f:found){ Cand c; c.len=f.first; c.end=layers[f.first][f.second]; c.copies=c.end.copies;
        c.pre=-(long long)(f.first-firstDone)*700 + (c.end.score - c.copies*100000); c.prog=reconstruct(layers,f.first,f.second); out.push_back(c); }
    return out;
}
static string solveSeq(const Ctx&X,const Case&c,int W,long long&L){ State s0; memset(&s0,0,sizeof s0); for(int e=0;e<6;e++)s0.pos[e]=X.G.start[e];
    auto v=run(X,W,s0,c.need,-1,100+4*X.npat*c.need); if(v.empty()) return ""; int bi=0; for(int i=1;i<(int)v.size();i++) if(v[i].len<v[bi].len) bi=i; L=v[bi].len; return v[bi].prog; }
static string solveBranch(const Ctx&X,const Case&c,int W,int K,int D,long long&L){
    State st; memset(&st,0,sizeof st); for(int e=0;e<6;e++)st.pos[e]=X.G.start[e];
    string prog; int done=0; long long total=0; int maxD=100+4*X.npat;
    while(done<c.need){ int rem=c.need-done;
        auto v=run(X,W,st,1,D,maxD); if(v.empty()) return "";
        // shortest always first
        sort(v.begin(),v.end(),[](const Cand&a,const Cand&b){return a.pre>b.pre;});
        int shortest=0; for(int i=1;i<(int)v.size();i++) if(v[i].len<v[shortest].len) shortest=i;
        vector<int> pick; pick.push_back(shortest); for(int i=0;i<(int)v.size()&&(int)pick.size()<K;i++) if(i!=shortest) pick.push_back(i);
        int best=-1; long long bestc=LLONG_MAX;
        if(rem==1){ best=shortest; }
        else for(int i:pick){ auto w=run(X,W,v[i].end,1,-1,maxD); if(w.empty()) continue; int L2=INT_MAX; for(auto&x:w) L2=min(L2,x.len);
            long long cst=v[i].len+L2; if(cst<bestc){bestc=cst; best=i;} }
        if(best<0) return "";
        prog+=v[best].prog; total+=v[best].len; st=v[best].end; done+=1;
    }
    L=total; return prog;
}
int main(int argc,char**argv){
    if(argc<3){fprintf(stderr,"usage\n");return 1;}
    int W=argc>3?atoi(argv[3]):64; int TH=argc>4?atoi(argv[4]):2; int K=argc>5?atoi(argv[5]):3; int D=argc>6?atoi(argv[6]):2;
    ifstream in(argv[1]); int n; in>>n; vector<Case> cs(n);
    for(auto&c:cs){ in>>c.R>>c.rows>>c.cols>>c.need; c.pat.resize(c.rows); for(auto&r:c.pat) in>>r; }
    vector<string> res(n); vector<long long> lines(n,0); vector<int> src(n,0); atomic<int> idx(0);
    vector<thread> th; for(int t=0;t<TH;t++) th.emplace_back([&]{ for(;;){ int i=idx++; if(i>=n)break; Ctx X(cs[i]);
        long long l1=LLONG_MAX,l2=LLONG_MAX; string r1=solveSeq(X,cs[i],W,l1); if(r1.empty()) l1=LLONG_MAX;
        string r2=cs[i].need>1?solveBranch(X,cs[i],W,K,D,l2):""; if(r2.empty()) l2=LLONG_MAX;
        if(l2<l1){res[i]=r2;lines[i]=l2;src[i]=1;} else {res[i]=r1;lines[i]=(l1==LLONG_MAX?0:l1);} } });
    for(auto&t:th)t.join();
    long long tot=0; int fail=0,nb=0; ofstream out(argv[2]);
    for(int i=0;i<n;i++){ if(res[i].empty()){fail++; out<<"FAIL\n";} else out<<res[i]; if(i+1<n) out<<"\n"; tot+=lines[i]; nb+=src[i]; }
    fprintf(stderr,"%s: score %lld fails %d branch-wins %d (W=%d K=%d D=%d)\n",argv[1],tot,fail,nb,W,K,D);
}
