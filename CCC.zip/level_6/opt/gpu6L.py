#!/usr/bin/env python3
"""gpu6 + relaxed destroy rule + lower-bound rerank: the K selected children are rescored with
score - KLB*LB, LB = max over unbuilt pattern cells of (2nd-smallest emitter distance to a beam through it,
+1 if that emitter is off) = earliest tick the last cell could still be built.
  python gpu6L.py test <W>                  # relaxed vs relaxed+LB on long e/l cases
  python gpu6L.py run <f> <W> <KLB> <stop>  # whole file, longest first -> x_<f>L<W>.out"""
import sys, time
import numpy as np
import cupy as cp
import gpu6snap as g

S = g.SRC
PRUNE = 'if (c3[k] & bd) bad = true;'
MAT = 'int score = evalc(w, M, pos, act, nb, cop, BP, nearT);'
HDR = 'extern "C" __global__ void materialize('
assert S.count(PRUNE) == 1 and S.count(MAT) == 1 and S.count(HDR) == 1
LBF = r'''
extern "C" { __device__ unsigned char QT[6*512]; __device__ int KLBv; }
__device__ __forceinline__ int lbterm(int M, const int* pos, int act, const u64* nb, const u64* __restrict__ PM){
    int lb = 0;
    for (int k=0;k<NWP;k++){ u64 rem = PM[k] & ~nb[k];
        while (rem){ int b = __ffsll((long long)rem)-1; rem &= rem-1ULL; int idx = k*64+b;
            int m1=1000, m2=1000;
            for (int e=0;e<6;e++){ int q = QT[e*512+idx]; if (q==255) continue; int d = pos[e]-q; if (d<0) d=-d; if (d > M-d) d = M-d;
                if (!((act>>e)&1)) d += 1;
                if (d<m1){ m2=m1; m1=d; } else if (d<m2) m2=d; }
            if (m2<1000 && m2>lb) lb=m2; } }
    return lb;
}
'''
RELAX = S.replace(PRUNE, '')
LBSRC = RELAX.replace(HDR, LBF + HDR).replace(MAT, 'int score = evalc(w, M, pos, act, nb, cop, BP, nearT) - KLBv * lbterm(M, pos, act, nb, PM);')
CUR = {'lb': True, 'klb': 300, 'qt': None}
_mods = {}
def getmod2(NWP, NWA):
    key = (NWP, NWA, CUR['lb'])
    if key not in _mods:
        _mods[key] = cp.RawModule(code=LBSRC if CUR['lb'] else RELAX, options=('-DNWP=%d' % NWP, '-DNWA=%d' % NWA, '-std=c++14'))
    m = _mods[key]
    if CUR['lb']:
        m.get_global('QT').copy_from_host(CUR['qt'].ctypes.data, CUR['qt'].nbytes)
        k = np.array([CUR['klb']], np.int32); m.get_global('KLBv').copy_from_host(k.ctypes.data, 4)
    return (m.get_function('expand'), m.get_function('compact'), m.get_function('materialize'), m.get_function('nearK'))
g.getmod = getmod2

def qtable(case):
    R, rows, cols, need, pat = case
    _, _, idg, ring, M, start, beam = g.geo(R)
    plist = [(i, j) for i in range(rows) for j in range(cols) if pat[i][j] == 'M']
    qt = np.full(6 * 512, 255, np.uint8)
    for e in range(6):
        where = {}
        for p in range(M):
            for c in beam[e][p]: where[c] = p
        for k, c in enumerate(plist):
            if c in where: qt[e * 512 + k] = where[c]
    return qt

def solve(case, W, lb, klb=300):
    CUR['lb'] = lb; CUR['klb'] = klb
    if lb: CUR['qt'] = qtable(case)
    return g.solve(case, W, 4.0)

FID = {'e': '4-enormous', 'l': '3-large', 'm': '2-medium'}
if __name__ == '__main__':
    if sys.argv[1] == 'test':
        W = int(sys.argv[2]); tot = {}
        for f in 'el':
            cs = g.parse('../input/in_level-6_%s.txt' % FID[f]); best = g.refl('w_%s.out' % FID[f])
            for i in sorted(range(len(cs)), key=lambda i: -best[i])[:6]:
                r = [solve(cs[i], W, False), solve(cs[i], W, True, 300), solve(cs[i], W, True, 900)]
                L = [len(x) if x else 999 for x in r]
                t = tot.setdefault(f, [0, 0, 0, 0])
                for j in range(3): t[j] += L[j]
                t[3] += best[i]
                print('%s case %d: relaxed %d  LB300 %d  LB900 %d  (best %d)' % (f, i, L[0], L[1], L[2], best[i]), flush=True)
        print('TOTAL', tot, flush=True)
    else:
        f, W, klb, stop = sys.argv[2], int(sys.argv[3]), int(sys.argv[4]), sys.argv[5]
        cs = g.parse('../input/in_level-6_%s.txt' % FID[f]); best = g.refl('w_%s.out' % FID[f])
        res = [None] * len(cs); lastw = 0
        import os
        outp = 'x_%sL%d.out' % (f, W)
        if os.path.exists(outp):
            rb = [x for x in open(outp).read().replace(chr(13)+chr(10), chr(10)).split(chr(10)+chr(10)) if x.strip()]
            if len(rb) == len(cs):
                for k, x in enumerate(rb):
                    if 'FAIL' not in x: res[k] = x.strip().split(chr(10))
        for i in sorted(range(len(cs)), key=lambda i: -best[i]):
            if time.strftime('%H%M', time.gmtime()) >= stop: break
            if res[i] is not None: continue
            r = solve(cs[i], W, True, klb); res[i] = r
            print('%s case %d: %s (best %d)' % (f, i, len(r) if r else 'FAIL', best[i]), file=sys.stderr, flush=True)
            if time.time() - lastw > 20: g.writeout('x_%sL%d.out' % (f, W), res); lastw = time.time()
        g.writeout('x_%sL%d.out' % (f, W), res)
