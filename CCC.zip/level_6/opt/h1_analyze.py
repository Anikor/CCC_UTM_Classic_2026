import sys
from collections import defaultdict, Counter
_argv=sys.argv; sys.argv=['x']
exec(open('nano6.py').read().replace('\nmain()\n','\n'))
sys.argv=_argv
inp,outp=sys.argv[1:3]
cases=parse(inp); blocks=[b for b in open(outp).read().split('\n\n') if b.strip()]
hist=Counter(); zero=0; tot=0; actives=Counter(); fails=[]
percase=[]
for ci,((R,rows,cols,need,pat),b) in enumerate(zip(cases,blocks)):
    if 'FAIL' in b: fails.append(ci); continue
    prog=[l.split() for l in b.strip().split('\n')]
    geo=Geo(R); board=[r[:] for r in geo.g]
    pm=[(i,j) for i in range(rows) for j in range(cols) if pat[i][j]=='M']
    pos=list(geo.start); act=[False]*6; z=0
    for line in prog:
        for e,ins in enumerate(line):
            if ins=='F': pos[e]=(pos[e]+1)%geo.M
            elif ins=='B': pos[e]=(pos[e]-1)%geo.M
            elif ins=='T': act[e]=not act[e]
        cnt=defaultdict(int)
        for e in range(6):
            if act[e]:
                for c in geo.beam[(e,pos[e])]: cnt[c]+=1
        created=0
        for c,k in cnt.items():
            if k==2 and board[c[0]][c[1]]!='M': created+=1; board[c[0]][c[1]]='M'
            elif k>=3: board[c[0]][c[1]]='O'
        if all(board[i][j]=='M' for i,j in pm):
            for i,j in pm: board[i][j]='O'
        hist[created]+=1; tot+=1; actives[sum(act)]+=1
        if created==0: z+=1
    percase.append((len(prog), need, len(pm), z, R))
print('ticks',tot,'zero-creation ticks',sum(1 for p in percase for _ in [0])and sum(p[3] for p in percase), 'hist created/tick',sorted(hist.items()))
print('active beams/tick',sorted(actives.items()))
print('fails',fails)
# worst cases by lines per cell-copy
pc=sorted(percase,key=lambda p:-p[0]/(p[1]*p[2]))
print('worst lines/cell:',[(round(p[0]/(p[1]*p[2]),2),'lines',p[0],'need',p[1],'cells',p[2],'zero',p[3],'R',p[4]) for p in pc[:6]])
print('best lines/cell:',[(round(p[0]/(p[1]*p[2]),2),'lines',p[0],'need',p[1],'cells',p[2],'zero',p[3],'R',p[4]) for p in pc[-3:]])
