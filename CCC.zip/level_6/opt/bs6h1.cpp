// Beam search for level 6, H1 variant.
// ./bs6h1 <in> <out> [W0=64] [threads=2] [budget_sec=20] [Wmax=4096] [wdone=1000] [wpotA=12] [wpotI=4] [wdist=3] [wlook=60] [potcap=6] [bucketK=16]
#include <bits/stdc++.h>
using namespace std;
struct BS { uint64_t w[8];
    BS(){memset(w,0,sizeof w);}
    inline void set(int i){w[i>>6]|=1ULL<<(i&63);}
    inline bool test(int i)const{return w[i>>6]>>(i&63)&1;}
    inline bool any()const{for(int i=0;i<8;i++)if(w[i])return true;return false;}
    inline int count()const{int c=0;for(int i=0;i<8;i++)c+=__builtin_popcountll(w[i]);return c;}
    inline BS operator&(const BS&o)const{BS r;for(int i=0;i<8;i++)r.w[i]=w[i]&o.w[i];return r;}
    inline BS operator|(const BS&o)const{BS r;for(int i=0;i<8;i++)r.w[i]=w[i]|o.w[i];return r;}
    inline BS operator~()const{BS r;for(int i=0;i<8;i++)r.w[i]=~w[i];return r;}
    inline BS&operator|=(const BS&o){for(int i=0;i<8;i++)w[i]|=o.w[i];return *this;}
    inline BS&operator&=(const BS&o){for(int i=0;i<8;i++)w[i]&=o.w[i];return *this;}
    inline bool operator==(const BS&o)const{for(int i=0;i<8;i++)if(w[i]!=o.w[i])return false;return true;}
    inline uint64_t hash()const{uint64_t h=1469598103934665603ULL;for(int i=0;i<8;i++){h^=w[i];h*=1099511628211ULL;h^=h>>29;}return h;}
};
static inline int andcount(const BS&a,const BS&b){int c=0;for(int i=0;i<8;i++)c+=__builtin_popcountll(a.w[i]&b.w[i]);return c;}
static inline bool andany(const BS&a,const BS&b){for(int i=0;i<8;i++)if(a.w[i]&b.w[i])return true;return false;}
struct Geo {
    int R, rows, cols, M; vector<string> g; vector<pair<int,int>> ring; int start[6];
    vector<vector<int>> id; int ncell;
    vector<vector<BS>> beam; // [e][p]
    int D[6][2] = {{0,2},{1,1},{1,-1},{0,-2},{-1,-1},{-1,1}};
    Geo(int R_):R(R_){
        rows=2*R+1; cols=4*R+1; g.assign(rows,string(cols,'-')); id.assign(rows,vector<int>(cols,-1)); ncell=0;
        for(int i=0;i<rows;i++){int off=abs(i-R); for(int j=off;j<=cols-1-off;j+=2){bool b=(i==0||i==rows-1||j==off||j==cols-1-off); g[i][j]=b?'*':'O'; if(!b) id[i][j]=ncell++;}}
        for(int t=0;t<R;t++) ring.push_back({0,R+2*t}); for(int t=0;t<R;t++) ring.push_back({t,3*R+t});
        for(int t=0;t<R;t++) ring.push_back({R+t,4*R-t}); for(int t=0;t<R;t++) ring.push_back({2*R,3*R-2*t});
        for(int t=0;t<R;t++) ring.push_back({2*R-t,R-t}); for(int t=0;t<R;t++) ring.push_back({R-t,t});
        M=ring.size(); int s[6]={5*R,0,R,2*R,3*R,4*R}; for(int e=0;e<6;e++)start[e]=s[e];
        beam.assign(6,vector<BS>(M));
        for(int e=0;e<6;e++)for(int p=0;p<M;p++){int y=ring[p].first+D[e][0],x=ring[p].second+D[e][1]; while(y>=0&&y<rows&&x>=0&&x<cols){ if(id[y][x]>=0) beam[e][p].set(id[y][x]); y+=D[e][0];x+=D[e][1];}}
    }
    int rd(int p,int q)const{int f=((q-p)%M+M)%M; return min(f,M-f);}
};
struct State { unsigned char pos[6]; unsigned char act; BS board; int copies; int score; int parent; unsigned short mv; };
struct Case { int R,rows,cols,need; vector<string> pat; };
struct Wt { int wdone=300, wpotA=12, wpotI=4, wdist=3, wlook=0, potcap=999, bucketK=999, wpen=0; };

string solve(const Case& c, int W, const Wt& wt, long long& outlines){
    Geo G(c.R); BS pat; 
    for(int i=0;i<c.rows;i++)for(int j=0;j<c.cols;j++) if(c.pat[i][j]=='M') pat.set(G.id[i][j]);
    int npat=pat.count();
    BS adj; { int NBd[6][2]={{0,2},{0,-2},{1,1},{1,-1},{-1,1},{-1,-1}};
      for(int i=0;i<c.rows;i++)for(int j=0;j<c.cols;j++) if(c.pat[i][j]=='M') for(auto&d:NBd){int y=i+d[0],x=j+d[1]; if(y>=0&&y<G.rows&&x>=0&&x<G.cols&&G.id[y][x]>=0&&!pat.test(G.id[y][x])) adj.set(G.id[y][x]);} }
    BS notpat=~pat;
    vector<vector<State>> layers;
    State s0; memset(&s0,0,sizeof s0); for(int e=0;e<6;e++)s0.pos[e]=G.start[e]; s0.act=0; s0.copies=0; s0.parent=-1; s0.mv=0; s0.board=BS();
    layers.push_back({s0});
    const char INS[4]={'-','F','B','T'};
    int done=-1; int depth=0;
    int maxdepth = 100 + 4*npat*c.need;
    vector<int> near(6*G.M);
    unordered_set<uint64_t> seen; seen.reserve(1<<18);
    vector<State> nxt; nxt.reserve((size_t)W*4096/4);
    while(done<0 && depth<maxdepth){
        vector<State>& cur=layers.back(); nxt.clear(); seen.clear();
        for(int pi=0;pi<(int)cur.size();pi++){
            const State& s=cur[pi]; BS needed = pat & ~s.board;
            if(!needed.any()) needed=pat; // (shouldn't happen)
            int useful[6][80]; for(int e=0;e<6;e++)for(int p=0;p<G.M;p++) useful[e][p]=andany(G.beam[e][p],needed)?1:0;
            for(int e=0;e<6;e++) for(int p=0;p<G.M;p++){int best=G.M; for(int q=0;q<G.M;q++) if(useful[e][q]) best=min(best,G.rd(p,q)); near[e*G.M+p]=best;}
            for(int mv=0;mv<4096;mv++){
                State t=s; t.parent=pi; t.mv=mv; int m=mv;
                for(int e=0;e<6;e++){int o=m&3; m>>=2; if(o==1)t.pos[e]=(t.pos[e]+1)%G.M; else if(o==2)t.pos[e]=(t.pos[e]+G.M-1)%G.M; else if(o==3)t.act^=(1<<e);}
                BS c1,c2,c3; for(int e=0;e<6;e++) if(t.act>>e&1){const BS&b=G.beam[e][t.pos[e]]; c3|=c2&b; c2|=c1&b; c1|=b;}
                BS created=c2&~c3; BS destroyed=c3;
                if(andany(created,adj)) continue;            // stray adjacent to the pattern blocks collection
                if(andany(destroyed,t.board&pat)) continue;  // destroying pattern matter
                BS nb=(t.board|created)&~destroyed;
                t.copies=s.copies;
                bool completed=false;
                if((nb&pat)==pat){ t.copies++; nb&=~pat; completed=true; }
                t.board=nb;
                uint64_t h=t.act; for(int e=0;e<6;e++) h=h*131+t.pos[e]; h=h*1000003+t.copies; h^=t.board.hash()*0x9E3779B97F4A7C15ULL;
                if(!seen.insert(h).second) continue;
                int donec=andcount(t.board,pat); BS need2=pat&~t.board;
                int pot=0, dsum=0, look=0;
                BS hit1=c1&~c2;
                for(int e=0;e<6;e++){
                    const BS& L=G.beam[e][t.pos[e]];
                    int onl=andcount(L,need2); if(onl>wt.potcap) onl=wt.potcap;
                    if(t.act>>e&1){ pot+=wt.wpotA*onl; if(onl==0) pot-=wt.wpen; }
                    else { pot+=wt.wpotI*onl;
                        // toggle-on lookahead: cells hit once now that lie on L become created; must be all needed, and no destroy of board cells via c2
                        BS cr=L&hit1; if(cr.any() && !andany(cr,adj) && !andany(L&c2,t.board&pat)){ int k=andcount(cr,need2); if(k>look) look=k; }
                    }
                    dsum += completed ? 0 : near[e*G.M+t.pos[e]];
                }
                t.score = t.copies*1000000 + donec*wt.wdone + pot + wt.wlook*look - dsum*wt.wdist;
                nxt.push_back(t);
                if(t.copies==c.need){ done=(int)nxt.size()-1; }
            }
            if(done>=0) break;
        }
        if(nxt.empty()) return "";
        if(done<0 && (int)nxt.size()>W){
            sort(nxt.begin(), nxt.end(), [](const State&a,const State&b){return a.score>b.score;});
            // diversity: at most bucketK states per identical (board,copies)
            vector<State> keep; keep.reserve(W); unordered_map<uint64_t,int> cntb; cntb.reserve(W*2);
            for(const State& st: nxt){ uint64_t bh=st.board.hash()^((uint64_t)st.copies*0x9E3779B97F4A7C15ULL); int& k=cntb[bh]; if(k>=wt.bucketK) continue; k++; keep.push_back(st); if((int)keep.size()>=W) break; }
            nxt.swap(keep);
        }
        layers.push_back(nxt); depth++;
    }
    if(done<0) return "";
    vector<int> mvs; int li=layers.size()-1, si=done;
    while(li>0){ mvs.push_back(layers[li][si].mv); si=layers[li][si].parent; li--; }
    reverse(mvs.begin(),mvs.end()); string out;
    for(int mv:mvs){ int m=mv; for(int e=0;e<6;e++){ out+=INS[m&3]; m>>=2; out+= (e==5?'\n':' ');} }
    outlines=mvs.size(); return out;
}

int main(int argc,char**argv){
    if(argc<3){fprintf(stderr,"usage\n");return 1;}
    int W0=argc>3?atoi(argv[3]):64; int TH=argc>4?atoi(argv[4]):2; double budget=argc>5?atof(argv[5]):20.0; int Wmax=argc>6?atoi(argv[6]):4096;
    Wt wt; if(argc>7)wt.wdone=atoi(argv[7]); if(argc>8)wt.wpotA=atoi(argv[8]); if(argc>9)wt.wpotI=atoi(argv[9]); if(argc>10)wt.wdist=atoi(argv[10]); if(argc>11)wt.wlook=atoi(argv[11]); if(argc>12)wt.potcap=atoi(argv[12]); if(argc>13)wt.bucketK=atoi(argv[13]); if(argc>14)wt.wpen=atoi(argv[14]);
    ifstream in(argv[1]); int n; in>>n; vector<Case> cs(n);
    for(auto&c:cs){ in>>c.R>>c.rows>>c.cols>>c.need; c.pat.resize(c.rows); for(auto&r:c.pat) in>>r; }
    vector<string> res(n); vector<long long> lines(n,0); atomic<int> idx(0);
    vector<thread> th; for(int t=0;t<TH;t++) th.emplace_back([&]{ for(;;){ int i=idx++; if(i>=n)break;
        auto t0=chrono::steady_clock::now(); double spent=0, last=0; long long bestl=LLONG_MAX; string bests;
        for(int W=W0; W<=Wmax; W*=2){
            auto t1=chrono::steady_clock::now(); long long l=0; string r=solve(cs[i],W,wt,l);
            last=chrono::duration<double>(chrono::steady_clock::now()-t1).count(); spent=chrono::duration<double>(chrono::steady_clock::now()-t0).count();
            if(!r.empty() && l<bestl){bestl=l; bests=r;}
            if(spent + last*2.2 > budget) break;
        }
        if(bests.empty()){ for(int w2: {16,8,32}){ long long l=0; string r=solve(cs[i],w2,wt,l); if(!r.empty()){bests=r; bestl=l; break;} } }
        res[i]=bests; lines[i]=(bestl==LLONG_MAX?0:bestl); } });
    for(auto&t:th)t.join();
    long long tot=0; int fail=0; ofstream out(argv[2]);
    for(int i=0;i<n;i++){ if(res[i].empty()){fail++; out<<"FAIL\n";} else {out<<res[i];} if(i+1<n) out<<"\n"; tot+=lines[i]; }
    fprintf(stderr,"%s: score %lld fails %d (W0=%d budget=%.1f wdone=%d potA=%d potI=%d dist=%d look=%d cap=%d K=%d)\n",argv[1],tot,fail,W0,budget,wt.wdone,wt.wpotA,wt.wpotI,wt.wdist,wt.wlook,wt.potcap,wt.bucketK);
}
