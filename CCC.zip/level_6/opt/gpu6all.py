#!/usr/bin/env python3
"""Run gpu6.solve over all three level-6 files, cases ordered by current best length (desc, across files).
usage: python gpu6all.py W [files=elm]   -> writes x_<f>G<W>.out progressively (FAIL for pending)."""
import sys, os, time
sys.argv_saved = list(sys.argv)
import gpu6
if os.environ.get('RELAX'):
    assert gpu6.SRC.count('if (c3[k] & bd) bad = true;') == 1
    gpu6.SRC = gpu6.SRC.replace('if (c3[k] & bd) bad = true;', '')
TAG = os.environ.get('TAG', 'G')
W = int(sys.argv[1]); fl = sys.argv[2] if len(sys.argv) > 2 else 'elm'
FID = {'e': '4-enormous', 'l': '3-large', 'm': '2-medium'}
cases = {}; res = {}; jobs = []
for f in fl:
    fid = FID[f]
    cs = gpu6.parse('../input/in_level-6_%s.txt' % fid); cases[f] = cs; res[f] = [None]*len(cs)
    rl = None
    for ref in ('w_%s.out' % fid, 'final_%s.out' % fid):
        try:
            r = gpu6.refl(ref)
            if len(r) == len(cs): rl = r; break
        except Exception: pass
    if rl is None: rl = [0]*len(cs)
    if os.environ.get('RESUME') and os.path.exists('x_%s%s%d.out' % (f, TAG, W)):
        try:
            rb = [x for x in open('x_%s%s%d.out' % (f, TAG, W)).read().replace(chr(13)+chr(10), chr(10)).split(chr(10)+chr(10)) if x.strip()]
            if len(rb) == len(cs):
                for k, x in enumerate(rb):
                    if 'FAIL' not in x: res[f][k] = x.strip().split(chr(10))
        except Exception: pass
    for i in range(len(cs)):
        if res[f][i] is None and rl[i] >= int(os.environ.get('MINLEN', '0')): jobs.append((rl[i], f, i))
jobs.sort(key=lambda t: (t[0] if os.environ.get('ORDER') == 'asc' else -t[0]))
t0 = time.time(); lastw = 0; tot = {f: 0 for f in fl}; refsum = {f: 0 for f in fl}
for n, (rl, f, i) in enumerate(jobs):
    tc = time.time()
    try:
        r = gpu6.solve(cases[f][i], W, 4.0)
    except Exception as ex:
        print('CRASH', f, i, repr(ex)[:200], file=sys.stderr, flush=True)
        for g in fl: gpu6.writeout('x_%s%s%d.out' % (g, TAG, W), res[g])
        os._exit(3)
    res[f][i] = r
    if r is not None: tot[f] += len(r); refsum[f] += rl
    print(f'{f} case {i}: {len(r) if r else "FAIL"} (ref {rl})  {time.time()-tc:.2f}s  tot {tot} ref {refsum} elapsed {time.time()-t0:.0f}s', file=sys.stderr, flush=True)
    if time.time() - lastw > 20 or n == len(jobs)-1:
        for g in fl: gpu6.writeout('x_%s%s%d.out' % (g, TAG, W), res[g])
        lastw = time.time()
for g in fl: gpu6.writeout('x_%s%s%d.out' % (g, TAG, W), res[g])
print(f'ALL DONE W={W} tot {tot} ref {refsum} time {time.time()-t0:.0f}s', file=sys.stderr, flush=True)
