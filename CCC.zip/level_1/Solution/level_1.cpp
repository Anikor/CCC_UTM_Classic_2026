#include <bits/stdc++.h>
using namespace std;
int main(){
    int n;
    if(!(cin>>n))return 0;
    string out;
    for(int k=0;k<n;k++){
        int r;cin>>r;
        if(k>0) out+="\n";
        for(int i=0;i<=2*r;i++){
            int d=abs(i-r);
            int cnt=2*r+1-d;
            string line(d,'-');
            for(int j=0;j<cnt;j++){
                if(j>0) line+='-';
                bool border=(d==r)||j==0||j==cnt-1;
                line+=border?'*':'O';
            }
            line+=string(d,'-');
            out+=line;
            out+="\n";
        }
    }
    cout<<out;
    return 0;
}