#include <bits/stdc++.h>
using namespace std;
int main(){
    int n;
    if(!(cin>>n))return 0;
    string out;
    for(int k=0;k<n;k++){
        int r,rows,cols;
        cin>>r>>rows>>cols;
        vector<string> g(rows);
        for(int i=0;i<rows;i++) cin>>g[i];
        vector<vector<int>> cnt(rows);
        for(int i=0;i<rows;i++) cnt[i].assign(g[i].size(),0);
        int emitters=0;
        for(int i=0;i<rows;i++)
            for(int j=0;j<(int)g[i].size();j++){
                char c=g[i][j];
                if(c<'1'||c>'6') continue;
                emitters++;
                int dr=0,dc=0;
                switch(c-'0'){
                    case 1: dr=0;dc=2;break;
                    case 2: dr=1;dc=1;break;
                    case 3: dr=1;dc=-1;break;
                    case 4: dr=0;dc=-2;break;
                    case 5: dr=-1;dc=-1;break;
                    case 6: dr=-1;dc=1;break;
                }
                int y=i+dr,x=j+dc;
                while(y>=0&&y<rows&&x>=0&&x<(int)g[y].size()){
                    cnt[y][x]++;
                    y+=dr;x+=dc;
                }
            }
        if(emitters==0) throw runtime_error("case "+to_string(k)+": no emitter");
        for(int i=0;i<rows;i++)
            for(int j=0;j<(int)g[i].size();j++){
                char &c=g[i][j];
                if(c!='O'&&c!='M') continue;
                if(cnt[i][j]==2) c='M';
                else if(cnt[i][j]>=3) c='O';
            }
        if(k>0) out+="\n";
        for(int i=0;i<rows;i++){out+=g[i];out+="\n";}
    }
    cout<<out;
    return 0;
}