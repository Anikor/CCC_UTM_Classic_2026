#include <bits/stdc++.h>
using namespace std;
int main(){
    int n;
    if(!(cin>>n))return 0;
    string out;
    for(int k=0;k<n;k++){
        int R,rows,cols;
        cin>>R>>rows>>cols;
        if(rows!=2*R+1||cols!=4*R+1) throw runtime_error("case "+to_string(k)+": bad dimensions");
        vector<string> pat(rows);
        for(int i=0;i<rows;i++){
            cin>>pat[i];
            if((int)pat[i].size()!=cols) throw runtime_error("case "+to_string(k)+": bad pattern row width");
        }
        vector<string> g(rows,string(cols,'-'));
        for(int i=0;i<rows;i++){
            int off=abs(i-R);
            for(int j=off;j<=cols-1-off;j+=2){
                bool border=(i==0||i==rows-1||j==off||j==cols-1-off);
                g[i][j]=border?'*':'O';
            }
        }
        vector<pair<int,int>> pm;
        for(int i=0;i<rows;i++)for(int j=0;j<cols;j++){
            if(pat[i][j]=='M'){
                if(g[i][j]!='O') throw runtime_error("case "+to_string(k)+": pattern matter outside board");
                pm.push_back({i,j});
            }
        }
        vector<vector<char>> inPat(rows,vector<char>(cols,0));
        for(auto&p:pm) inPat[p.first][p.second]=1;
        int NR[6]={0,0,1,1,-1,-1},NC[6]={2,-2,1,-1,1,-1};
        vector<pair<int,int>> nb;
        {
            set<pair<int,int>> s;
            for(auto&p:pm)for(int d=0;d<6;d++){
                int y=p.first+NR[d],x=p.second+NC[d];
                if(y<0||y>=rows||x<0||x>=cols)continue;
                if(inPat[y][x])continue;
                s.insert({y,x});
            }
            nb.assign(s.begin(),s.end());
        }
        vector<pair<int,int>> ring;
        for(int t=0;t<R;t++) ring.push_back({0,R+2*t});
        for(int t=0;t<R;t++) ring.push_back({t,3*R+t});
        for(int t=0;t<R;t++) ring.push_back({R+t,4*R-t});
        for(int t=0;t<R;t++) ring.push_back({2*R,3*R-2*t});
        for(int t=0;t<R;t++) ring.push_back({2*R-t,R-t});
        for(int t=0;t<R;t++) ring.push_back({R-t,t});
        int M=ring.size();
        for(auto &p:ring){
            if(p.first<0||p.first>=rows||p.second<0||p.second>=cols||g[p.first][p.second]!='*')
                throw runtime_error("case "+to_string(k)+": bad ring geometry");
        }
        int L;
        cin>>L;
        int pos[6]={5*R,0,R,2*R,3*R,4*R};
        bool act[6]={false,false,false,false,false,false};
        int DR[6]={0,1,1,0,-1,-1};
        int DC[6]={2,1,-1,-2,-1,1};
        vector<vector<int>> cnt(rows,vector<int>(cols,0));
        long long count=0;
        for(int l=0;l<L;l++){
            for(int e=0;e<6;e++){
                string s;
                if(!(cin>>s)) throw runtime_error("case "+to_string(k)+": unexpected EOF");
                char c=s[0];
                if(c=='F') pos[e]=(pos[e]+1)%M;
                else if(c=='B') pos[e]=(pos[e]-1+M)%M;
                else if(c=='T') act[e]=!act[e];
                else if(c=='-'){}
                else throw runtime_error("case "+to_string(k)+": bad instruction "+s);
            }
            for(int i=0;i<rows;i++) fill(cnt[i].begin(),cnt[i].end(),0);
            for(int e=0;e<6;e++){
                if(!act[e]) continue;
                int y=ring[pos[e]].first+DR[e],x=ring[pos[e]].second+DC[e];
                while(y>=0&&y<rows&&x>=0&&x<cols){
                    char c=g[y][x];
                    if(c=='O'||c=='M') cnt[y][x]++;
                    y+=DR[e];x+=DC[e];
                }
            }
            for(int i=0;i<rows;i++)
                for(int j=0;j<cols;j++){
                    char &c=g[i][j];
                    if(c!='O'&&c!='M') continue;
                    if(cnt[i][j]==2) c='M';
                    else if(cnt[i][j]>=3) c='O';
                }
            if(!pm.empty()){
                bool ok=true;
                for(auto&p:pm) if(g[p.first][p.second]!='M'){ok=false;break;}
                if(ok) for(auto&p:nb) if(g[p.first][p.second]=='M'){ok=false;break;}
                if(ok){
                    count++;
                    for(auto&p:pm) g[p.first][p.second]='O';
                }
            }
        }
        out+=to_string(count);
        out+="\n";
    }
    cout<<out;
    return 0;
}