#include <bits/stdc++.h>
using namespace std;
int main(){
    int n;
    if(!(cin>>n))return 0;
    string out;
    for(int k=0;k<n;k++){
        int r,rows,cols;
        cin>>r>>rows>>cols;
        vector<string> g(rows);
        for(int i=0;i<rows;i++) cin>>g[i];
        int er=-1,ec=-1,dir=0;
        for(int i=0;i<rows&&er<0;i++)
            for(int j=0;j<(int)g[i].size();j++)
                if(g[i][j]>='1'&&g[i][j]<='6'){er=i;ec=j;dir=g[i][j]-'0';break;}
        if(er<0) throw runtime_error("case "+to_string(k)+": no emitter");
        int dr=0,dc=0;
        switch(dir){
            case 1: dr=0;dc=2;break;
            case 2: dr=1;dc=1;break;
            case 3: dr=1;dc=-1;break;
            case 4: dr=0;dc=-2;break;
            case 5: dr=-1;dc=-1;break;
            case 6: dr=-1;dc=1;break;
        }
        int y=er+dr,x=ec+dc;
        while(y>=0&&y<rows&&x>=0&&x<(int)g[y].size()&&g[y][x]!='*'){
            if(g[y][x]=='O') g[y][x]='M';
            y+=dr;x+=dc;
        }
        if(k>0) out+="\n";
        for(int i=0;i<rows;i++){out+=g[i];out+="\n";}
    }
    cout<<out;
    return 0;
}